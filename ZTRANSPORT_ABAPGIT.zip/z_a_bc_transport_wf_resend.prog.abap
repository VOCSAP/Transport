*&---------------------------------------------------------------------*
*& Report  Z_A_BC_TRANSPORT_WF_RESEND
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT z_a_bc_transport_wf_resend.


SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Mode de Transport
" -----------------------------------------------------------

" Normal
PARAMETERS : p_norm RADIOBUTTON GROUP rg1 DEFAULT 'X' USER-COMMAND uc1 MODIF ID rg1.

" Express
PARAMETERS : p_ft2 RADIOBUTTON GROUP rg1 MODIF ID rg1.

" Critique
PARAMETERS : p_crit RADIOBUTTON GROUP rg1 MODIF ID rg1.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Typologie de Transport
" -----------------------------------------------------------

" Demande
PARAMETERS : p_req AS CHECKBOX DEFAULT 'X'.

" Lot
PARAMETERS : p_batch AS CHECKBOX.

SELECTION-SCREEN END OF BLOCK b2.


START-OF-SELECTION.
***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_request  TYPE STANDARD TABLE OF ztbrequest
      WITH NON-UNIQUE KEY primary_key COMPONENTS zedreqnb.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
    lr_target  TYPE ddtrange.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Cible
  lr_target = VALUE #(
    (
      low    = zcl_transport_request_celio=>mc_system-production
      sign   = if_trba_selection_c=>gc_sign_incl
      option = if_trba_selection_c=>gc_option_eq
    )
  ).

  IF p_req EQ abap_true.
    " -----------------------------------------------------------
    " Récupération des Demandes en Attente de Validation
    " -----------------------------------------------------------

    " Récupération des Demandes non validées
    CALL FUNCTION 'Z_BC_TRANSPORT_GET_TABLE'
      EXPORTING
        iv_code            = abap_true
        iv_lock            = abap_true
        iv_trtdate_empty   = abap_true
      TABLES
        rs_valid_target    = lr_target
        et_read_ztbrequest = lt_request.
    IF lt_request[] IS INITIAL.
      " Pas de Demande en cours de Validation
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Relance Notification
    " -----------------------------------------------------------

    CASE abap_true.

      WHEN p_ft2.
        " Uniquement Demande Express
        ""  --> Supprime les Demandes non Express et celles déjà validées
        DELETE lt_request WHERE zedeligible EQ abap_false OR zedvalft2 EQ abap_true.

      WHEN p_crit.
        " Uniquement Demande Critique
        ""  --> Supprime les Demandes non Critiques non validées
        DELETE lt_request WHERE zedreqcritic EQ abap_false OR ( zedreqcritic EQ abap_true AND zedsupervalidated EQ abap_false ).

        ""  --> Supprime les Demandes Express non validées FT2
        DELETE lt_request WHERE zedeligible EQ abap_true AND zedvalft2 EQ abap_false.

      WHEN OTHERS.
        " Autres
        ""  --> Filtre les Demandes déjà validées
        DELETE lt_request WHERE NOT zedvaluser IS INITIAL.

    ENDCASE.

    LOOP AT lt_request ASSIGNING FIELD-SYMBOL(<lfs_s_request>).

      " Relance Notification
      zcl_transport_request_workflow=>workflow_validation_resend( <lfs_s_request>-zedreqnb ).

    ENDLOOP.

  ENDIF.

  IF p_batch EQ abap_true.
    " -----------------------------------------------------------
    " Récupération des Lots en Attente de Validation
    " -----------------------------------------------------------

    SELECT zedbatch
      FROM ztbrequest_batch
     WHERE zedvalidated EQ @abap_false
      INTO TABLE @DATA(lt_batch).

    LOOP AT lt_batch ASSIGNING FIELD-SYMBOL(<lfs_s_batch>).

      " Relance Notification
      zcl_transport_batch_workflow=>workflow_validation_resend( <lfs_s_batch>-zedbatch ).

    ENDLOOP.

  ENDIF.
