class ZCL_TRANSPORT_REQUEST_CELIO definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ts_request_create,
        sysid    TYPE sy-sysid,
        zedreqnb TYPE ztbrequest-zedreqnb,
      END OF   ts_request_create .
  types:
    tt_request_create TYPE STANDARD TABLE OF ts_request_create
            WITH NON-UNIQUE KEY primary_key COMPONENTS sysid .
  types:
    BEGIN OF ts_transport_road,
        source TYPE SYST_SYSID,
        target TYPE SYST_SYSID,
      END OF   ts_transport_road .
  types:
    tt_transport_road TYPE STANDARD TABLE OF ts_transport_road
          WITH NON-UNIQUE KEY primary_key COMPONENTS source .

  constants:
    BEGIN OF mc_request_type,
    classic TYPE ztbrequest-zedtrpcode VALUE space,
    authorization TYPE ztbrequest-zedtrpcode VALUE 'A', ##NO_TEXT
  END OF   mc_request_type .
  constants:
    BEGIN OF mc_validation_code,
      validate TYPE c LENGTH 1 VALUE 'V', ##NO_TEXT
      cancel TYPE c LENGTH 1 VALUE 'C', ##NO_TEXT
    END OF mc_validation_code .
  constants:
    BEGIN OF mc_system,
QUALITY type SY-SYSID value 'IE1', ##NO_TEXT
PREPROD type SY-SYSID value 'RE1', ##NO_TEXT
PRODUCTION type SY-SYSID value 'PE1', ##NO_TEXT
DEVELOPMENT type SY-SYSID value 'DE1', ##NO_TEXT
END OF mc_system .
  constants MC_ATTRIBUTE_DEPENDENCIES type E070A-ATTRIBUTE value 'ZDEPENDENCIES' ##NO_TEXT.

  class-methods CLASS_CONSTRUCTOR .
  class-methods REQUEST_CREATE
    importing
      !IV_TYPE type ZEDTRPCODE
      !IV_BATCH type ZEDREQBATCH optional
      !IT_TRKORR type TRKORRS
      !IV_CRITIC type XFELD optional
      !IS_SYSTEM type COAS_SYSTEM
      !IS_TRANSPORT_DATE type SWU_ORGTIM optional
      !IV_EXPRESS type XSDBOOLEAN optional
      !IV_ONLY_SYSID type XSDBOOLEAN optional
    exporting
      !EV_SUBRC type SY-SUBRC
      !ES_RETURN type BAPIRET2
    returning
      value(RT_REQUEST) type ZCL_TRANSPORT_REQUEST_CELIO=>TT_REQUEST_CREATE .
  class-methods REQUEST_DELETE
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods TRANSPORT_ROAD_GET
    importing
      !IV_SYSID type CLIKE
      !IV_ONLY_SYSID type XSDBOOLEAN optional
    returning
      value(RT_TRANSPORT_ROAD) type ZCL_TRANSPORT_REQUEST_CELIO=>TT_TRANSPORT_ROAD .
  class-methods REQUEST_CHECK
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB optional
      !IR_TRKORR type UCON_TR_REQ_RANGE optional
      !IV_SYSID type ZEDTARGSYS optional
    preferred parameter IV_REQUEST_NUMBER
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods REQUEST_VALIDATION
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB
      !IV_VALIDATION_CODE type CLIKE optional
      !IV_SUPERVALIDATION_CODE type CLIKE optional
    exporting
      !EV_SUBRC type SY-SUBRC
      !EV_CHANGED type XSDBOOLEAN
    returning
      value(RS_REQUEST) type ZTBREQUEST .
  class-methods REQUEST_LOCK
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB
    exporting
      !ES_RETURN type WSRS_RETURN
    returning
      value(RV_LOCKED) type XSDBOOLEAN .
  class-methods REQUEST_UNLOCK
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB
    returning
      value(RV_UNLOCKED) type XSDBOOLEAN .
  class-methods REQUEST_LOCK_CHECK
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB
    returning
      value(RV_IS_LOCKED) type XSDBOOLEAN .
  class-methods REQUEST_DISPLAY
    importing
      !IV_REQUEST_NUMBER type ZEDREQNB
      !IV_EDIT_MODE type XSDBOOLEAN optional
      !AS_POPUP type XSDBOOLEAN optional .
protected section.
private section.

  class-data MO_HARDCODE type ref to ZCL_HARDCODE .
  class-data:
    mr_sval_user TYPE RANGE OF sy-uname .

  class-methods _REQUEST_CREATE
    importing
      !IV_TYPE type ZEDTRPCODE
      !IV_BATCH type ZEDREQBATCH optional
      !IT_TRKORR type TRKORRS
      !IV_CRITIC type XFELD optional
      !IS_SYSTEM type COAS_SYSTEM
      !IS_TRANSPORT_DATE type SWU_ORGTIM
      !IV_EXPRESS type XSDBOOLEAN optional
    exporting
      !EV_SUBRC type SY-SUBRC
      !ES_RETURN type BAPIRET2
    returning
      value(RV_REQUEST) type ZEDREQNB .
  class-methods _REQUEST_CREATE_USING_BATCH
    importing
      !IV_TYPE type ZEDTRPCODE
      !IV_BATCH type ZEDREQBATCH optional
      !IS_SYSTEM type COAS_SYSTEM
      !IS_TRANSPORT_DATE type SWU_ORGTIM
      !IV_CRITIC type XFELD optional
      !IT_TRKORR type TRKORRS
      !IV_EXPRESS type XSDBOOLEAN
    returning
      value(RV_REQNB) type ZEDREQNB .
ENDCLASS.



CLASS ZCL_TRANSPORT_REQUEST_CELIO IMPLEMENTATION.


METHOD class_constructor.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Hardcode
      " -----------------------------------------------------------

      " Récupération Hardcode
      zcl_transport_request_celio=>mo_hardcode =
        zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ). "#EC NOTEXT

      TRY.
          " Détermination utilisateur SVAL
          zcl_transport_request_celio=>mr_sval_user =
            zcl_transport_request_celio=>mo_hardcode->attribute_value_get(
                iv_parameter_name = 'CONFIGURATION'         "#EC NOTEXT
                iv_attribute_name = 'SUPER_VALIDATOR_USER'  "#EC NOTEXT
            )-range.

        CATCH zcx_hardcode.

      ENDTRY.

    CATCH zcx_hardcode.
      " Pas de Hardcode

  ENDTRY.

ENDMETHOD.


METHOD request_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_listasci   TYPE list_string_table,
    lt_listobject TYPE table_abaplist.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lor_data       TYPE REF TO data,
    lo_salv_table  TYPE REF TO cl_salv_table,
    lor_line_descr TYPE REF TO cl_abap_datadescr.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
        <lfs_t_result> TYPE STANDARD TABLE.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Paramétrage pour récupération ALV résultat
  " -----------------------------------------------------------

  " Récuépration données & metadata
  cl_salv_bs_runtime_info=>set(
    data     = abap_true
    display  = abap_false
    metadata = abap_true
  ).

  " -----------------------------------------------------------
  " Lance le programme de contrôle
  " -----------------------------------------------------------

  " Programme de Contrôle
  SUBMIT z_a_bc_transport_check
    WITH p_req    EQ iv_request_number
    WITH s_trkorr IN ir_trkorr[]
    WITH p_sysid  EQ iv_sysid
    EXPORTING LIST TO MEMORY
     AND RETURN.

  TRY.
      " -----------------------------------------------------------
      " Récupération résultat du contrôle
      " -----------------------------------------------------------

      " Récupération données
      cl_salv_bs_runtime_info=>get_data_ref( IMPORTING r_data = lor_data ).
      IF lor_data IS BOUND.
        " Données présente
        ASSIGN lor_data->* TO <lfs_t_result>.

      ENDIF.
      IF NOT <lfs_t_result> IS ASSIGNED
      OR <lfs_t_result> IS INITIAL.
        " Pas de données
        ""  --> Arrêt du traitement
        rv_subrc = 0.
        RETURN.

      ENDIF.

      " Retourne indicateur présence erreur / avertissement
      LOOP AT <lfs_t_result> ASSIGNING FIELD-SYMBOL(<lfs_s_result>).
        ASSIGN COMPONENT 'TYPE' OF STRUCTURE <lfs_s_result> TO FIELD-SYMBOL(<lfs_value>).
        IF <lfs_value> CA 'EAXIW'.                          "#EC NOTEXT
          rv_subrc = 4.
          EXIT.
        ENDIF.
      ENDLOOP.
      IF rv_subrc IS INITIAL.
        " Aucune erreur / avertissement
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

      " Récupération metadata
      DATA(ls_metadata) = cl_salv_bs_runtime_info=>get_metadata( ).

      " Réinitialisation capture ALV
      cl_salv_bs_runtime_info=>clear_all( ).

      TRY.
          " -----------------------------------------------------------
          " Affichage résultat dans une fenêtre modale
          " -----------------------------------------------------------

          " Génération instance ALV
          cl_salv_table=>factory(
            IMPORTING
              r_salv_table   = lo_salv_table
            CHANGING
              t_table        = <lfs_t_result>
          ).

          " Activation fonctions standards
          lo_salv_table->get_functions( )->set_all( abap_true ).

          DATA(lv_end_line) = lines( <lfs_t_result> ) + 1.
          IF lv_end_line GT 20. lv_end_line = 20. ENDIF.

          " Initialisation taille fenêtre modale
          lo_salv_table->set_screen_popup(
            start_line   = 1
            end_line     = lv_end_line
            start_column = 20
            end_column   = 160
          ).

          " Modification Affichage
          zcl_salv_utilities=>fieldcatalog_lvc_to_salv(
            EXPORTING
              it_fieldcatalog = ls_metadata-t_fcat
            CHANGING
              co_salv_table   = lo_salv_table
          ).

          " Modification intitulé
          lo_salv_table->get_display_settings( )->set_list_header(
            |Contrôle Demande|                              "#EC NOTEXT
          ).

          " Affichage de l'ALV
          lo_salv_table->display( ).

        CATCH cx_salv_msg.

      ENDTRY.

    CATCH cx_salv_bs_sc_runtime_info.
      " Erreur récupération données
      ""  --> Le message du programme s'affiche quand même

  ENDTRY.

ENDMETHOD.


METHOD request_create.
*&---------------------------------------------------------------------*
*& Méthode         : REQUEST_CREATE                                    *
*& Classe          : ZCL_TRANSPORT_REQUEST_CELIO                       *
*& Description     : Demande de Transport - Création                   *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 04/04/2019                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_transport_date TYPE swu_orgtim.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_mandt    TYPE sy-mandt,
    lv_released TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  CLEAR : ev_subrc.

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  ls_transport_date = is_transport_date.
  IF ls_transport_date-datum IS INITIAL.
    " Date de Transport Vide
    ls_transport_date-datum = sy-datum.

  ENDIF.

  IF ls_transport_date-datum IS INITIAL.
    " Heure de Transport Vide
    ls_transport_date-uzeit = sy-uzeit.

  ENDIF.

  " -----------------------------------------------------------
  " Libération de l'OT / Tâches
  " -----------------------------------------------------------

  " Libérations des OTs / Tâches
  LOOP AT it_trkorr ASSIGNING FIELD-SYMBOL(<lfs_s_trkorr>).

    IF zcl_transport_request=>transport_request_is_released( <lfs_s_trkorr> )
      EQ abap_false.
      " OT non libéré
      ""  --> Libération de l'OT (et des Tâches)
      IF NOT zcl_transport_request=>transport_request_release(
        EXPORTING
          iv_trkorr = <lfs_s_trkorr>
        IMPORTING
          es_return = es_return
      ) IS INITIAL.
        " Erreur lors de la libération de l'OT
        ""  --> Arrêt du traitement
        ev_subrc = 2.
        RETURN.

      ENDIF.

      " Au moins un OT libérée
      lv_released = abap_true.

    ENDIF.

  ENDLOOP.

  IF lv_released EQ abap_true.
    " Mise en attente le temps que le traitement de libération se finisse
    WAIT UP TO 2 SECONDS.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération Route de Transport
  " -----------------------------------------------------------

  " Récupération des Environnements
  DATA(lt_transport_road) = zcl_transport_request_celio=>transport_road_get(
    iv_sysid      = is_system-sysid
    iv_only_sysid = iv_only_sysid
  ).
  IF lt_transport_road[] IS INITIAL.
    " Aucun Environnement
    ""  --> Arrêt du traitement
    ev_subrc   = 4.
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Création Demande(s) de Transport
  " -----------------------------------------------------------

  IF is_system-mandt IS INITIAL.
    " Utilisation mandant courrant
    lv_mandt = sy-mandt.

  ELSE.
    " Utilisation mandant transmis
    lv_mandt = is_system-mandt.

  ENDIF.

  " Création d'une Demande pour chaque Environnement
  LOOP AT lt_transport_road ASSIGNING FIELD-SYMBOL(<lfs_s_transport_road>).

    " Création de la Requête
    APPEND VALUE #(
      sysid    = <lfs_s_transport_road>-target
      zedreqnb = zcl_transport_request_celio=>_request_create(
                      is_system         = VALUE #(
                        mandt = lv_mandt
                        sysid = <lfs_s_transport_road>-source
                      )
                      iv_type           = iv_type
                      iv_batch          = iv_batch
                      iv_critic         = iv_critic
                      it_trkorr         = it_trkorr
                      iv_express        = iv_express
                      is_transport_date = ls_transport_date
                 )
    ) TO rt_request. "Ajout dans la table de sortie

  ENDLOOP.

ENDMETHOD.


METHOD request_delete.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_request_number IS INITIAL.
    " Pas de Demande
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Suppression de la Demande
      " -----------------------------------------------------------

      " Suppression de la séquence
      DELETE FROM ztborderseq WHERE zedreqnb EQ @iv_request_number.

      " Suppression de la Demande
      DELETE FROM ztbrequest WHERE zedreqnb EQ @iv_request_number.

      " Fin Workflow Validation
      zcl_transport_request_workflow=>workflow_validation_stop( iv_request_number ).

    CATCH cx_root.
      " Erreur lors de la suppression
      ""  --> Rollback
      rv_subrc = 4.
      ROLLBACK WORK.
      RETURN.

  ENDTRY.

ENDMETHOD.


METHOD REQUEST_DISPLAY.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_tab_current TYPE seltabinfo.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_request_number IS INITIAL.
    " N° demande vide
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Affichage de l'édition
  " -----------------------------------------------------------

  " Lecture-seule ?
  DATA(lv_read_only) = xsdbool( iv_edit_mode EQ abap_false ).

  " Initialise données écran à afficher
  ls_tab_current = VALUE #(
    prog      = 'Z_BC_TRANSPORT_REQUEST' ##NO_TEXT
    dynnr     = 3000
    activetab = 'UCOMM2' ##NO_TEXT
  ).

  " Export les données pour l'import
  EXPORT current_tab = ls_tab_current TO MEMORY ID 'ZMEM_ID_TAB_NAV' ##NO_TEXT.

  " Affichage de la Demande en modification / lecture-seule
  SUBMIT z_bc_transport_request
    WITH p_screen = ls_tab_current-dynnr
    WITH p_req    = iv_request_number
    WITH p_ronly  = lv_read_only.

ENDMETHOD.


METHOD request_lock.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Blocage de la Demande
  " -----------------------------------------------------------

  " Blocage de la Demande
  CALL FUNCTION 'ENQUEUE_EZ_ZTBREQUEST'
    EXPORTING
      mode_ztbrequest = 'E'
      zedreqnb        = iv_request_number
    EXCEPTIONS
      foreign_lock    = 1
      system_failure  = 2
      error_message   = 3
      OTHERS          = 4.

  " Retourne booléen
  rv_locked = boolc( sy-subrc EQ 0 ).

  " Retourne message
  IF sy-subrc NE 0 AND es_return IS SUPPLIED.
    " Echec du Blocage
    ""  --> Alimentation message retour
    IF sy-msgid IS INITIAL.
      MESSAGE e015(pams) INTO es_return-message.
    ENDIF.
    CALL FUNCTION 'WSRS_MSG_EXCEPTION_CATCH'
      CHANGING
        px_return = es_return.

  ENDIF.

ENDMETHOD.


METHOD request_lock_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
        lt_enq TYPE wlf_seqg3_tab.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_subrc TYPE sy-subrc.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Lecture entrée blocage
  " -----------------------------------------------------------

  " Lecture entrée blocage sur la Livraison
  CALL FUNCTION 'ENQUEUE_READ'
    EXPORTING
      gname                 = CONV seqg3-gname( 'ZTBREQUEST' ) "#EC NOTEXT
      garg                  = CONV seqg3-garg( |{ sy-mandt }{ iv_request_number }| )
      guname                = space
    IMPORTING
      subrc                 = lv_subrc
    TABLES
      enq                   = lt_enq
    EXCEPTIONS
      communication_failure = 1
      system_failure        = 2
      OTHERS                = 3.

  " Retourne booléen
  rv_is_locked = boolc( sy-subrc NE 0 OR NOT lt_enq[] IS INITIAL ).

ENDMETHOD.


METHOD request_unlock.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Déblocage de la Demande
  " -----------------------------------------------------------

  " Déblocage de la Demande
  CALL FUNCTION 'DEQUEUE_EZ_ZTBREQUEST'
    EXPORTING
      mode_ztbrequest = 'E'
      zedreqnb        = iv_request_number.

  " Retourne booléen Demande Bloquée
  rv_unlocked = boolc( zcl_transport_request_celio=>request_lock_check( iv_request_number ) EQ abap_false ).

ENDMETHOD.


METHOD request_validation.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_valid            TYPE xsdboolean,
    lv_validation       TYPE xsdboolean,
    lv_super_validation TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  CLEAR : ev_changed, ev_subrc.

  " -----------------------------------------------------------
  " Sélection des données
  " -----------------------------------------------------------

  " Récupération données de la Demande
  SELECT SINGLE * FROM ztbrequest
                 WHERE zedreqnb EQ @iv_request_number
                  INTO @rs_request.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF  rs_request-zedreqcritic   EQ abap_true
  AND ( iv_validation_code      EQ zcl_transport_request_celio=>mc_validation_code-validate
   OR   iv_supervalidation_code EQ zcl_transport_request_celio=>mc_validation_code-validate ).
    " Demande Critique
    IF NOT sy-uname IN zcl_transport_request_celio=>mr_sval_user.
      " Demande Critique et Utilisateur non autorisé à la Valider
      ""  --> Rejet de la Validation
      MESSAGE s026(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Affichage PopUp Validation
    CALL FUNCTION 'Z_REQUEST_CRITICITY_ASK_VAL'
      EXPORTING
        iv_request_number = iv_request_number
      IMPORTING
        ev_validated      = lv_valid.

    IF lv_valid EQ abap_false.
      " Utilisateur n'a pas Validé la Demande
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Détermination champ à mettre à jour
  " -----------------------------------------------------------

  IF iv_validation_code IS SUPPLIED.
    " Validation
    lv_validation = abap_true.
    CASE iv_validation_code.

      WHEN zcl_transport_request_celio=>mc_validation_code-validate.            " Validation
        " Validation
        CLEAR rs_request-zedvalcode.
        rs_request-zedvaluser = sy-uname.
        rs_request-zedvaldate = sy-datum.
        rs_request-zedvaltime = sy-uzeit.

      WHEN zcl_transport_request_celio=>mc_validation_code-cancel.
        " Annulation de la Validation
        rs_request-zedvalcode = abap_true.
        CLEAR : rs_request-zedvaluser, rs_request-zedvaldate, rs_request-zedvaltime.

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDIF.

  IF  iv_supervalidation_code IS SUPPLIED
  AND rs_request-zedreqcritic EQ abap_true.
    " Super-Validation
    lv_super_validation = abap_true.
    CASE iv_supervalidation_code.

      WHEN zcl_transport_request_celio=>mc_validation_code-validate.            " Validation
        " Super-Validation
        rs_request-zedsupvaluser     = sy-uname.
        rs_request-zedsupvaldate     = sy-datum.
        rs_request-zedsupvaltime     = sy-uzeit.
        rs_request-zedsupervalidated = abap_true.

      WHEN zcl_transport_request_celio=>mc_validation_code-cancel.
        " Annulation Super-Validation
        rs_request-zedsupervalidated = abap_false.
        CLEAR : rs_request-zedsupvaluser, rs_request-zedsupvaltime, rs_request-zedsupvaldate.

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDIF.

  " -----------------------------------------------------------
  " MàJ DB
  " -----------------------------------------------------------

  " Mise à jour en DB
  CALL FUNCTION 'Z_BC_TRANSPORT_UPDATE_TABLE'
    EXPORTING
      iv_zedreqnb          = iv_request_number
      iv_zedvalcode        = rs_request-zedvalcode
      iv_zedvaluser        = rs_request-zedvaluser
      iv_zedvaldate        = rs_request-zedvaldate
      iv_zedvaltime        = rs_request-zedvaltime
      iv_zedsupvaluser     = rs_request-zedsupvaluser
      iv_zedsupvaldate     = rs_request-zedsupvaldate
      iv_zedsupvaltime     = rs_request-zedsupvaltime
      iv_zedsupervalidated = rs_request-zedsupervalidated
    EXCEPTIONS
      OTHERS               = 1.

  " Retourne Code
  ev_subrc = sy-subrc.

  " Changement effectuée
  ev_changed = abap_true.

  " Commit
  COMMIT WORK AND WAIT.

  " -----------------------------------------------------------
  " Post-MàJ
  " -----------------------------------------------------------

  IF iv_validation_code IS SUPPLIED.
    CASE iv_validation_code.

      WHEN zcl_transport_request_celio=>mc_validation_code-validate.
        " Fin du WF de Validation
        zcl_transport_request_workflow=>workflow_validation_done(
          CONV #( |{ rs_request-zedreqnb ALPHA = IN }| )
        ).

      WHEN zcl_transport_request_celio=>mc_validation_code-cancel.
        " Relance WF de Validation
        zcl_transport_request_workflow=>workflow_validation_start(
          CONV #( |{ rs_request-zedreqnb ALPHA = IN }| )
        ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDIF.

ENDMETHOD.


METHOD transport_road_get.
*&---------------------------------------------------------------------*
*& Méthode         : TRANSPORT_ROAD_GET                                *
*& Classe          : ZCL_TRANSPORT_REQUEST_CELIO                       *
*& Description     : Liste Chemin de Transport                         *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 05/04/2019                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_transport_road TYPE zcl_transport_request_celio=>ts_transport_road.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " Initialisation première recherche
  ls_transport_road-source = iv_sysid.

  WHILE 1 = 1.
    " -----------------------------------------------------------
    " Recherche des Systèmes Sources
    " -----------------------------------------------------------

    " Récupération Système Source
    SELECT SINGLE zedsoursys, zedtargsys
      FROM ztbdestrfc
     WHERE zedtargsys EQ @ls_transport_road-source
       AND loekz      EQ @abap_false
      INTO @ls_transport_road.
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Arrêt de la boucle
      EXIT.

    ENDIF.

    " Ajout du Système Source
    INSERT ls_transport_road INTO rt_transport_road INDEX 1.

    IF iv_only_sysid EQ abap_true.
      " Uniquuement Système cible
      ""  --> Arrêt de la boucle
      EXIT.

    ENDIF.

  ENDWHILE.

ENDMETHOD.


METHOD _request_create.
*&---------------------------------------------------------------------*
*& Méthode         : _REQUEST_CREATE                                   *
*& Classe          : ZCL_TRANSPORT_REQUEST_CELIO                       *
*& Description     : Demande de Transport - Création                   *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 04/04/2019                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Création de la Demande de Transport
  " -----------------------------------------------------------

  " Création de la Demande de Transport - Batch Input
  rv_request = zcl_transport_request_celio=>_request_create_using_batch(
      iv_type           = iv_type
      iv_batch          = iv_batch
      iv_critic         = iv_critic
      is_system         = is_system
      it_trkorr         = it_trkorr
      iv_express        = iv_express
      is_transport_date = is_transport_date
  ).

ENDMETHOD.


METHOD _request_create_using_batch.
*&---------------------------------------------------------------------*
*& Méthode         : _REQUEST_CREATE_USING_BATCH                       *
*& Classe          : ZCL_TRANSPORT_REQUEST_CELIO                       *
*& Description     : Demande de Transport - Création (Batch Input      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 04/04/2019                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_batch   TYPE bdcdata_tab,
    lt_trkorr  TYPE trkorrs,
    lt_message TYPE wdkmsg_tty.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_options               TYPE ctu_params,
    ls_transport_date_wished TYPE swu_orgtim.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_line    TYPE numc2,
    lv_message TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  IF NOT iv_batch IS INITIAL.
    " Création avec un Lot
    ""  --> Récupération Donnés du Lot
    ls_transport_date_wished = CORRESPONDING #(
      zcl_transport_request_batch=>batch_get( iv_batch )
      MAPPING datum = zedtrpdate
              uzeit = zedtrptime
       EXCEPT *
    ).

  ELSEIF NOT is_transport_date IS INITIAL.
    " Date & Heure de Transport transmise
    ls_transport_date_wished = is_transport_date.

  ENDIF.

  IF ls_transport_date_wished IS INITIAL.
    " Demande sans Lot ou Lot inexistant
    ""  --> Utilisation Date & Heure actuelle
    ls_transport_date_wished-datum = sy-datum.
    ls_transport_date_wished-uzeit = sy-uzeit.

  ENDIF.

  " -----------------------------------------------------------
  " Préparation dossier Batch-Input
  " -----------------------------------------------------------

  lt_batch = VALUE #(
    (
      " Ecran de ZBC_REQUEST_CREATE / Grisée
      program  = 'Z_M_BC_TRANSPORT_REQUEST'                 "#EC NOTEXT
      dynpro   = '2000'                                     "#EC NOTEXT
      dynbegin = abap_true
    )
    (
    " Validation
      fnam = 'BDC_OKCODE'                                   "#EC NOTEXT
      fval = '=VALI'                                        "#EC NOTEXT
    )
    (
      " Ecran de ZBC_REQUEST_CREATE / Saisie des Info d'Entête
      program  = 'Z_M_BC_TRANSPORT_REQUEST'                 "#EC NOTEXT
      dynpro   = '2000'                                     "#EC NOTEXT
      dynbegin = abap_true
    )
    (
    " Code Transport
      fnam = 'ZTBREQUEST-ZEDTRPCODE'                        "#EC NOTEXT
      fval = iv_type
    )
    (
    " Système Cible
      fnam = 'ZTBREQUEST-ZEDSOURSYS'                        "#EC NOTEXT
      fval = is_system-sysid
    )
    (
    " Mandant Cible
      fnam = 'ZTBREQUEST-ZEDSOURMDT'                        "#EC NOTEXT
      fval = is_system-mandt
    )
    (
    " Date
      fnam = 'ZTBREQUEST-ZEDTRPDATE'                        "#EC NOTEXT
      fval = |{ ls_transport_date_wished-datum DATE = USER }|
    )
    (
    " Heure
      fnam = 'ZTBREQUEST-ZEDTRPTIME'                        "#EC NOTEXT
      fval = |{ ls_transport_date_wished-uzeit TIME = USER }|
    )
    (
    " Radio-boutton Mandant-Dépendant
      fnam = 'DCLT'                                         "#EC NOTEXT
      fval = abap_true
    )
    (
    " Radio-boutton Inter-Mandant
      fnam = 'ICLT'                                         "#EC NOTEXT
      fval = abap_false
    )
    (
    " Validation
      fnam = 'BDC_OKCODE'                                   "#EC NOTEXT
      fval = '=VALI'                                        "#EC NOTEXT
    )
  ).

  IF is_system-sysid NE zcl_transport_request_celio=>mc_system-development.
    " -----------------------------------------------------------
    " PopUp Sélection d'une Autre Demande
    " -----------------------------------------------------------

    APPEND LINES OF VALUE bdcdata_tab(
      (
        " PopUp Reprise Demande ?
        program  = 'SAPLSWOS'                               "#EC NOTEXT
        dynpro   = '0600'                                   "#EC NOTEXT
        dynbegin = abap_true
      )
      (
        fnam = 'BDC_OKCODE'
        fval = '=N'
      )
    ) TO lt_batch.

  ENDIF.

  IF is_system-sysid EQ zcl_transport_request_celio=>mc_system-preprod.
    " Système Source Recette
    IF NOT iv_batch IS INITIAL OR iv_express EQ abap_true.
      APPEND VALUE #(
        " Ecran de ZBC_REQUEST_CREATE
        program  = 'Z_M_BC_TRANSPORT_REQUEST'               "#EC NOTEXT
        dynpro   = '2000'                                   "#EC NOTEXT
        dynbegin = abap_true
      ) TO lt_batch.

    ENDIF.
    IF iv_express EQ abap_true.
      " -----------------------------------------------------------
      " Coche Demande Express
      " -----------------------------------------------------------

      APPEND VALUE #(
        fnam = 'ZTBREQUEST-ZEDELIGIBLE'                     "#EC NOTEXT
        fval = iv_express
      ) TO lt_batch.

    ENDIF.

    IF NOT iv_batch IS INITIAL.
      " -----------------------------------------------------------
      " N° de Lot
      " -----------------------------------------------------------

      APPEND VALUE #(
        fnam = 'ZTBREQUEST-ZEDREQBATCH'                     "#EC NOTEXT
        fval = iv_batch
      ) TO lt_batch.

    ENDIF.

    IF NOT iv_batch IS INITIAL OR iv_express EQ abap_true.
      APPEND VALUE #(
        fnam = 'BDC_OKCODE'                                 "#EC NOTEXT
        fval = '=VALI'                                      "#EC NOTEXT
      ) TO lt_batch.

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Ajout des OTs
  " -----------------------------------------------------------

  " Découpe les OTs par Paquet de 10
  DATA(lo_tranchor) = NEW zcl_tranchor(
    it_data         = it_trkorr
    iv_package_size = 10
  ).

  " Ajout des OTs 10 par 10
  WHILE lo_tranchor->has_next( ) EQ abap_true.

    " Récupération Paquet Suivant
    lo_tranchor->get_next( IMPORTING et_package = lt_trkorr ).

    " Réinitialisation Position
    lv_line = 01.

    " Ecran ZBC_REQUEST_CREATE / Saisie OT
    APPEND VALUE #(
      program  = 'Z_M_BC_TRANSPORT_REQUEST'                 "#EC NOTEXT
      dynpro   = '2000'                                     "#EC NOTEXT
      dynbegin = abap_true
    ) TO lt_batch.

    " Ajout des OTs
    LOOP AT lt_trkorr ASSIGNING FIELD-SYMBOL(<lfs_s_trkorr>).

      " Ajout de l'OT
      APPEND VALUE #(
          fnam = |GT_ORDER-TRKORR({ lv_line })|             "#EC NOTEXT
          fval = <lfs_s_trkorr>
      ) TO lt_batch.

      " Ajout de la Criticité
      APPEND VALUE #(
          fnam = |GT_ORDER-CRITIC({ lv_line })|             "#EC NOTEXT
          fval = iv_critic
      ) TO lt_batch.

      " Incrémentation N° Ligne
      ADD 1 TO lv_line.

    ENDLOOP.

    " Valide
    APPEND VALUE #(
      fnam = 'BDC_OKCODE'                                   "#EC NOTEXT
      fval = '=VALI'                                        "#EC NOTEXT
    ) TO lt_batch.

    IF lo_tranchor->has_next( ) EQ abap_true.
      " Saut de Page
      APPEND LINES OF VALUE bdcdata_tab(
        (
          " Ecran de ZBC_REQUEST_CREATE / Saut de Page
          program  = 'Z_M_BC_TRANSPORT_REQUEST'             "#EC NOTEXT
          dynpro   = '2000'                                 "#EC NOTEXT
          dynbegin = abap_true
        )
        (
          fnam = 'BDC_OKCODE'
          fval = '=P+'
        )
      ) TO lt_batch.

    ENDIF.

  ENDWHILE.

  " -----------------------------------------------------------
  " Finalisation
  " -----------------------------------------------------------

  " Finalisation
  APPEND LINES OF VALUE bdcdata_tab(
      (
        " Ecran de ZBC_REQUEST_CREATE / Sauvegarde
        program  = 'Z_M_BC_TRANSPORT_REQUEST'               "#EC NOTEXT
        dynpro   = '2000'                                   "#EC NOTEXT
        dynbegin = abap_true
      )
    (
      fnam = 'BDC_OKCODE'                                   "#EC NOTEXT
      fval = '=SAVE'                                        "#EC NOTEXT
    )
  ) TO lt_batch.

  " -----------------------------------------------------------
  " Exécution dossier Batch-Input
  " -----------------------------------------------------------

  " Mode Asychrone / Pas d'affichage
  ls_options-updmode  = 'A'.                                "#EC NOTEXT
  ls_options-dismode  = 'P'.                                "#EC NOTEXT
  ls_options-racommit = abap_true.

  " Appel de la Transaction
  ""  --> Active l'indicateur de nouvelle génération
  EXPORT new_gen = abap_true TO MEMORY ID 'NEW_GEN'.        "#EC NOTEXT
  CALL TRANSACTION 'ZBC_REQUEST_CREATE'                     "#EC NOTEXT
           WITHOUT AUTHORITY-CHECK
             USING lt_batch
     MESSAGES INTO lt_message OPTIONS FROM ls_options.
  ""  --> Libére l'indicateur
  FREE MEMORY ID 'NEW_GEN'.                                 "#EC NOTEXT

  TRY.
      " Récupération du Numéro de Demande
      lv_message = lt_message[ lines( lt_message ) ]-msgv1.
      FIND REGEX '\d' IN lv_message MATCH OFFSET DATA(lv_offset). "#EC NOTEXT
      IF sy-subrc EQ 0.
        rv_reqnb = lv_message+lv_offset(8).

      ENDIF.

    CATCH cx_sy_itab_line_not_found.

  ENDTRY.

ENDMETHOD.
ENDCLASS.
