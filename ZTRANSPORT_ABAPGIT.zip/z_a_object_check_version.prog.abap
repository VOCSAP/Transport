*&---------------------------------------------------------------------*
*& Report  Z_A_OBJECT_CHECK_VERSION
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT z_a_object_check_version.

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

" -----------------------------------------------------------
" Critère de sélection
" -----------------------------------------------------------

TABLES : e071.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.

" Objet
SELECT-OPTIONS : s_object FOR e071-obj_name NO INTERVALS.

SELECTION-SCREEN END OF BLOCK b1.

***==================================================================***
**                           INITIALIZATION                           **
***==================================================================***
INITIALIZATION.


***==================================================================***
**                         AT SELECTION-SCREEN                        **
***==================================================================***
AT SELECTION-SCREEN.


***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***
AT SELECTION-SCREEN OUTPUT.

***==================================================================***
**                AT SELECTION-SCREEN ON VALUE REQUEST                **
***==================================================================***


***==================================================================***
**                         START-OF-SELECTION                         **
***==================================================================***
START-OF-SELECTION.

  TYPES :
    BEGIN OF ts_object_ot,
      object                    TYPE e071-obj_name,
      trkorr                    TYPE e071-trkorr,
      trkorr_main               TYPE e070-strkorr,
      as4text                   TYPE e07t-as4text,
      transport_recette         TYPE xsdboolean,
      transport_recette_icon    TYPE icon_d,
      transport_production      TYPE xsdboolean,
      transport_production_icon TYPE icon_d,
    END OF   ts_object_ot.

  TYPES : tt_object_ot TYPE STANDARD TABLE OF ts_object_ot
                          WITH NON-UNIQUE KEY primary_key COMPONENTS object trkorr_main.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_object_ot TYPE tt_object_ot.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_salv    TYPE REF TO cl_salv_table,
    lo_column  TYPE REF TO cl_salv_column,
    lo_columns TYPE REF TO cl_salv_columns.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_strlen               TYPE lvc_outlen,
    lv_object_length_output TYPE lvc_outlen.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF s_object[] IS INITIAL.
    " Aucun Objet
    ""  --> Faut en mettre
    MESSAGE s000(zbc) WITH 'Faut' 'des' 'objets' '!' DISPLAY LIKE if_msg_output=>msgtype_error. ##NO_TEXT
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération des OTs constituant
  " -----------------------------------------------------------

  " Récupération des OTs contenant l'Objet
  SELECT
    e071~obj_name AS object, e071~trkorr AS trkorr,
    CASE WHEN main~strkorr NE @space THEN main~strkorr ELSE main~trkorr END AS trkorr_main
    FROM e071  INNER JOIN e070 AS main ON e071~trkorr    EQ main~trkorr
   WHERE e071~obj_name IN @s_object[] AND e071~trkorr   NOT LIKE 'DE1_P%'
     AND ( e071~pgmid  NE @if_dms_constants=>orig_type_corr  AND e071~object NE @if_cts_organizer_constants=>activity_release )
    INTO TABLE @lt_object_ot.
  IF sy-subrc NE 0.
    " Aucun OT sélectionné
    ""  --> Arrêt du traitement
    MESSAGE s000(zbc) WITH text-e02 space space space DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  " Suppression inutile et doublon
  DELETE lt_object_ot WHERE ( trkorr IS INITIAL OR trkorr_main IS INITIAL ).
  SORT : lt_object_ot BY object trkorr_main.
  DELETE ADJACENT DUPLICATES FROM lt_object_ot COMPARING object trkorr_main.

  " Tri par Ordre décroissant
  SORT : lt_object_ot BY object trkorr_main DESCENDING.

  " -----------------------------------------------------------
  " Contrôle Version
  " -----------------------------------------------------------

  LOOP AT lt_object_ot ASSIGNING FIELD-SYMBOL(<lfs_s_object_ot>).

    " Désignation OT // pas mis dans le SELECT au-dessus car condition sur OT / Tâche
    SELECT SINGLE as4text FROM e07t
            WHERE trkorr EQ @<lfs_s_object_ot>-trkorr_main AND langu EQ 'F'
             INTO @<lfs_s_object_ot>-as4text.

    " OT transporté en Recette ?
    <lfs_s_object_ot>-transport_recette = zcl_transport_request=>transport_request_check_import(
      iv_trkorr    = <lfs_s_object_ot>-trkorr_main
      iv_tarsystem = 'RE1'                                  "#EC NOTEXT
    ).

    " Icône Transport Recette
    <lfs_s_object_ot>-transport_recette_icon = SWITCH #( <lfs_s_object_ot>-transport_recette
      WHEN abap_false     THEN text-e00
      WHEN abap_true      THEN text-s00
      WHEN abap_undefined THEN text-i00
    ).

    " OT transporté en Production ?
    <lfs_s_object_ot>-transport_production = zcl_transport_request=>transport_request_check_import(
      iv_trkorr    = <lfs_s_object_ot>-trkorr_main
      iv_tarsystem = 'PE1'                                  "#EC NOTEXT
    ).

    " Icône Transport Production
    <lfs_s_object_ot>-transport_production_icon = SWITCH #( <lfs_s_object_ot>-transport_production
      WHEN abap_false     THEN text-e00
      WHEN abap_true      THEN text-s00
      WHEN abap_undefined THEN text-i00
    ).

    " Taille affichage - Objet
    lv_strlen = strlen( <lfs_s_object_ot>-object ).
    IF lv_strlen GT lv_object_length_output.
      " Taille objet plus grande
      ""  --> Utilisation de cette taille
      lv_object_length_output = lv_strlen + 2.

    ENDIF.

  ENDLOOP.

  " -----------------------------------------------------------
  " Initialisation Affichage ALV
  " -----------------------------------------------------------

  TRY.
      " Création instance ALV
      cl_salv_table=>factory(
        EXPORTING
          list_display = sy-batch
        IMPORTING
          r_salv_table = lo_salv
        CHANGING
          t_table      = lt_object_ot
      ).

      " -----------------------------------------------------------
      " Customization
      " -----------------------------------------------------------

      lo_salv->get_functions( )->set_all( abap_true ).

      TRY.
          " Modification FieldCat
          lo_columns = lo_salv->get_columns( ).

          TRY.
              " Tâche
              lo_column = lo_columns->get_column( 'TRKORR' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...
          ENDTRY.

          TRY.
              " OT
              lo_column = lo_columns->get_column( 'TRKORR_MAIN' ). "#EC NOTEXT
              lo_column->set_output_length( 10 ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...
          ENDTRY.

          TRY.
              " Récupération de la Colonne "OBJECT" - Nom d'Objet
              lo_column = lo_columns->get_column( 'OBJECT' ). "#EC NOTEXT
              lo_column->set_output_length( lv_object_length_output ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...

          ENDTRY.

          TRY.
              " Indicateur Transport Recette
              lo_column = lo_columns->get_column( 'TRANSPORT_RECETTE' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...
          ENDTRY.
*
          TRY.
              " Icone Transport Recette
              lo_column = lo_columns->get_column( 'TRANSPORT_RECETTE_ICON' ). "#EC NOTEXT
              lo_column->set_output_length( '9' ).
              lo_column->set_long_text( CONV #( text-tre ) ).
              lo_column->set_short_text( CONV #( text-tre ) ).
              lo_column->set_medium_text( CONV #( text-tre ) ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...
          ENDTRY.

          TRY.
              " Indicateur Transport Production
              lo_column = lo_columns->get_column( 'TRANSPORT_PRODUCTION' ). "#EC NOTEXT
              lo_column->set_visible( abap_false ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...
          ENDTRY.

          TRY.
              " Icone Transport Production
              lo_column = lo_columns->get_column( 'TRANSPORT_PRODUCTION_ICON' ). "#EC NOTEXT
              lo_column->set_output_length( '9' ).
              lo_column->set_long_text( CONV #( text-tpr ) ).
              lo_column->set_short_text( CONV #( text-tpr ) ).
              lo_column->set_medium_text( CONV #( text-tpr ) ).

            CATCH : cx_salv_not_found, cx_salv_data_error.
              " Une erreur est survenue
              ""  --> Tant pis ...
          ENDTRY.

        CATCH cx_root.
          " Une erreur est survenue

      ENDTRY.

      " -----------------------------------------------------------
      " Affichage
      " -----------------------------------------------------------

      " Affichage
      lo_salv->display( ).

    CATCH cx_salv_msg.

  ENDTRY.


END-OF-SELECTION.
