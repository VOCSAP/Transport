class ZCL_IM_CLIF_TOGGLE_DISPEDI definition
  public
  final
  create public .

public section.

  interfaces IF_EX_CLIF_TOGGLE_DISPEDIT .
protected section.
private section.
ENDCLASS.



CLASS ZCL_IM_CLIF_TOGGLE_DISPEDI IMPLEMENTATION.


METHOD if_ex_clif_toggle_dispedit~handle_class_toggle.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Traitement
  " -----------------------------------------------------------

  " Suivant l'Action utilisateur
  CASE access_mode.

    WHEN 'MODIFY'.                                          "#EC NOTEXT
      IF zcl_transport_request=>object_edition_check( clskey-clsname ) EQ abap_true.
        " L'utilisateur ne souhaite pas poursuivre l'édition
        RAISE no_access.

      ENDIF.

    WHEN OTHERS.
      " Autres

  ENDCASE.

ENDMETHOD.


METHOD if_ex_clif_toggle_dispedit~handle_interface_toggle.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Traitement
  " -----------------------------------------------------------

  " Suivant l'Action utilisateur
  CASE access_mode.

    WHEN 'MODIFY'.                                          "#EC NOTEXT
      IF zcl_transport_request=>object_edition_check( intkey-clsname ) EQ abap_true.
        " L'utilisateur ne souhaite pas poursuivre l'édition
        RAISE no_access.

      ENDIF.

    WHEN OTHERS.
      " Autres

  ENDCASE.

ENDMETHOD.
ENDCLASS.
