*&---------------------------------------------------------------------*
*& Report  ZBC_REQUEST_BATCH_CREATE
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zbc_request_batch_create.

START-OF-SELECTION.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_existing TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Affichage écran de création du Lot
  " -----------------------------------------------------------

  DATA(ls_batch) = zcl_transport_request_batch=>batch_create(
    EXPORTING
      iv_extended_mode    = abap_true
      iv_display_at_popup = abap_false
      iv_commit_immediate = abap_true
    IMPORTING
      ev_existing         = lv_existing
  ).

  IF lv_existing EQ abap_true.
    " Sélection d'un Lot existant
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  IF NOT ls_batch-zedbatch IS INITIAL.
    WRITE : 'Lot créé : ', ls_batch-zedbatch.

  ENDIF.
