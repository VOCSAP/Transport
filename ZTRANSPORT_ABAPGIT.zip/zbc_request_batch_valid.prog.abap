*&---------------------------------------------------------------------*
*& Report  ZBC_REQUEST_BATCH_VALID
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT zbc_request_batch_valid.

TABLES : ztbrequest_batch.

CLASS : lcl_main_tree DEFINITION DEFERRED.
CLASS : lcl_main DEFINITION DEFERRED.
CLASS : lcl_main_tree_toolbar_handler DEFINITION DEFERRED.
CLASS : lcl_main_tree_event_handler DEFINITION DEFERRED.

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Critères de sélection
" -----------------------------------------------------------

" Date de Transport
SELECT-OPTIONS : s_tdate FOR ztbrequest_batch-zedtrpdate.

" Lot
SELECT-OPTIONS : s_batch FOR ztbrequest_batch-zedbatch.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Lot sélectionné
" -----------------------------------------------------------

" Tous les Lots
PARAMETERS : p_all RADIOBUTTON GROUP rg1 MODIF ID bvi USER-COMMAND rg1.

" Validées uniquement
PARAMETERS : p_oval RADIOBUTTON GROUP rg1.

" Non Validées uniquement
PARAMETERS : p_toval RADIOBUTTON GROUP rg1 DEFAULT 'X'.     "#EC NOTEXT

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE text-tb3.
" -----------------------------------------------------------
" Option Visualisation
" -----------------------------------------------------------

PARAMETERS : p_dot AS CHECKBOX USER-COMMAND dot.

SELECTION-SCREEN END OF BLOCK b3.


***------------------------------------------------------------------***
**                             CLASSES                                **
***------------------------------------------------------------------***


*----------------------------------------------------------------------*
*       CLASS LCL_MAIN DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    CONSTANTS :
      BEGIN OF mc_process,
        display TYPE string VALUE 'DISPLAY',
      END OF   mc_process.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Initialisation
    CLASS-METHODS initialization
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main.

    " Criticité - Affichage
    CLASS-METHODS criticity_display
      IMPORTING
                !iv_batch_number     TYPE ztbrequest-zedreqbatch
                !iv_request_number   TYPE ztbrequest-zedreqnb
                !iv_transport_number TYPE trkorr
      RETURNING VALUE(rv_subrc)      TYPE sy-subrc.

    " Traitement Principal
    METHODS process
      IMPORTING
                !iv_process        TYPE string
                !iv_request_number TYPE zedreqnb OPTIONAL
      RETURNING VALUE(rv_subrc)    TYPE sy-subrc.

    " PAI - 2000
    METHODS user_command_2000.


***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs
    CONSTANTS :
      BEGIN OF mc_event,
        back   TYPE sy-ucomm VALUE 'BACK',
        exit   TYPE sy-ucomm VALUE 'EXIT',
        save   TYPE sy-ucomm VALUE 'SAVE',
        leave  TYPE sy-ucomm VALUE 'LEAVE',
        cancel TYPE sy-ucomm VALUE 'CANCEL',
      END OF   mc_event.

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    TYPES :
      BEGIN OF ts_criteria,
        or_tdate LIKE REF TO s_tdate[],
        or_batch LIKE REF TO s_batch[],
      END OF   ts_criteria.

    TYPES :
      BEGIN OF ts_visualisation,
        ov_display_ot   TYPE REF TO xsdboolean,
        ov_display_all  TYPE REF TO xsdboolean,
        ov_only_valided TYPE REF TO xsdboolean,
        ov_only_unvalid TYPE REF TO xsdboolean,
      END OF   ts_visualisation.

    TYPES :
      BEGIN OF ts_selection_criteria,
        criteria      TYPE lcl_main=>ts_criteria,
        visualisation TYPE lcl_main=>ts_visualisation,
      END OF   ts_selection_criteria.

    TYPES :
      BEGIN OF ts_batch_data,
        batch_number          TYPE ztbrequest_batch-zedbatch,
        batch_description     TYPE ztbrequest_batch-zedbatch_descr,
        transport_wished_date TYPE ztbrequest_batch-zedtrpdate,
        transport_wished_time TYPE ztbrequest_batch-zedtrptime,
        validated             TYPE ztbrequest_batch-zedvalidated,
        validated_by          TYPE ztbrequest_batch-zedsupvaluser,
        validated_date        TYPE ztbrequest_batch-zedsupvaldate,
        validated_time        TYPE ztbrequest_batch-zedsupvaltime,
        transport_real_date   TYPE ztbrequest_batch-zedtrtdate,
        transport_real_time   TYPE ztbrequest_batch-zedtrttime,
        critic                TYPE ztbrequest_batch-zedcritic,
        express               TYPE ztbrequest_batch-zedeligible,
      END OF   ts_batch_data.

    TYPES : tt_batch_data TYPE SORTED TABLE OF ts_batch_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS batch_number.

    TYPES :
      BEGIN OF ts_request_data,
        request_number        TYPE ztbrequest-zedreqnb,
        transport_wished_date TYPE ztbrequest-zedtrpdate,
        transport_wished_time TYPE ztbrequest-zedtrptime,
        validated             TYPE ztbrequest-zedvalcode,
        validated_by          TYPE ztbrequest-zedvaluser,
        validated_date        TYPE ztbrequest-zedvaldate,
        validated_time        TYPE ztbrequest-zedvaltime,
        transport_real_date   TYPE ztbrequest-zedtrtdate,
        transport_real_time   TYPE ztbrequest-zedtrttime,
        transport_status      TYPE ztbrequest-zedimport,
        critic                TYPE ztbrequest-zedreqcritic,
        express               TYPE ztbrequest-zedeligible,
        batch_number          TYPE ztbrequest-zedreqbatch,
      END OF   ts_request_data.

    TYPES : tt_request_data TYPE SORTED TABLE OF ts_request_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS batch_number request_number.


    TYPES :
      BEGIN OF ts_ot_data,
        request_number      TYPE ztbrequest-zedreqnb,
        ot_number           TYPE e070-trkorr,
        description         TYPE e07t-as4text,
        transport_status    TYPE strw_int4,
        transport_real_date TYPE ztbrequest-zedtrtdate,
        transport_real_time TYPE ztbrequest-zedtrttime,
        critic              TYPE ztborderseq-zedcritic,
      END OF   ts_ot_data.

    TYPES : tt_ot_data TYPE SORTED TABLE OF ts_ot_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS request_number ot_number.

    TYPES :
      BEGIN OF ts_work_area_private,
        o_salv         TYPE REF TO cl_salv_table,
        o_hardcode     TYPE REF TO zcl_hardcode,
        t_ot_data      TYPE lcl_main=>tt_ot_data,
        t_batch_data   TYPE lcl_main=>tt_batch_data,
        t_request_data TYPE lcl_main=>tt_request_data,
      END OF   ts_work_area_private.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Génération Instance
    CLASS-METHODS factory
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main.

    " Constructeur
    METHODS constructor.

    " Contrôle autorisation
    METHODS autorithy_check.

    " Lot - Récupération
    METHODS batch_request_get
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Lot - Visualisation
    METHODS batch_request_display
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Sauvegarde
    METHODS save_to_db
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : ms_work_area_private TYPE lcl_main=>ts_work_area_private.
    DATA : ms_selection_criteria TYPE lcl_main=>ts_selection_criteria.

ENDCLASS.             "lcl_MAIN DEFINITION


*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_TOOLBAR_HANDLER DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_toolbar_handler DEFINITION FINAL.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    CONSTANTS :
      BEGIN OF mc_function,
        display TYPE ui_func VALUE 'DISPLAY',               "#EC NOTEXT
        check   TYPE ui_func VALUE 'CHECK',                 "#EC NOTEXT
      END OF   mc_function.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_main_tree TYPE REF TO lcl_main_tree.

    " Handler Toolbar
    METHODS handler_function_selected FOR EVENT function_selected
                  OF cl_gui_toolbar
      IMPORTING !fcode.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs


*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Handler - Contrôler
    METHODS _handler_on_check.

    " Handler - Afficher
    METHODS _handler_on_display.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mo_main_tree TYPE REF TO lcl_main_tree.

ENDCLASS.             "lcl_MAIN_TREE_TOOLBAR_HANDLER DEFINITION


*----------------------------------------------------------------------*
*       CLASS LCL_main_tree DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree DEFINITION FINAL
    FRIENDS lcl_main_tree_event_handler
            lcl_main_tree_toolbar_handler.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    TYPES :
      BEGIN OF ts_batch_request,
        batch_number                  TYPE ztbrequest_batch-zedbatch,
        request_number                TYPE ztbrequest-zedreqnb,
        ot_number                     TYPE e070-trkorr,
        batch_validated               TYPE xsdboolean,
        batch_description             TYPE ztbrequest_batch-zedbatch_descr,
        batch_transport_wished_date   TYPE ztbrequest_batch-zedtrpdate,
        batch_transport_wished_time   TYPE ztbrequest_batch-zedtrptime,
        batch_transport_real_date     TYPE ztbrequest_batch-zedtrtdate,
        batch_transport_real_time     TYPE ztbrequest_batch-zedtrttime,
        batch_validated_by            TYPE ztbrequest_batch-zedsupvaluser,
        batch_validated_date          TYPE ztbrequest_batch-zedsupvaldate,
        batch_validated_time          TYPE ztbrequest_batch-zedsupvaltime,
        batch_critic                  TYPE ztbrequest-zedreqcritic,
        batch_express                 TYPE ztbrequest-zedeligible,
        request_validated             TYPE xsdboolean,
        request_transport_wished_date TYPE ztbrequest-zedtrpdate,
        request_transport_wished_time TYPE ztbrequest-zedtrptime,
        request_transport_real_date   TYPE ztbrequest-zedtrtdate,
        request_transport_real_time   TYPE ztbrequest-zedtrttime,
        request_validated_by          TYPE ztbrequest-zedvaluser,
        request_validated_date        TYPE ztbrequest-zedvaldate,
        request_validated_time        TYPE ztbrequest-zedvaltime,
        request_transport_status      TYPE ztbrequest-zedqtrpcod,
        request_critic                TYPE ztbrequest-zedreqcritic,
        request_express               TYPE ztbrequest-zedeligible,
        ot_description                TYPE e07t-as4text,
        ot_transport_status           TYPE e070-trstatus,
        ot_critic                     TYPE xsdboolean,
        ot_transport_real_date        TYPE ztbrequest-zedtrtdate,
        ot_transport_real_time        TYPE ztbrequest-zedtrttime,
      END OF   ts_batch_request.

    TYPES : tt_batch_request TYPE SORTED TABLE OF ts_batch_request
                    WITH NON-UNIQUE KEY primary_key COMPONENTS batch_number request_number ot_number.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes
    " Constructor
    METHODS constructor
      IMPORTING
        !io_main          TYPE REF TO lcl_main
        !iv_display_ot    TYPE xsdboolean OPTIONAL
        !it_batch_request TYPE lcl_main_tree=>tt_batch_request.

    " Destructeur
*    METHODS free.

    " Affichage
    METHODS display
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Demande - Affichage
    METHODS request_display
      IMPORTING
                !iv_request_number TYPE zedreqnb
      RETURNING VALUE(rv_subrc)    TYPE sy-subrc.

    " Demande - Contrôle
    METHODS request_check
      IMPORTING
                !iv_request_number TYPE zedreqnb
      RETURNING VALUE(rv_subrc)    TYPE sy-subrc.

    " Demande - Validée
    METHODS request_validation
      IMPORTING
                !iv_node_key    TYPE lvc_nkey
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Lot - Validé
    METHODS batch_validation
      IMPORTING
                !iv_node_key    TYPE lvc_nkey
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    TYPES :
      BEGIN OF ts_display_data,
        batch_validated        TYPE xsdboolean,
        batch_validated_icon   TYPE icon_d,
        request_validated      TYPE xsdboolean,
        request_validated_icon TYPE icon_d,
        request_check_icon     TYPE icon_d,
        batch_number           TYPE ztbrequest_batch-zedbatch,
        request_number         TYPE ztbrequest-zedreqnb,
        ot_number              TYPE e070-trkorr,
        transport_status       TYPE ztbrequest-zedqtrpcod,
        transport_status_icon  TYPE icon_d,
        critic                 TYPE ztbrequest-zedreqcritic,
        critic_icon            TYPE icon_d,
        express                TYPE ztbrequest-zedeligible,
        express_icon           TYPE icon_d,
        batch_description      TYPE ztbrequest_batch-zedbatch_descr,
        ot_description         TYPE e07t-as4text,
        transport_wished_date  TYPE ztbrequest_batch-zedtrpdate,
        transport_wished_time  TYPE ztbrequest_batch-zedtrptime,
        transport_real_date    TYPE ztbrequest_batch-zedtrtdate,
        transport_real_time    TYPE ztbrequest_batch-zedtrttime,
        validated_by           TYPE ztbrequest-zedvaluser,
        validated_date         TYPE ztbrequest-zedvaldate,
        validated_time         TYPE ztbrequest-zedvaltime,
      END OF   ts_display_data .

    TYPES : tt_display_data  TYPE STANDARD TABLE OF ts_display_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS batch_number request_number.


    " Container données
    TYPES :
      BEGIN OF ts_container_data,
        t_display_data TYPE lcl_main_tree=>tt_display_data,
      END OF   ts_container_data.

    " Elèments pour affichage
    TYPES :
      BEGIN OF ts_display_element,
        t_fieldcatalog      TYPE        lvc_t_fcat,
        t_hierarchy         TYPE        zcl_gui_alv_tree_util=>tt_hierarchy,
        o_event             TYPE REF TO lcl_main_tree_event_handler,
        o_alv_tree          TYPE REF TO cl_gui_alv_tree,
        v_handle_tree       TYPE i,
        o_container         TYPE REF TO cl_gui_container,
        o_ccontainer        TYPE REF TO cl_gui_custom_container,
        o_toolbar           TYPE REF TO cl_gui_toolbar,
        s_hierarchy_header  TYPE        treev_hhdr,
        o_toolbar_handler   TYPE REF TO lcl_main_tree_toolbar_handler,
        t_toolbar_excluding TYPE        ui_functions,
      END OF   ts_display_element.

    " Ensemble des composantes
    TYPES :
      BEGIN OF ts_main_tree,
        data            TYPE lcl_main_tree=>ts_container_data,
        display_element TYPE lcl_main_tree=>ts_display_element,
      END OF   ts_main_tree.

    TYPES :
      BEGIN OF ts_work_area_private,
        display_ot     TYPE xsdboolean,
        t_display_data TYPE lcl_main_tree=>tt_display_data,
      END OF   ts_work_area_private.


***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Initialisation données à afficher
    METHODS build_hierarchy_node
      IMPORTING !it_hardcode    TYPE zvtec_t_hc_tt OPTIONAL
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Création des élèments à afficher
    METHODS build_display_element.

    " Création barre de Tâche
    METHODS build_toolbar.

    " Création du Container
    METHODS build_container.

    " Création de l'ALV Tree
    METHODS build_alv_tree.

    " Création du FieldCatalog
    METHODS build_fieldcatalog.

    " Création de la Hiérarchie d'affichagee
    METHODS build_hierarchy.

    " Applique Lecture-Seule
    METHODS _read_only_apply.

    " Mise à jour Noeud
    METHODS _update_data_item
      IMPORTING
                !iv_node_key        TYPE lvc_nkey
                !is_outtab_line     TYPE any
                !it_field_to_update TYPE stringtab
      RETURNING VALUE(rv_subrc)     TYPE sy-subrc.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs
    CONSTANTS : mc_node_level_version TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level VALUE '1'. "#EC NOTEXT
    CONSTANTS : mc_node_level_parameter TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level VALUE '2'. "#EC NOTEXT
    CONSTANTS : mc_node_level_attribute TYPE zcl_gui_alv_tree_util=>ts_hierarchy-node_level VALUE '3'. "#EC NOTEXT

    DATA : mo_main TYPE REF TO lcl_main.
    DATA : mt_level_node_key TYPE zcl_gui_alv_tree_util=>tt_level_node_key.
    DATA : ms_display_element TYPE lcl_main_tree=>ts_main_tree.
    DATA : ms_work_area_private TYPE lcl_main_tree=>ts_work_area_private.

ENDCLASS.             "lcl_main_tree DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_EVENT_HANDLER DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_event_handler DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Génération Instance
    CLASS-METHODS factory
      IMPORTING
                !io_main_tree      TYPE REF TO lcl_main_tree
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main_tree_event_handler.

    " Handler - Evènement - Lien sélectionné
    METHODS on_link_click FOR EVENT link_click OF cl_gui_alv_tree
      IMPORTING fieldname node_key.

    " Handler - Evènement - Double clique
    METHODS on_item_double_click FOR EVENT item_double_click OF cl_gui_alv_tree
      IMPORTING fieldname node_key.

    " Handler - Evènement - Bouton cliqué
    METHODS on_button_click FOR EVENT button_click OF cl_gui_alv_tree
      IMPORTING fieldname node_key.

    " Handler - Evènement - Case à cocher modifié
    METHODS on_checkbox_change FOR EVENT checkbox_change OF cl_gui_alv_tree
      IMPORTING checked fieldname node_key.


***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs


*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Constructeur
    METHODS constructor
      IMPORTING
        !io_main_tree TYPE REF TO lcl_main_tree.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    DATA : mo_alv_tree TYPE REF TO cl_gui_alv_tree.
    DATA : mo_main_tree TYPE REF TO lcl_main_tree.


ENDCLASS.             "lcl_MAIN_TREE_EVENT_HANDLER DEFINITION

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_EVENT_HANDLER IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_event_handler IMPLEMENTATION.

  METHOD factory.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Génération Instance
    " -----------------------------------------------------------

    " Génération Instance
    ro_instance = NEW #(
      io_main_tree
    ).

  ENDMETHOD.

  METHOD on_item_double_click.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Sélection des données
    " -----------------------------------------------------------


  ENDMETHOD.

  METHOD on_link_click.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_outtab_line TYPE lcl_main_tree=>ts_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant le champ
    " -----------------------------------------------------------

    me->mo_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = node_key
      IMPORTING
        e_outtab_line  = ls_outtab_line
      EXCEPTIONS
        node_not_found = 1
        OTHERS         = 2
    ).
    IF sy-subrc NE 0.
      " Noeud inexistant
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Suivant le bouton appuyé
    CASE fieldname.

      WHEN cl_alv_tree_base=>c_hierarchy_column_name.
        " Hiérarchie
        IF NOT ls_outtab_line-ot_number IS INITIAL.
          " Niveau OT
          ""  --> Lance la Visuaisation de l'OT

        ELSEIF NOT ls_outtab_line-request_number IS INITIAL.
          " Niveau Demande
          ""  --> Lance la Visualisation de la Demande
          me->mo_main_tree->request_display( ls_outtab_line-request_number ).

        ELSE.
          " Niveau Lot
          ""  --> Lance la Visualisation du Lot

        ENDIF.

      WHEN 'CRITIC_ICON'.                                   "#EC NOTEXT
        " Criticité
        ""  --> Affiche Criticité
        lcl_main=>criticity_display(
          iv_batch_number     = ls_outtab_line-batch_number
          iv_request_number   = ls_outtab_line-request_number
          iv_transport_number = ls_outtab_line-ot_number
        ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD on_button_click.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_outtab_line TYPE lcl_main_tree=>ts_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant le champ
    " -----------------------------------------------------------

    me->mo_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = node_key
      IMPORTING
        e_outtab_line  = ls_outtab_line
      EXCEPTIONS
        node_not_found = 1
        OTHERS         = 2
    ).
    IF sy-subrc NE 0.
      " Noeud inexistant
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Suivant le bouton appuyé
    CASE fieldname.

      WHEN 'BATCH_VALIDATED_ICON'.                          "#EC NOTEXT
        " Lot - Valider
        me->mo_main_tree->batch_validation( node_key ).

      WHEN 'REQUEST_CHECK_ICON'.                            "#EC NOTEXT
        " Demande - Contrôle
        me->mo_main_tree->request_check( ls_outtab_line-request_number ).

      WHEN 'REQUEST_VALIDATED_ICON'.                        "#EC NOTEXT
        " Demande - Valider
        me->mo_main_tree->request_validation( node_key ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD on_checkbox_change.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " LOG
    " -----------------------------------------------------------


  ENDMETHOD.

  METHOD constructor.
***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_events TYPE cntl_simple_events.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Attribut
    " -----------------------------------------------------------

    me->mo_main_tree = io_main_tree.
    me->mo_alv_tree = me->mo_main_tree->ms_display_element-display_element-o_alv_tree.

    " -----------------------------------------------------------
    " Gestion Evènement
    " -----------------------------------------------------------

    " Récupération Evènement Soucris
    CALL METHOD me->mo_alv_tree->get_registered_events
      IMPORTING
        events = lt_events.

    " Ajout des évènements
    APPEND VALUE #(
        appl_event = abap_true
        eventid    = cl_gui_column_tree=>eventid_link_click
    ) TO lt_events.
    APPEND VALUE #(
        appl_event = abap_true
        eventid = cl_gui_column_tree=>eventid_button_click
    ) TO lt_events.
    APPEND VALUE #(
        appl_event = abap_true
        eventid = cl_gui_column_tree=>eventid_checkbox_change
    ) TO lt_events.

    " Handler - Lien sélectionée
    SET HANDLER me->on_link_click FOR me->mo_alv_tree.

    " Handler - Double clique
    SET HANDLER me->on_item_double_click FOR me->mo_alv_tree.

    " Handler - Bouton cliqué
    SET HANDLER me->on_button_click FOR me->mo_alv_tree.

    " Handler - Case à cocher modifié
    SET HANDLER me->on_checkbox_change FOR me->mo_alv_tree.

    " Enregistre les Evènements
    CALL METHOD me->mo_alv_tree->set_registered_events
      EXPORTING
        events                    = lt_events
      EXCEPTIONS
        cntl_error                = 1
        cntl_system_error         = 2
        illegal_event_combination = 3.

  ENDMETHOD.

ENDCLASS.
*----------------------------------------------------------------------*
*       CLASS LCL_MAIN_TREE_TOOLBAR_HANDLER IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree_toolbar_handler IMPLEMENTATION.


  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Attributs
    " -----------------------------------------------------------

    me->mo_main_tree = io_main_tree.

    " -----------------------------------------------------------
    " Souscription évènements
    " -----------------------------------------------------------

    " Sur la barre d'outil
    SET HANDLER me->handler_function_selected FOR me->mo_main_tree->ms_display_element-display_element-o_toolbar.

  ENDMETHOD.

  METHOD handler_function_selected.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement suite à clique sur Toolbar
    " -----------------------------------------------------------

    " Suivant le code fonction
    CASE fcode.

      WHEN me->mc_function-check.
        " Contrôler
        me->_handler_on_check( ).

      WHEN me->mc_function-display.
        " Afficher
        me->_handler_on_display( ).

      WHEN OTHERS.
        " Autres

    ENDCASE.

  ENDMETHOD.

  METHOD _handler_on_check.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " LOG
    " -----------------------------------------------------------



  ENDMETHOD.

  METHOD _handler_on_display.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " LOG
    " -----------------------------------------------------------



  ENDMETHOD.

ENDCLASS.

*----------------------------------------------------------------------*
*       CLASS LCL_main_tree IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main_tree IMPLEMENTATION.

  METHOD build_display_element.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    IF NOT me->ms_display_element-display_element-o_ccontainer IS BOUND.
      " -----------------------------------------------------------
      " Création du Custom Container
      " -----------------------------------------------------------
      me->build_container( ).

    ENDIF.

    IF me->ms_display_element-display_element-t_fieldcatalog[] IS INITIAL.
      " -----------------------------------------------------------
      " Constitution du FieldCatalog
      " -----------------------------------------------------------
      me->build_fieldcatalog( ).

    ENDIF.

    IF me->ms_display_element-display_element-t_hierarchy[] IS INITIAL.
      " -----------------------------------------------------------
      " Constitution de la Hiérarchie d'affichage
      " -----------------------------------------------------------
      me->build_hierarchy( ).

    ENDIF.

    IF me->ms_display_element-display_element-s_hierarchy_header IS INITIAL.
      " -----------------------------------------------------------
      " Initialisation de l'entête de la Hiérarchie
      " -----------------------------------------------------------
      me->ms_display_element-display_element-s_hierarchy_header-width = SWITCH #(
        me->ms_work_area_private-display_ot
        WHEN abap_true THEN 30 ELSE 20
      ).
      me->ms_display_element-display_element-s_hierarchy_header-heading = text-hea.

    ENDIF.

    IF me->ms_display_element-display_element-t_toolbar_excluding[] IS INITIAL.
      " -----------------------------------------------------------
      " Initialisation des fonctionnalitées à exclures
      " -----------------------------------------------------------

      " Modification affichage des colonnes
      APPEND cl_gui_alv_tree=>mc_fc_print_back      TO me->ms_display_element-display_element-t_toolbar_excluding.
      APPEND cl_gui_alv_tree=>mc_fc_current_variant TO me->ms_display_element-display_element-t_toolbar_excluding.

    ENDIF.

    " -----------------------------------------------------------
    " Création de l'ALV Tree
    " -----------------------------------------------------------

    me->build_alv_tree( ).

  ENDMETHOD.

  METHOD build_toolbar.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération instance Barre de Tâche
    " -----------------------------------------------------------

    " Récupération barre de tâche
    FREE : me->ms_display_element-display_element-o_toolbar.
    me->ms_display_element-display_element-o_alv_tree->get_toolbar_object(
      IMPORTING
        er_toolbar = me->ms_display_element-display_element-o_toolbar
    ).

    IF NOT me->ms_display_element-display_element-o_toolbar IS BOUND.
      " Pas de Toolbar
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Ajout des fonctionnalités
    " -----------------------------------------------------------

*    " Afficher
*    me->ms_display_element-display_element-o_toolbar->add_button(
*      EXPORTING
*        fcode            = lcl_main_tree_toolbar_handler=>mc_function-display
*        icon             = text-dis
*        butn_type        = cntb_btype_button
*        text             = text-tdi
*      EXCEPTIONS
*        cntl_error       = 1
*        cntb_btype_error = 2
*        cntb_error_fcode = 3
*        OTHERS           = 4
*    ).
*
*    " Contrôler
*    me->ms_display_element-display_element-o_toolbar->add_button(
*      EXPORTING
*        fcode            = lcl_main_tree_toolbar_handler=>mc_function-check
*        icon             = text-ctl
*        butn_type        = cntb_btype_button
*        text             = text-tct
*      EXCEPTIONS
*        cntl_error       = 1
*        cntb_btype_error = 2
*        cntb_error_fcode = 3
*        OTHERS           = 4
*    ).
*
*    " Séparateur
*    me->ms_display_element-display_element-o_toolbar->add_button(
*      EXPORTING
*        fcode            = 'SEP1'                           "#EC NOTEXT
*        icon             = text-del
*        butn_type        = cntb_btype_sep
*      EXCEPTIONS
*        cntl_error       = 1
*        cntb_btype_error = 2
*        cntb_error_fcode = 3
*        OTHERS           = 4
*    ).

    " -----------------------------------------------------------
    " Génération Toolbar - Handler
    " -----------------------------------------------------------

    " Création instance Toolbar - Handler
    CREATE OBJECT me->ms_display_element-display_element-o_toolbar_handler
      EXPORTING
        io_main_tree = me.

  ENDMETHOD.

  METHOD build_container.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    CLEAR : me->ms_display_element-display_element-o_ccontainer.

    " -----------------------------------------------------------
    " Création du Custom Container
    " -----------------------------------------------------------

    " Initialisation Custom Container
    CREATE OBJECT me->ms_display_element-display_element-o_ccontainer
      EXPORTING
        container_name              = 'CC_ALV_TREE' "#EC NOTEXT
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5
        OTHERS                      = 6.
    IF sy-subrc NE 0.
      " Une erreur est survenue

    ENDIF.

  ENDMETHOD.

  METHOD build_alv_tree.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-data-t_display_data.

    IF me->ms_display_element-display_element-o_alv_tree IS BOUND.
      " Libération de l'ancienne instance
      me->ms_display_element-display_element-o_alv_tree->free( ).
      FREE : me->ms_display_element-display_element-o_alv_tree.

    ENDIF.

    " -----------------------------------------------------------
    " Création de l'ALV
    " -----------------------------------------------------------

    CREATE OBJECT me->ms_display_element-display_element-o_alv_tree
      EXPORTING
        parent                      = me->ms_display_element-display_element-o_ccontainer
        node_selection_mode         = cl_gui_column_tree=>node_sel_mode_single
        item_selection              = abap_true
        no_html_header              = abap_true
        no_toolbar                  = abap_false
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        illegal_node_selection_mode = 5
        failed                      = 6
        illegal_column_name         = 7.

    " -----------------------------------------------------------
    " Génération instance Handler externe
    " -----------------------------------------------------------

    " Génération instance gestion Evènement
    me->ms_display_element-display_element-o_event = lcl_main_tree_event_handler=>factory(
      io_main_tree = me
    ).

    " -----------------------------------------------------------
    " Préparation de l'Affichage
    " -----------------------------------------------------------

    me->ms_display_element-display_element-o_alv_tree->set_table_for_first_display(
      EXPORTING
        is_hierarchy_header  = me->ms_display_element-display_element-s_hierarchy_header
        it_toolbar_excluding = me->ms_display_element-display_element-t_toolbar_excluding
      CHANGING
        it_outtab            = me->ms_display_element-data-t_display_data
        it_fieldcatalog      = me->ms_display_element-display_element-t_fieldcatalog
    ).

    " -----------------------------------------------------------
    " Génération de la barre de Tâche
    " -----------------------------------------------------------

    me->build_toolbar( ).

  ENDMETHOD.

  METHOD build_fieldcatalog.

***------------------------------------------------------------------***
**                           CONSTANTES                               **
***------------------------------------------------------------------***
    CONSTANTS :
      " Définition longeur d'affichage
      BEGIN OF lc_output_length,
        " Clef
        BEGIN OF key,
          key_standard TYPE lvc_outlen VALUE 30,
        END OF key,
        " Icône
        BEGIN OF icon,
          icon_standard  TYPE lvc_outlen VALUE 15,
          icon_validated TYPE lvc_outlen VALUE 15,
        END OF icon,
        " Date
        BEGIN OF date,
          date_standard TYPE lvc_outlen VALUE 16,
        END OF   date,
        " Heure
        BEGIN OF time,
          time_standard TYPE lvc_outlen VALUE 16,
        END OF   time,
      END OF   lc_output_length.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_dfies    TYPE dfies,
      ls_fieldcat TYPE lvc_s_fcat.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lo_tabledescr  TYPE REF TO cl_abap_tabledescr,
      lo_structdescr TYPE REF TO cl_abap_structdescr.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-display_element-t_fieldcatalog.

    " -----------------------------------------------------------
    " Constitution du FieldCatalog
    " -----------------------------------------------------------

    " Récupération description de la table
    lo_tabledescr ?= cl_abap_structdescr=>describe_by_data( me->ms_display_element-data-t_display_data ).

    " Récupération description ligne de la table
    lo_structdescr ?= lo_tabledescr->get_table_line_type( ).

    " Parcours l'ensemble des champs de la table
    LOOP AT cl_salv_data_descr=>read_structdescr( lo_structdescr ) ASSIGNING FIELD-SYMBOL(<lfs_s_dfies>).

      CLEAR : ls_fieldcat.

      " Initialisation des données
      MOVE-CORRESPONDING <lfs_s_dfies> TO ls_fieldcat.

      " Personnalisation
      CASE ls_fieldcat-fieldname.

        WHEN 'OT_NUMBER'                                    "#EC NOTEXT
          OR 'BATCH_NUMBER'                                 "#EC NOTEXT
          OR 'REQUEST_NUMBER'.                              "#EC NOTEXT
          " Numéro d'OT // Numéro de Lot // Numéro de Demande
          ls_fieldcat-no_out = abap_true.

        WHEN 'OT_DESCRIPTION'.                              "#EC NOTEXT
          " Description OT
          ls_fieldcat-no_out = xsdbool( me->ms_work_area_private-display_ot EQ abap_false ).

        WHEN 'BATCH_DESCRIPTION'.                           "#EC NOTEXT
          " Description Lot
          ls_fieldcat-no_out = abap_true.

        WHEN 'VALIDATED_DATE'                               "#EC NOTEXT
          OR 'TRANSPORT_REAL_DATE'                          "#EC NOTEXT
          OR 'TRANSPORT_WISHED_DATE'.                       "#EC NOTEXT
          " Date
          ls_fieldcat-outputlen = lc_output_length-date-date_standard.

        WHEN 'VALIDATED_TIME'                               "#EC NOTEXT
          OR 'TRANSPORT_REAL_TIME'                          "#EC NOTEXT
          OR 'TRANSPORT_WISHED_TIME'.                       "#EC NOTEXT
          " Heure
          ls_fieldcat-outputlen = lc_output_length-time-time_standard.

        WHEN 'BATCH_VALIDATED'.                             "#EC NOTEXT
          " Lot Validé
          ls_fieldcat-no_out = abap_true.

        WHEN 'BATCH_VALIDATED_ICON'.                        "#EC NOTEXT
          " Lot Validé Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-bva.

        WHEN 'REQUEST_VALIDATED'.                           "#EC NOTEXT
          " Demande Validée
          ls_fieldcat-no_out = abap_true.

        WHEN 'REQUEST_CHECK_ICON'.                          "#EC NOTEXT
          " Conrôle Demande Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-tct.

        WHEN 'REQUEST_VALIDATED_ICON'.                      "#EC NOTEXT
          " Demande Validée Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-rva.

        WHEN 'EXPRESS'.                                     "#EC NOTEXT
          " Demande Express
          ls_fieldcat-no_out = abap_true.

        WHEN 'EXPRESS_ICON'.                                "#EC NOTEXT
          " Demande Express Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-exp.

        WHEN 'CRITIC'.                                      "#EC NOTEXT
          " Demande Express
          ls_fieldcat-no_out = abap_true.

        WHEN 'CRITIC_ICON'.                                 "#EC NOTEXT
          " Demande Critique Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-cri.

        WHEN 'TRANSPORT_STATUS'.                            "#EC NOTEXT
          " Demande Express
          ls_fieldcat-no_out = abap_true.

        WHEN 'TRANSPORT_STATUS_ICON'.                       "#EC NOTEXT
          " Demande Critique Icône
          ls_fieldcat-icon      = abap_true.
          ls_fieldcat-outputlen = lc_output_length-icon-icon_standard.
          ls_fieldcat-scrtext_s = ls_fieldcat-scrtext_m = ls_fieldcat-scrtext_l = text-tsi.

        WHEN OTHERS.
          " Autres

      ENDCASE.

      " Ajout du champ
      APPEND ls_fieldcat TO me->ms_display_element-display_element-t_fieldcatalog.

    ENDLOOP.

  ENDMETHOD.

  METHOD build_hierarchy.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_mandatory_component TYPE cgpl_field_names.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_hierarchy TYPE zcl_gui_alv_tree_util=>ts_hierarchy.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_node_level TYPE i.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-display_element-t_hierarchy.

    " -----------------------------------------------------------
    " Initialisation des Attributs "obligatoire" à alimenter
    " -----------------------------------------------------------

    APPEND 'CRITIC'            TO lt_mandatory_component.   "#EC NOTEXT
    APPEND 'EXPRESS'           TO lt_mandatory_component.   "#EC NOTEXT
    APPEND 'BATCH_NUMBER'      TO lt_mandatory_component.   "#EC NOTEXT
    APPEND 'REQUEST_NUMBER'    TO lt_mandatory_component.   "#EC NOTEXT
    APPEND 'TRANSPORT_STATUS'  TO lt_mandatory_component.   "#EC NOTEXT
    APPEND 'REQUEST_VALIDATED' TO lt_mandatory_component.   "#EC NOTEXT

    " -----------------------------------------------------------
    " Initialisation de la Hiérarchie
    " -----------------------------------------------------------

    " Lot
    ADD 1 TO lv_node_level.
    CLEAR : ls_hierarchy.
    ls_hierarchy-fieldname                = 'BATCH_NUMBER'. "#EC NOTEXT
    ls_hierarchy-node_level               = lv_node_level.
    ls_hierarchy-node_text_dynamic = VALUE #(
      (
        fieldname = 'BATCH_NUMBER'                          "#EC NOTEXT
        alpha_in  = abap_false
        condense  = abap_true
      )
      (
        fieldname = 'BATCH_DESCRIPTION'                     "#EC NOTEXT
        separator = | - |
        alpha_in  = abap_false
      )
    ).
    ls_hierarchy-node_text_alpha_in       = abap_false.
    ls_hierarchy-node_layout-n_image      = text-bat.
    ls_hierarchy-node_layout-exp_image    = text-bat.
    ls_hierarchy-node_layout-isfolder     = abap_true.
    ls_hierarchy-node_level_key_fieldname = 'BATCH_NUMBER'. "#EC NOTEXT
    ls_hierarchy-t_item_layout = VALUE #(
      (
        class     = cl_gui_column_tree=>item_class_link
        fieldname = 'CRITIC_ICON'                           "#EC NOTEXT
      )
      (
        fieldname = 'BATCH_VALIDATED_ICON'                  "#EC NOTEXT
        class   = cl_gui_column_tree=>item_class_button
      )
    ).
    APPEND 'CRITIC_ICON'            TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'EXPRESS_ICON'           TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'VALIDATED_BY'           TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'VALIDATED_DATE'         TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'VALIDATED_TIME'         TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'BATCH_VALIDATED'        TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_REAL_DATE'    TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_REAL_TIME'    TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'BATCH_VALIDATED_ICON'   TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_WISHED_DATE'  TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_WISHED_TIME'  TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_STATUS_ICON'  TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'REQUEST_VALIDATED_ICON' TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND LINES OF lt_mandatory_component TO ls_hierarchy-t_component_display.
    INSERT ls_hierarchy INTO TABLE me->ms_display_element-display_element-t_hierarchy.

    " Demande
    ADD 1 TO lv_node_level.
    CLEAR : ls_hierarchy.
    ls_hierarchy-fieldname                = 'REQUEST_NUMBER'. "#EC NOTEXT
    ls_hierarchy-node_level               = lv_node_level.
*    ls_hierarchy-node_layout-style        = 8.
    ls_hierarchy-hide_if_null             = abap_true.
    ls_hierarchy-hide_if_empty            = abap_true.
    ls_hierarchy-node_text_alpha_in       = abap_false.
    ls_hierarchy-node_layout-n_image      = text-req.
    ls_hierarchy-node_layout-exp_image    = text-req.
    ls_hierarchy-node_layout-isfolder     = me->ms_work_area_private-display_ot.
    ls_hierarchy-node_level_key_fieldname = 'REQUEST_NUMBER'. "#EC NOTEXT
    ls_hierarchy-t_item_layout = VALUE #(
      (
        class     = cl_gui_column_tree=>item_class_link
        fieldname = 'CRITIC_ICON'                           "#EC NOTEXT
      )
      (
        class     = cl_gui_column_tree=>item_class_link
        fieldname = cl_alv_tree_base=>c_hierarchy_column_name
      )
      (
        class     = cl_gui_column_tree=>item_class_button
        fieldname = 'REQUEST_VALIDATED_ICON'                "#EC NOTEXT
      )
      (
        class     = cl_gui_column_tree=>item_class_button
        fieldname = 'REQUEST_CHECK_ICON'                    "#EC NOTEXT
      )
    ).
    APPEND 'CRITIC_ICON'            TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'EXPRESS_ICON'           TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'VALIDATED_BY'           TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'VALIDATED_DATE'         TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'VALIDATED_TIME'         TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'REQUEST_NUMBER'         TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'REQUEST_CHECK_ICON'     TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_REAL_DATE'    TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_REAL_TIME'    TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_WISHED_DATE'  TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_WISHED_TIME'  TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'TRANSPORT_STATUS_ICON'  TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND 'REQUEST_VALIDATED_ICON' TO ls_hierarchy-t_component_display. "#EC NOTEXT
    APPEND LINES OF lt_mandatory_component TO ls_hierarchy-t_component_display.
    INSERT ls_hierarchy INTO TABLE me->ms_display_element-display_element-t_hierarchy.

    IF me->ms_work_area_private-display_ot EQ abap_true.
      " OT
      ADD 1 TO lv_node_level.
      CLEAR : ls_hierarchy.
      ls_hierarchy-fieldname                = 'OT_NUMBER'.  "#EC NOTEXT
      ls_hierarchy-node_level               = lv_node_level.
      ls_hierarchy-hide_if_null             = abap_true.
      ls_hierarchy-hide_if_empty            = abap_true.
      ls_hierarchy-node_text_alpha_in       = abap_false.
      ls_hierarchy-node_layout-n_image      = text-trk.
      ls_hierarchy-node_layout-exp_image    = text-trk.
      ls_hierarchy-node_level_key_fieldname = 'OT_NUMBER'.  "#EC NOTEXT
      ls_hierarchy-t_item_layout = VALUE #(
        (
          class     = cl_gui_column_tree=>item_class_link
          fieldname = 'CRITIC_ICON'                         "#EC NOTEXT
        )
      ).
      APPEND 'OT_NUMBER'             TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'CRITIC_ICON'           TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'EXPRESS_ICON'          TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'OT_DESCRIPTION'        TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'TRANSPORT_REAL_DATE'   TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'TRANSPORT_REAL_TIME'   TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'TRANSPORT_WISHED_DATE' TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'TRANSPORT_WISHED_TIME' TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND 'TRANSPORT_STATUS_ICON' TO ls_hierarchy-t_component_display. "#EC NOTEXT
      APPEND LINES OF lt_mandatory_component TO ls_hierarchy-t_component_display.
      INSERT ls_hierarchy INTO TABLE me->ms_display_element-display_element-t_hierarchy.

    ENDIF.

  ENDMETHOD.

  METHOD display.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des élèments à afficher
    " -----------------------------------------------------------

    me->build_display_element( ).

    " -----------------------------------------------------------
    " Initialisation des données à afficher
    " -----------------------------------------------------------

    me->build_hierarchy_node( ).

    " -----------------------------------------------------------
    " Affichage de l'arboresence
    " -----------------------------------------------------------

    " Appel de l'écran d'affichage
    CALL SCREEN 2000.

  ENDMETHOD.

  METHOD constructor.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_display_data TYPE lcl_main_tree=>ts_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des Attributs
    " -----------------------------------------------------------

    me->mo_main = io_main.
    me->ms_work_area_private-display_ot = iv_display_ot.

    " -----------------------------------------------------------
    " Initialisation des Attributs
    " -----------------------------------------------------------

    " Données à afficher
    LOOP AT it_batch_request ASSIGNING FIELD-SYMBOL(<lfs_s_batch_request>).

      AT NEW batch_number.
        " A chaque nouveau Numéro de Lot
        ""  --> Création entrée Lot
        ls_display_data-critic                = <lfs_s_batch_request>-batch_critic.
        ls_display_data-express               = <lfs_s_batch_request>-batch_express.
        ls_display_data-batch_number          = <lfs_s_batch_request>-batch_number.
        ls_display_data-batch_validated       = <lfs_s_batch_request>-batch_validated.
        ls_display_data-batch_description     = <lfs_s_batch_request>-batch_description.
        ls_display_data-validated_by          = <lfs_s_batch_request>-batch_validated_by.
        ls_display_data-validated_date        = <lfs_s_batch_request>-batch_validated_date.
        ls_display_data-validated_time        = <lfs_s_batch_request>-batch_validated_time.
        ls_display_data-transport_real_date   = <lfs_s_batch_request>-batch_transport_real_date.
        ls_display_data-transport_real_time   = <lfs_s_batch_request>-batch_transport_real_time.
        ls_display_data-transport_wished_date = <lfs_s_batch_request>-batch_transport_wished_date.
        ls_display_data-transport_wished_time = <lfs_s_batch_request>-batch_transport_wished_time.

        ""  --> Icône Critique
        ls_display_data-critic_icon           = SWITCH #( ls_display_data-critic
          WHEN abap_true THEN text-icr ELSE space
        ).

        ""  --> Icône Express
        ls_display_data-express_icon          = SWITCH #( ls_display_data-express
          WHEN abap_true THEN text-iex ELSE space
        ).

        ""  --> Icône Validation
        ls_display_data-batch_validated_icon  = SWITCH #( ls_display_data-batch_validated
          WHEN abap_true THEN text-iva ELSE text-wva
        ).

        ""  --> Ajout de l'entrée
        APPEND ls_display_data TO me->ms_work_area_private-t_display_data
                   REFERENCE INTO DATA(lo_batch_display_data).

      ENDAT.

      AT NEW request_number.
        " A chaque nouvelle Demande
        ""  --> Initialisation données Demande
        ls_display_data-critic                = <lfs_s_batch_request>-request_critic.
        ls_display_data-express               = <lfs_s_batch_request>-request_express.
        ls_display_data-validated_by          = <lfs_s_batch_request>-request_validated_by.
        ls_display_data-validated_date        = <lfs_s_batch_request>-request_validated_date.
        ls_display_data-validated_time        = <lfs_s_batch_request>-request_validated_time.
        ls_display_data-request_number        = <lfs_s_batch_request>-request_number.
        ls_display_data-request_validated     = <lfs_s_batch_request>-request_validated.
        ls_display_data-transport_real_date   = <lfs_s_batch_request>-request_transport_real_date.
        ls_display_data-transport_real_time   = <lfs_s_batch_request>-request_transport_real_time.
        ls_display_data-transport_wished_date = <lfs_s_batch_request>-request_transport_wished_date.
        ls_display_data-transport_wished_time = <lfs_s_batch_request>-request_transport_wished_time.

        ""  --> Icône Contrôle
        ls_display_data-request_check_icon = text-ctl.

        ""  --> Icône Critique
        ls_display_data-critic_icon = SWITCH #( ls_display_data-critic
          WHEN abap_true THEN text-icr ELSE space
        ).

        ""  --> Icône Express
        ls_display_data-express_icon = SWITCH #( ls_display_data-express
          WHEN abap_true THEN text-iex ELSE space
        ).

        ""  --> Icône Validation
        ls_display_data-request_validated_icon = SWITCH #( ls_display_data-request_validated
          WHEN abap_true THEN text-iva ELSE text-wva
        ).

        ""  --> Icône Statut Transport
        ls_display_data-transport_status_icon = SWITCH #( ls_display_data-transport_status
          WHEN 0 THEN text-ito WHEN 4 THEN text-ito ELSE text-itk
        ).

        IF ls_display_data-request_validated EQ abap_true.
          ""  --> Détermination Statut Transport Lot
          lo_batch_display_data->request_validated = abap_true.

        ENDIF.

        IF lo_batch_display_data->transport_status LT ls_display_data-transport_status.
          ""  --> Détermination Demande Validé Transport
          lo_batch_display_data->transport_status = ls_display_data-transport_status.

        ENDIF.

        " Ajout de l'entrée
        APPEND ls_display_data TO me->ms_work_area_private-t_display_data.

      ENDAT.

      IF NOT <lfs_s_batch_request>-ot_number IS INITIAL
      AND me->ms_work_area_private-display_ot EQ abap_true.
        ""  --> Initialisation données OT
        ls_display_data-critic              = <lfs_s_batch_request>-ot_critic.
        ls_display_data-ot_number           = <lfs_s_batch_request>-ot_number.
        ls_display_data-ot_description      = <lfs_s_batch_request>-ot_description.
        ls_display_data-transport_status    = <lfs_s_batch_request>-ot_transport_status.
        ls_display_data-transport_real_date = <lfs_s_batch_request>-ot_transport_real_date.
        ls_display_data-transport_real_time = <lfs_s_batch_request>-ot_transport_real_time.

        ""  --> Icône Statut Transport
        ls_display_data-transport_status_icon = SWITCH #( ls_display_data-transport_status
          WHEN 0 THEN text-ito WHEN 4 THEN text-ito ELSE text-itk
        ).

        ""  --> Icône Critique
        ls_display_data-critic_icon = SWITCH #( ls_display_data-critic
          WHEN abap_true THEN text-icr ELSE space
        ).

        " Ajout de l'entrée
        APPEND ls_display_data TO me->ms_work_area_private-t_display_data.

      ENDIF.

      AT END OF batch_number.
        " Dernière itération du Lot
        ""  --> Icône Lot Validé
        lo_batch_display_data->request_validated_icon = SWITCH #( lo_batch_display_data->request_validated
          WHEN abap_true THEN text-iva ELSE text-wva
        ).

        ""  --> Icône Statut Transport
        lo_batch_display_data->transport_status_icon = SWITCH #( lo_batch_display_data->transport_status
          WHEN 0 THEN text-ito WHEN 4 THEN text-ito ELSE text-itk
        ).

        CLEAR : ls_display_data.

      ENDAT.

    ENDLOOP.

    " Tri
    SORT me->ms_work_area_private-t_display_data BY batch_number request_number ot_number.

  ENDMETHOD.

  METHOD build_hierarchy_node.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_display_data TYPE lcl_main_tree=>tt_display_data.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_display_data TYPE lcl_main_tree=>ts_display_data.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
        lo_alv_tree_util TYPE REF TO zcl_gui_alv_tree_util.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    REFRESH : me->ms_display_element-data-t_display_data.

    " -----------------------------------------------------------
    " Extraction des données à afficher
    " -----------------------------------------------------------

    " Création Instance Utilitaire Gestion ALV Tree
    CREATE OBJECT lo_alv_tree_util
      EXPORTING
        io_alv_tree = me->ms_display_element-display_element-o_alv_tree.

    " Initialisation donner afficher par l'ALV Tree
    me->ms_display_element-data-t_display_data[] = me->ms_work_area_private-t_display_data[].

    " -----------------------------------------------------------
    " Contrôle présence de données
    " -----------------------------------------------------------

    IF  me->ms_display_element-data-t_display_data[] IS INITIAL.
      " Aucune données à afficher
      ""  --> Retourne code retour en erreur
      rv_subrc = 8.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Alimentation automatique des données dans l'ALV Tree
    " -----------------------------------------------------------

    " Alimentation des Noeuds de l'ALV
    zcl_gui_alv_tree_util=>alv_tree_populate_auto(
      EXPORTING
        it_alv_tree_data  = me->ms_display_element-data-t_display_data
        it_hierarchy      = me->ms_display_element-display_element-t_hierarchy
      IMPORTING
        et_level_node_key = me->mt_level_node_key
      CHANGING
        co_alv_tree       = me->ms_display_element-display_element-o_alv_tree
    ).

    " -----------------------------------------------------------
    " Application propriété lecture-seule
    " -----------------------------------------------------------

    " Applique lecture-seule
    me->_read_only_apply( ).

    " -----------------------------------------------------------
    " Etend jusqu'au Noeud indiqué
    " -----------------------------------------------------------

    LOOP AT me->mt_level_node_key ASSIGNING FIELD-SYMBOL(<lfs_s_node_key>)
                                      WHERE parent_node_key IS INITIAL.

      me->ms_display_element-display_element-o_alv_tree->expand_node(
        EXPORTING
          i_node_key          = <lfs_s_node_key>-node_key
          i_level_count       = 10
          i_expand_subtree    = abap_true
        EXCEPTIONS
          failed              = 1
          illegal_level_count = 2
          cntl_system_error   = 3
          node_not_found      = 4
          cannot_expand_leaf  = 5
          OTHERS              = 6
      ).

    ENDLOOP.

  ENDMETHOD.

  METHOD _read_only_apply.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          lo_display_data_batch TYPE REF TO lcl_main_tree=>ts_display_data.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_outtab_line TYPE lcl_main_tree=>ts_display_data.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_data     TYPE string,
      lv_readonly TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Modifie propriété Lecture-Seule
    " -----------------------------------------------------------

    LOOP AT me->mt_level_node_key
      ASSIGNING FIELD-SYMBOL(<lfs_s_level_node_key>).

      " Récupération données affichées
      me->ms_display_element-display_element-o_alv_tree->get_outtab_line(
        EXPORTING
          i_node_key     = <lfs_s_level_node_key>-node_key
        IMPORTING
          e_outtab_line  = ls_outtab_line
        EXCEPTIONS
          node_not_found = 1
          OTHERS         = 2
      ).
      IF sy-subrc NE 0.
        " Noeud inexistant
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      " Modifie les propriétés lecture-seule
      CASE <lfs_s_level_node_key>-fieldname.

        WHEN 'OT_NUMBER'.                                   "#EC NOTEXT
          " OT

        WHEN 'BATCH_NUMBER'.                                "#EC NOTEXT
          " Lot
          ""  --> Détermine Lecture seule basé sur Transport effectué
          lv_readonly = SWITCH #(
            ls_outtab_line-transport_real_date
              WHEN '00000000' THEN abap_false               "#EC NOTEXT
                              ELSE abap_true
          ).

          IF lv_readonly EQ abap_false.
            ""  --> Détermine lecture Seule basée sur Toutes Demandes Validées
            READ TABLE me->ms_display_element-data-t_display_data
              WITH KEY batch_number = <lfs_s_level_node_key>-node_level_key
              TRANSPORTING NO FIELDS BINARY SEARCH.
            IF sy-subrc EQ 0.
              " Au moins une occurence
              ""  --> Parcours toutes les Demandes de ce Lot
              LOOP AT me->ms_display_element-data-t_display_data
                 ASSIGNING FIELD-SYMBOL(<lfs_s_display_data>) FROM sy-tabix.

                IF <lfs_s_display_data>-batch_number NE <lfs_s_level_node_key>-node_level_key.
                  " On ne traite plus le même Lot
                  ""  --> Arrêt de la boucle
                  EXIT.

                ENDIF.

                IF <lfs_s_display_data>-request_number IS INITIAL
                OR NOT <lfs_s_display_data>-ot_number  IS INITIAL.
                  " Pas de Demande // Il s'agit de l'entrée du Lot || Niveau OT
                  ""  --> Stock l'entrée du Lot
*                  lo_display_data_batch = REF #( <lfs_s_display_data> ).

                  ""  --> Passe à l'itération suivante
                  CONTINUE.

                ENDIF.

                IF <lfs_s_display_data>-request_validated EQ abap_false.
                  " Demande non Validée
                  ""  --> Désactive Validation Lot
                  lv_readonly = abap_true.

                  ""  --> Arrêt de la boucle
                  EXIT.

                ENDIF.

              ENDLOOP.

              ""  --> Détermination de l'icône à appliquer
              lv_data = SWITCH #( lv_readonly
                  WHEN abap_false THEN text-iva ELSE text-wva
                ).

              ""  --> Change Indicateur Demande Validée
              me->ms_display_element-display_element-o_alv_tree->change_item(
                EXPORTING
                  i_node_key     = <lfs_s_level_node_key>-node_key
                  i_fieldname    = 'REQUEST_VALIDATED'      "#EC NOTEXT
                  i_data         = xsdbool( lv_readonly EQ abap_false )
                EXCEPTIONS
                  node_not_found = 1
                  OTHERS         = 2
              ).

              ""  --> Change Icône Demande Validée
              me->ms_display_element-display_element-o_alv_tree->change_item(
                EXPORTING
                  i_node_key     = <lfs_s_level_node_key>-node_key
                  i_fieldname    = 'REQUEST_VALIDATED_ICON' "#EC NOTEXT
                  i_data         = lv_data
                EXCEPTIONS
                  node_not_found = 1
                  OTHERS         = 2
              ).

            ENDIF.

          ENDIF.

          ""  --> (Dés)Active le bouton "Valider"
          me->ms_display_element-display_element-o_alv_tree->change_item(
            EXPORTING
              i_node_key     = <lfs_s_level_node_key>-node_key
              i_fieldname    = 'BATCH_VALIDATED_ICON'       "#EC NOTEXT
              i_data         = ls_outtab_line-batch_validated_icon
              is_item_layout = VALUE #(
                disabled   = lv_readonly
                u_disabled = abap_true
              )
            EXCEPTIONS
              node_not_found = 1
              OTHERS         = 2
          ).

        WHEN 'REQUEST_NUMBER'.                              "#EC NOTEXT
          " Requête
          ""  --> Détermine Lecture seule basé sur Transport effectué
          lv_readonly = SWITCH #(
            ls_outtab_line-transport_real_date
              WHEN '00000000' THEN abap_false               "#EC NOTEXT
                              ELSE abap_true
          ).

          ""  --> (Dés)Active le bouton "Contrôle"
          me->ms_display_element-display_element-o_alv_tree->change_item(
            EXPORTING
              i_node_key     = <lfs_s_level_node_key>-node_key
              i_fieldname    = 'REQUEST_CHECK_ICON'         "#EC NOTEXT
              i_data         = ls_outtab_line-request_check_icon
              is_item_layout = VALUE #(
                disabled   = lv_readonly
                u_disabled = abap_true
              )
            EXCEPTIONS
              node_not_found = 1
              OTHERS         = 2
          ).

          ""  --> (Dés)Active le bouton "Validation"
          me->ms_display_element-display_element-o_alv_tree->change_item(
            EXPORTING
              i_node_key     = <lfs_s_level_node_key>-node_key
              i_fieldname    = 'REQUEST_VALIDATED_ICON'     "#EC NOTEXT
              i_data         = ls_outtab_line-request_validated_icon
              is_item_layout = VALUE #(
                disabled   = lv_readonly
                u_disabled = abap_true
              )
            EXCEPTIONS
              node_not_found = 1
              OTHERS         = 2
          ).

        WHEN OTHERS.
          " Autre
          ""  --> Passe à l'itération suivante
          CONTINUE.

      ENDCASE.

    ENDLOOP.

    " Mise à jour de l'affichage
    me->ms_display_element-display_element-o_alv_tree->update_calculations( ).

  ENDMETHOD.

  METHOD request_check.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle de la Demande
    " -----------------------------------------------------------

    " Traitement de Contrôle
    zcl_transport_request_celio=>request_check( iv_request_number ).

  ENDMETHOD.

  METHOD request_validation.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_outtab_line TYPE lcl_main_tree=>ts_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération données actuelles
    " -----------------------------------------------------------

    " Récupération données actuelles
    me->ms_display_element-display_element-o_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = iv_node_key
      IMPORTING
        e_outtab_line  = ls_outtab_line
      EXCEPTIONS
        node_not_found = 1
        OTHERS         = 2
    ).
    IF sy-subrc NE 0.
      " Noeud inexistant
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Valide la Demande
    " -----------------------------------------------------------

    " Validation de la Demande
    DATA(ls_request) = zcl_transport_request_celio=>request_validation(
        iv_request_number  = ls_outtab_line-request_number
        iv_validation_code = SWITCH #( ls_outtab_line-request_validated
          WHEN abap_true THEN zcl_transport_request_celio=>mc_validation_code-cancel
                         ELSE zcl_transport_request_celio=>mc_validation_code-validate
        )
        iv_supervalidation_code = SWITCH #( ls_outtab_line-request_validated
          WHEN abap_true THEN zcl_transport_request_celio=>mc_validation_code-cancel
                         ELSE zcl_transport_request_celio=>mc_validation_code-validate
        )
    ).

    " -----------------------------------------------------------
    " Modifie l'affichage
    " -----------------------------------------------------------

    " Données de Validation
    ls_outtab_line-validated_by      = ls_request-zedvaluser.
    ls_outtab_line-validated_date    = ls_request-zedvaldate.
    ls_outtab_line-validated_time    = ls_request-zedvaltime.
    ls_outtab_line-request_validated = xsdbool( ls_request-zedvalcode EQ abap_false ).

    " Icône Validation
    ls_outtab_line-request_validated_icon = SWITCH #( ls_outtab_line-request_validated
      WHEN abap_true THEN text-iva ELSE text-wva
    ).

    " MàJ affichage
    me->_update_data_item(
    iv_node_key          = iv_node_key
      is_outtab_line     = ls_outtab_line
      it_field_to_update = VALUE #(
        ( |VALIDATED_BY| )                                  "#EC NOTEXT
        ( |VALIDATED_DATE| )                                "#EC NOTEXT
        ( |VALIDATED_TIME| )                                "#EC NOTEXT
        ( |REQUEST_VALIDATED| )                             "#EC NOTEXT
        ( |REQUEST_VALIDATED_ICON| )                        "#EC NOTEXT
      )
    ).

    " -----------------------------------------------------------
    " Applique Lecture-Seule
    " -----------------------------------------------------------

    me->_read_only_apply( ).

  ENDMETHOD.

  METHOD request_display.
***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_batch   TYPE bdcdata_tab,
      lt_trkorr  TYPE trkorrs,
      lt_message TYPE wdkmsg_tty.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
      ls_options               TYPE ctu_params,
      ls_transport_date_wished TYPE swu_orgtim.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_line    TYPE numc2,
      lv_message TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Préparation dossier Batch-Input
    " -----------------------------------------------------------

    lt_batch = VALUE #(
      (
        " Ecran de ZBC_REQUEST_DISPLAY
        program  = 'Z_M_BC_TRANSPORT_REQUEST'               "#EC NOTEXT
        dynpro   = '1000'                                   "#EC NOTEXT
        dynbegin = abap_true
      )
      (
      " Numéro de Demande
        fnam = 'ZTBREQUEST-ZEDREQNB'                        "#EC NOTEXT
        fval = iv_request_number
      )
      (
      " Validation
        fnam = 'BDC_OKCODE'                                 "#EC NOTEXT
        fval = '=VALI'                                      "#EC NOTEXT
      )
    ).

    " -----------------------------------------------------------
    " Exécution dossier Batch-Input
    " -----------------------------------------------------------

    " Mode Asychrone / Pas d'affichage
    ls_options-updmode  = 'A'.                              "#EC NOTEXT
    ls_options-dismode  = 'E'.                              "#EC NOTEXT
    ls_options-racommit = abap_true.

    " Appel de la Transaction
    CALL TRANSACTION 'ZBC_REQUEST_DISPLAY'                  "#EC NOTEXT
             WITHOUT AUTHORITY-CHECK
               USING lt_batch
       MESSAGES INTO lt_message OPTIONS FROM ls_options.

  ENDMETHOD.

  METHOD batch_validation.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_outtab_line TYPE lcl_main_tree=>ts_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération données actuelles
    " -----------------------------------------------------------

    " Récupération données actuelles
    me->ms_display_element-display_element-o_alv_tree->get_outtab_line(
      EXPORTING
        i_node_key     = iv_node_key
      IMPORTING
        e_outtab_line  = ls_outtab_line
      EXCEPTIONS
        node_not_found = 1
        OTHERS         = 2
    ).
    IF sy-subrc NE 0.
      " Noeud inexistant
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Valide le Lot
    " -----------------------------------------------------------

    " Validation de la Demande
    DATA(ls_request_batch) = zcl_transport_request_batch=>batch_validation(
        iv_batch           = ls_outtab_line-batch_number
        iv_validation_code = xsdbool( ls_outtab_line-batch_validated EQ abap_false )
    ).

    " -----------------------------------------------------------
    " Modifie l'affichage
    " -----------------------------------------------------------

    " Données de Validation
    ls_outtab_line-validated_by    = ls_request_batch-zedsupvaluser.
    ls_outtab_line-validated_date  = ls_request_batch-zedsupvaldate.
    ls_outtab_line-validated_time  = ls_request_batch-zedsupvaltime.
    ls_outtab_line-batch_validated = ls_request_batch-zedvalidated.

    " Icône Validation
    ls_outtab_line-batch_validated_icon = SWITCH #( ls_outtab_line-batch_validated
      WHEN abap_true THEN text-iva ELSE text-wva
    ).

    " MàJ affichage
    me->_update_data_item(
    iv_node_key          = iv_node_key
      is_outtab_line     = ls_outtab_line
      it_field_to_update = VALUE #(
        ( |VALIDATED_BY| )                                  "#EC NOTEXT
        ( |VALIDATED_DATE| )                                "#EC NOTEXT
        ( |VALIDATED_TIME| )                                "#EC NOTEXT
        ( |BATCH_VALIDATED| )                               "#EC NOTEXT
        ( |BATCH_VALIDATED_ICON| )                          "#EC NOTEXT
      )
    ).

    " -----------------------------------------------------------
    " Applique Lecture-Seule
    " -----------------------------------------------------------

    me->_read_only_apply( ).

  ENDMETHOD.

  METHOD _update_data_item.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_value> TYPE any.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Modifie les données
    " -----------------------------------------------------------

    LOOP AT it_field_to_update ASSIGNING FIELD-SYMBOL(<lfs_s_field_to_update>).

      " Initialisation pointeur sur la valeur du champ
      ASSIGN COMPONENT <lfs_s_field_to_update>
          OF STRUCTURE is_outtab_line TO <lfs_value>.
      IF sy-subrc NE 0.
        " Aucune correspondance
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      " Mise à jour table interne ALV
      me->ms_display_element-display_element-o_alv_tree->change_item(
        EXPORTING
          i_node_key     = iv_node_key
          i_fieldname    = CONV #( <lfs_s_field_to_update> )
          i_data         = <lfs_value>
          i_u_data       = abap_true
        EXCEPTIONS
          node_not_found = 1
          OTHERS         = 2
      ).

    ENDLOOP.

    " Modification effectuée
    ""  --> MàJ affichage
    me->ms_display_element-display_element-o_alv_tree->update_calculations( ).

  ENDMETHOD.

ENDCLASS.

*----------------------------------------------------------------------*
*       CLASS LCL_MAIN IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main IMPLEMENTATION.

  METHOD initialization.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Création instance Principale
    " -----------------------------------------------------------

    ro_instance = lcl_main=>factory( ).
    IF NOT ro_instance IS BOUND.
      " Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle autorisation
    " -----------------------------------------------------------

    " Contrôle autorisation
    ro_instance->autorithy_check( ).

  ENDMETHOD.

  METHOD factory.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Génération Instance
    " -----------------------------------------------------------

    " Création instance principale
    ro_instance = NEW #( ).

  ENDMETHOD.

  METHOD criticity_display.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_trkorr TYPE trkorrs,
      lv_critic TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Affichage Criticité
    " -----------------------------------------------------------

    IF NOT iv_transport_number IS INITIAL.
      " Initialisation table OT
      lt_trkorr = VALUE trkorrs( ( iv_transport_number ) ).

    ENDIF.

    " Affichage Détail Criticité
    CALL FUNCTION 'Z_REQUEST_CRITICITY_DISPLAY'
      EXPORTING
        it_trkorr         = lt_trkorr
        iv_batch_number   = iv_batch_number
        iv_request_number = iv_request_number
      IMPORTING
        ev_critic         = lv_critic.

    IF lv_critic EQ abap_false.
      " Pas de criticité
      ""  --> Criticité manuelle
      MESSAGE s025(ztools) DISPLAY LIKE if_msg_output=>msgtype_warning.

    ENDIF.

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Attribut
    " -----------------------------------------------------------

    " Critère de sélection
    ""  --> Date
    me->ms_selection_criteria-criteria-or_tdate = REF #( s_tdate[] ).

    ""  --> Lot
    me->ms_selection_criteria-criteria-or_batch = REF #( s_batch[] ).

    ""  --> Visualisation
    me->ms_selection_criteria-visualisation-ov_display_ot   = REF #( p_dot ).
    me->ms_selection_criteria-visualisation-ov_display_all  = REF #( p_all ).
    me->ms_selection_criteria-visualisation-ov_only_valided = REF #( p_oval ).
    me->ms_selection_criteria-visualisation-ov_only_unvalid = REF #( p_toval ).

    TRY.
        " Hardcode
        me->ms_work_area_private-o_hardcode =
          zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ). "#EC NOTEXT

      CATCH zcx_hardcode.
        " Pas de Hardcode
        ""  --> Arrêt de la transaction
        MESSAGE e017(ztools).
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD autorithy_check.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Contrôle utilisateur Super-Validateur ?
        " -----------------------------------------------------------

        IF sy-uname NOT IN me->ms_work_area_private-o_hardcode->attribute_value_get( "#EC NOTEXT
           iv_parameter_name = 'CONFIGURATION'              "#EC NOTEXT
           iv_attribute_name = 'SUPER_VALIDATOR_USER'       "#EC NOTEXT
          )-range.
          " Utilisateur non autorisé
          ""  --> Arrêt de la transaction
          MESSAGE e017(ztools).
          RETURN.

        ENDIF.

      CATCH zcx_hardcode.
        " Erreur
        ""  --> Arrêt de la transaction
        MESSAGE e017(ztools).
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD process.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " Suivant l'évènement
    CASE iv_process.

      WHEN lcl_main=>mc_process-display.
        " -----------------------------------------------------------
        " Récupération et Affichage des Lots
        " -----------------------------------------------------------

        " Récupération des Lots
        IF me->batch_request_get( ) IS INITIAL.
          " Affichage des Lots
          me->batch_request_display( ).

        ENDIF.

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD batch_request_get.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
          lt_cofile_lines TYPE tr_cofilines.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_sql_cond TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Critère dynamique
    " -----------------------------------------------------------

    " Suivant les Lots à afficher
    CASE abap_true.

      WHEN me->ms_selection_criteria-visualisation-ov_display_all->*.
        " Toutes les Demandes
        ""  --> Pas de filtre supplémentaire
        CLEAR : lv_sql_cond.

      WHEN me->ms_selection_criteria-visualisation-ov_only_valided->*.
        " Uniquement Validées
        ""  --> Ajout filtre sur Utilisateur Validateur <> Vide
        lv_sql_cond = | ZEDSUPVALUSER <> @space |.          "#EC NOTEXT

      WHEN me->ms_selection_criteria-visualisation-ov_only_unvalid->*.
        " Uniquement Non Validées
        ""  --> Ajout filtre sur Utilisateur Validateur = Vide
        lv_sql_cond = | ZEDSUPVALUSER = @space |.           "#EC NOTEXT

      WHEN OTHERS.
        " Autre
        ""  --> Pas de filtre supplémentaire
        CLEAR : lv_sql_cond.

    ENDCASE.

    " -----------------------------------------------------------
    " Récupération des Lots
    " -----------------------------------------------------------

    " Récupération des Lots
    SELECT zedbatch       AS batch_number,
           zedbatch_descr AS batch_description,
           zedtrpdate     AS transport_wished_date,
           zedtrptime     AS transport_wished_time,
           zedvalidated   AS validated,
           zedsupvaluser  AS validated_by,
           zedsupvaldate  AS validated_date,
           zedsupvaltime  AS validated_time,
           zedtrtdate     AS transport_real_date,
           zedtrttime     AS transport_real_time,
           zedcritic      AS critic,
           zedeligible    AS express
      FROM ztbrequest_batch
     WHERE zedbatch   IN @me->ms_selection_criteria-criteria-or_batch->*
       AND zedtrpdate IN @me->ms_selection_criteria-criteria-or_tdate->*
       AND (lv_sql_cond)
      INTO TABLE @me->ms_work_area_private-t_batch_data.
    IF sy-subrc NE 0.
      " Aucun Lot correspondant
      ""  --> Affiche message
      MESSAGE s018(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
      rv_subrc = 2.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération des Demandes associées
    " -----------------------------------------------------------

    " Récupération des Demandes
    SELECT zedreqnb       AS request_number,
           zedtrpdate     AS transport_wished_date,
           zedtrptime     AS transport_wished_time,
           zedvalcode     AS validated,
           zedvaluser     AS validated_by,
           zedvaldate     AS validated_date,
           zedvaltime     AS validated_time,
           zedtrtdate     AS transport_real_date,
           zedtrttime     AS transport_real_time,
           zedimport      AS transport_status,
           zedreqcritic   AS critic,
           zedeligible    AS express,
           zedreqbatch    AS batch_number
      FROM ztbrequest FOR ALL ENTRIES IN @me->ms_work_area_private-t_batch_data
     WHERE zedreqbatch EQ @me->ms_work_area_private-t_batch_data-batch_number
      INTO TABLE @me->ms_work_area_private-t_request_data.
    IF  sy-subrc EQ 0
    AND me->ms_selection_criteria-visualisation-ov_display_ot->* EQ abap_true.
      " -----------------------------------------------------------
      " Récupération OTs associées
      " -----------------------------------------------------------

      ""  --> Récupération des OTs
      SELECT zedreqnb    AS request_number,
             zedtrpord   AS ot_number,
             zedwording  AS description,
             zedcritic   AS critic
        FROM ztborderseq AS main
                 INNER JOIN e070 ON e070~trkorr EQ main~zedtrpord
         FOR ALL ENTRIES IN @me->ms_work_area_private-t_request_data
          WHERE zedreqnb EQ @me->ms_work_area_private-t_request_data-request_number
         INTO CORRESPONDING FIELDS OF TABLE @me->ms_work_area_private-t_ot_data.

    ENDIF.


    IF NOT me->ms_work_area_private-t_ot_data[] IS INITIAL.
      " -----------------------------------------------------------
      " Récupération données des OTs
      " -----------------------------------------------------------

      LOOP AT me->ms_work_area_private-t_ot_data
          ASSIGNING FIELD-SYMBOL(<lfs_s_ot_data>).

        " Récupération données d'Import
        lt_cofile_lines = zcl_transport_request=>transport_request_cofile_get(
          <lfs_s_ot_data>-ot_number
        ).
        IF lt_cofile_lines[] IS INITIAL.
          " Aucune données
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

        " Tri pour suppression doublon (pour conserver l'entrée la plus récente)
        DELETE lt_cofile_lines WHERE tarsystem NE 'PE1'.    "#EC NOTEXT
        SORT lt_cofile_lines BY function trdate DESCENDING trtime DESCENDING.
        DELETE ADJACENT DUPLICATES FROM lt_cofile_lines COMPARING function.

        " Récupération données dernier Import en Production
        READ TABLE lt_cofile_lines WITH KEY function  = cl_cts_change_tracking_api=>co_import_status_imported
                                  ASSIGNING FIELD-SYMBOL(<lfs_s_cofile_lines>)
                                     BINARY SEARCH.
        IF sy-subrc EQ 0.
          " Correspondance trouvée
          ""  --> Initialisation données
          <lfs_s_ot_data>-transport_real_date = <lfs_s_cofile_lines>-trdate.
          <lfs_s_ot_data>-transport_real_time = <lfs_s_cofile_lines>-trtime.

        ENDIF.

        TRY.
            " Statut
            <lfs_s_ot_data>-transport_status = lt_cofile_lines[
              function  = if_sedi_constants=>status_type_generate
            ]-retcode.

          CATCH cx_sy_itab_line_not_found.
            " Aucune correspondance
        ENDTRY.

        " Réinitialisation
        REFRESH : lt_cofile_lines.

      ENDLOOP.

    ENDIF.

  ENDMETHOD.

  METHOD batch_request_display.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_batch_request TYPE lcl_main_tree=>tt_batch_request.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          lo_alv_tree TYPE REF TO lcl_main_tree.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Préparation des données
    " -----------------------------------------------------------

    DATA : ls_batch_request TYPE lcl_main_tree=>ts_batch_request.

    LOOP AT me->ms_work_area_private-t_batch_data
        ASSIGNING FIELD-SYMBOL(<lfs_s_batch_data>).

      " Initialisation données du Lot
      ls_batch_request-batch_number                = <lfs_s_batch_data>-batch_number.
      ls_batch_request-batch_critic                = <lfs_s_batch_data>-critic.
      ls_batch_request-batch_express               = <lfs_s_batch_data>-express.
      ls_batch_request-batch_validated             = <lfs_s_batch_data>-validated.
      ls_batch_request-batch_description           = <lfs_s_batch_data>-batch_description.
      ls_batch_request-batch_validated_by          = <lfs_s_batch_data>-validated_by.
      ls_batch_request-batch_validated_date        = <lfs_s_batch_data>-validated_date.
      ls_batch_request-batch_validated_time        = <lfs_s_batch_data>-validated_time.
      ls_batch_request-batch_transport_real_date   = <lfs_s_batch_data>-transport_real_date.
      ls_batch_request-batch_transport_real_time   = <lfs_s_batch_data>-transport_real_time.
      ls_batch_request-batch_transport_wished_date = <lfs_s_batch_data>-transport_wished_date.
      ls_batch_request-batch_transport_wished_time = <lfs_s_batch_data>-transport_wished_time.

      " Récupération position première itération du Lot
      READ TABLE me->ms_work_area_private-t_request_data
        WITH KEY batch_number = <lfs_s_batch_data>-batch_number
        TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc EQ 0.
        " Au moins une correspondance
        ""  --> Initialisation données des Demandes
        LOOP AT me->ms_work_area_private-t_request_data
          ASSIGNING FIELD-SYMBOL(<lfs_s_request_data>) FROM sy-tabix.

          IF <lfs_s_request_data>-batch_number NE <lfs_s_batch_data>-batch_number.
            " On ne traite plus le même Lot
            ""  --> Arrêt de la boucle
            EXIT.

          ENDIF.

          " Initialisation données Demande
          ls_batch_request-request_number                = <lfs_s_request_data>-request_number.
          ls_batch_request-request_critic                = <lfs_s_request_data>-critic.
          ls_batch_request-request_express               = <lfs_s_request_data>-express.
          ls_batch_request-request_validated             = xsdbool( <lfs_s_request_data>-validated EQ abap_false ).
          ls_batch_request-request_validated_by          = <lfs_s_request_data>-validated_by.
          ls_batch_request-request_validated_date        = <lfs_s_request_data>-validated_date.
          ls_batch_request-request_validated_time        = <lfs_s_request_data>-validated_time.
          ls_batch_request-request_transport_status      = <lfs_s_request_data>-transport_status.
          ls_batch_request-request_transport_real_date   = <lfs_s_request_data>-transport_real_date.
          ls_batch_request-request_transport_real_time   = <lfs_s_request_data>-transport_real_time.
          ls_batch_request-request_transport_wished_date = <lfs_s_request_data>-transport_wished_date.
          ls_batch_request-request_transport_wished_time = <lfs_s_request_data>-transport_wished_time.

          " Récupération position première itération de la Demande
          READ TABLE me->ms_work_area_private-t_ot_data
            WITH KEY request_number = <lfs_s_request_data>-request_number
            TRANSPORTING NO FIELDS BINARY SEARCH.
          IF sy-subrc EQ 0.
            " Au moins une correspondance
            ""  --> Initialisation données des Demandes
            LOOP AT me->ms_work_area_private-t_ot_data
              ASSIGNING FIELD-SYMBOL(<lfs_s_ot_data>) FROM sy-tabix.

              IF <lfs_s_request_data>-request_number NE <lfs_s_ot_data>-request_number.
                " On ne traite plus la même Demande
                ""  --> Arrêt de la boucle
                EXIT.

              ENDIF.

              " Initialisation données OT
              ls_batch_request-ot_number              = <lfs_s_ot_data>-ot_number.
              ls_batch_request-ot_critic              = <lfs_s_ot_data>-critic.
              ls_batch_request-ot_description         = <lfs_s_ot_data>-description.
              ls_batch_request-ot_transport_status    = <lfs_s_ot_data>-transport_status.
              ls_batch_request-ot_transport_real_date = <lfs_s_ot_data>-transport_real_date.
              ls_batch_request-ot_transport_real_time = <lfs_s_ot_data>-transport_real_time.

              " Ajout de l'entrée
              INSERT ls_batch_request INTO TABLE lt_batch_request.

            ENDLOOP.

          ELSE.
            " Ajout de l'entrée
            INSERT ls_batch_request INTO TABLE lt_batch_request.

          ENDIF.

        ENDLOOP.

      ELSE.
        " Aucune Demande
        ""  --> Ajout des données
        INSERT ls_batch_request INTO TABLE lt_batch_request.

      ENDIF.

      CLEAR : ls_batch_request.

    ENDLOOP.

    " -----------------------------------------------------------
    " Création instance Affichage
    " -----------------------------------------------------------

    " Création instance
    CREATE OBJECT lo_alv_tree
      EXPORTING
        io_main          = me
        iv_display_ot    = me->ms_selection_criteria-visualisation-ov_display_ot->*
        it_batch_request = lt_batch_request.

    " -----------------------------------------------------------
    " Affichage des données
    " -----------------------------------------------------------

    " Affichage
    lo_alv_tree->display( ).

  ENDMETHOD.

  METHOD user_command_2000.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Gestion Action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE sy-ucomm.

      WHEN lcl_main=>mc_event-back
        OR lcl_main=>mc_event-exit
        OR lcl_main=>mc_event-leave.
        " Retour / Arrêt
*      IF go_main->is_changed( ) EQ abap_true.
*        " Données modifiées non persistée
*        ""  --> Affiche popup confirmation
*        IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
*          " Oui
*          ""  --> Sauvegarde
*          go_main->save( ).
*
*        ENDIF.
*
*      ENDIF.

        CASE sy-ucomm.

          WHEN lcl_main=>mc_event-leave.
            "  Arrêt
            ""  --> Interruption du traitement
            LEAVE PROGRAM.

          WHEN lcl_main=>mc_event-cancel.
            " Interrompre
            ""  --> Ne rien faire

          WHEN OTHERS.
            " Retour
            ""  --> Retourne à l'écran précédent
*          go_main->event_raise( lcl_main=>mc_event-display_leave ).
            LEAVE TO SCREEN 0.                              "#EC NOTEXT

        ENDCASE.

      WHEN lcl_main=>mc_event-save.
        " Sauvegarde
        ""  --> Sauvegarde
        me->save_to_db( ).

      WHEN OTHERS.
        " Autres

    ENDCASE.


  ENDMETHOD.

  METHOD save_to_db.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    "
    " -----------------------------------------------------------



  ENDMETHOD.

ENDCLASS.


***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
DATA : go_main TYPE REF TO lcl_main.

***==================================================================***
**                           INITIALIZATION                           **
***==================================================================***
INITIALIZATION.
  " Initialisation
  go_main = lcl_main=>initialization( ).

***==================================================================***
**                         AT SELECTION-SCREEN                        **
***==================================================================***
AT SELECTION-SCREEN.


***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***
AT SELECTION-SCREEN OUTPUT.


***==================================================================***
**                AT SELECTION-SCREEN ON VALUE REQUEST                **
***==================================================================***


***==================================================================***
**                         START-OF-SELECTION                         **
***==================================================================***
START-OF-SELECTION.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_subrc TYPE sy-subrc.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Traitement principal
  " -----------------------------------------------------------

  " Traitement principal
  go_main->process( lcl_main=>mc_process-display ).

END-OF-SELECTION.

***------------------------------------------------------------------***
**                            ROUTINES                                **
***------------------------------------------------------------------***

*&---------------------------------------------------------------------*
*&      Module  STATUS_2000  OUTPUT
*&---------------------------------------------------------------------*
*       PBO
*----------------------------------------------------------------------*
MODULE status_2000 OUTPUT.

  " -----------------------------------------------------------
  " Initialisation barre d'état
  " -----------------------------------------------------------

  SET PF-STATUS 'PF_STATUS_2000'.                           "#EC NOTEXT
  SET TITLEBAR 'TITLEBAR_2000'.                             "#EC NOTEXT

ENDMODULE.

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_2000  INPUT
*&---------------------------------------------------------------------*
*       PAI
*----------------------------------------------------------------------*
MODULE user_command_2000 INPUT.

  " -----------------------------------------------------------
  " Gestion Action Utilisateur
  " -----------------------------------------------------------

  go_main->user_command_2000( ).

ENDMODULE.
