class ZCL_TRANSPORT_REQUEST_BATCH definition
  public
  final
  create public .

public section.

  class-methods CLASS_CONSTRUCTOR .
  class-methods BATCH_GET
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RS_REQUEST_BATCH) type ZTBREQUEST_BATCH .
  class-methods BATCH_CREATE
    importing
      !IV_EXTENDED_MODE type XSDBOOLEAN default ABAP_FALSE
      !IV_DISPLAY_AT_POPUP type XSDBOOLEAN default ABAP_TRUE
      !IV_COMMIT_IMMEDIATE type XSDBOOLEAN optional
    exporting
      !EV_CANCEL type XSDBOOLEAN
      !EV_EXISTING type XSDBOOLEAN
    returning
      value(RS_REQUEST_TRANSPORT_BATCH) type ZST_REQUEST_TRANSPORT_BATCH .
  class-methods BATCH_COMMIT_DB
    importing
      !IV_BATCH type ZEDREQBATCH
      !IV_COMMIT type XSDBOOLEAN optional
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods BATCH_VALIDATION
    importing
      !IV_BATCH type ZEDREQBATCH
      !IV_VALIDATION_CODE type XSDBOOLEAN
    exporting
      !EV_CHANGED type XSDBOOLEAN
    returning
      value(RS_REQUEST_BATCH) type ZTBREQUEST_BATCH .
  class-methods BATCH_LOCK
    importing
      !IV_BATCH type ZEDREQBATCH
    exporting
      !ES_RETURN type WSRS_RETURN
    returning
      value(RV_LOCKED) type XSDBOOLEAN .
  class-methods BATCH_UNLOCK
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RV_UNLOCKED) type XSDBOOLEAN .
  class-methods BATCH_LOCK_CHECK
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RV_IS_LOCKED) type XSDBOOLEAN .
protected section.
PRIVATE SECTION.

  CLASS-DATA : mo_hardcode TYPE REF TO zcl_hardcode.
  CLASS-DATA : mr_sval_user TYPE RANGE OF sy-uname.


  CONSTANTS:
    BEGIN OF mc_snro,
      nr_range_nr TYPE inri-nrrangenr VALUE '01',           "#EC NOTEXT
      object      TYPE inri-object VALUE 'ZED_RBATCH',      "#EC NOTEXT
    END OF   mc_snro .

  TYPES :
    BEGIN OF ts_batch_pending,
      zedbatch  TYPE ztbrequest_batch-zedbatch,
      o_batch   TYPE REF TO zcl_transport_batch_workflow,
      persisted TYPE xsdboolean,
    END OF   ts_batch_pending.

  TYPES : tt_batch_pending TYPE SORTED TABLE OF ts_batch_pending
                  WITH NON-UNIQUE KEY primary_key COMPONENTS zedbatch.
  CLASS-DATA : mt_batch_pending TYPE tt_batch_pending.
  CLASS-METHODS _batch_number_get
    RETURNING
      VALUE(rv_request_batch) TYPE zedreqbatch .
ENDCLASS.



CLASS ZCL_TRANSPORT_REQUEST_BATCH IMPLEMENTATION.


METHOD batch_commit_db.
***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF iv_batch IS INITIAL.
    " Lot vide
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Récupération Batch en Buffer
  " -----------------------------------------------------------

  " Récupération entrée dans le Buffer
  READ TABLE zcl_transport_request_batch=>mt_batch_pending
  WITH TABLE KEY zedbatch = iv_batch ASSIGNING FIELD-SYMBOL(<lfs_s_ztbrequest_batch>).
  IF sy-subrc NE 0.
    " Aucune correspondance
    ""  --> Arrêt du traitement
    rv_subrc = 5.
    RETURN.

  ENDIF.

  IF <lfs_s_ztbrequest_batch>-persisted EQ abap_false.
    " Lot Sauvegardé ?
    ""  --> Lot existant en DB ?
    SELECT SINGLE zedbatch FROM ztbrequest_batch
      INTO @DATA(ls_zedbatch)
     WHERE zedbatch EQ @iv_batch.
    IF sy-subrc EQ 0.
      " Lot existant
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Modification en DB
      " -----------------------------------------------------------

      " Modification en DB
      DATA(ls_request_batch) = <lfs_s_ztbrequest_batch>-o_batch->data_return( ).
      MODIFY ztbrequest_batch FROM ls_request_batch.

      IF iv_commit EQ abap_true.
        " Commit
        COMMIT WORK AND WAIT.

      ENDIF.

      " Lot sauvegardé
      <lfs_s_ztbrequest_batch>-persisted = abap_true.

    CATCH cx_root.
      " Erreur MàJ DB
      ""  --> Arrêt du traitement
      rv_subrc = 8.
      RETURN.

  ENDTRY.

ENDMETHOD.


METHOD batch_create.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_ztbrequest_batch TYPE ztbrequest_batch.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  CLEAR : ev_cancel.

  " -----------------------------------------------------------
  " Affichage PopUp Création de Lot
  " -----------------------------------------------------------

  " PopUp Création
  CALL FUNCTION 'Z_REQUEST_BATCH_CREATE'
    EXPORTING
      iv_extended_mode           = iv_extended_mode
      iv_display_at_popup        = iv_display_at_popup
    IMPORTING
      ev_cancel                  = ev_cancel
      ev_existing                = ev_existing
      es_request_transport_batch = rs_request_transport_batch.

  IF ev_cancel EQ abap_true.
    " Annulation
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Mise à jour Buffer
  " -----------------------------------------------------------

  " Initialisation données
  ls_ztbrequest_batch = CORRESPONDING #( rs_request_transport_batch ).

  IF ev_existing              EQ abap_false
  AND NOT ls_ztbrequest_batch IS INITIAL.
    " Insertion dans la table Buffer
    ls_ztbrequest_batch-zedbatch = rs_request_transport_batch-zedbatch =
      zcl_transport_request_batch=>_batch_number_get( ).
    ls_ztbrequest_batch-zedcreated_at = sy-datum.
    ls_ztbrequest_batch-zedcreated_by = sy-uname.
    INSERT CORRESPONDING #( ls_ztbrequest_batch ) INTO TABLE zcl_transport_request_batch=>mt_batch_pending.

  ENDIF.

  IF iv_commit_immediate EQ abap_true.
    " -----------------------------------------------------------
    " Mise à jour DB
    " -----------------------------------------------------------

    zcl_transport_request_batch=>batch_commit_db( ls_ztbrequest_batch-zedbatch ).

  ENDIF.

ENDMETHOD.


METHOD batch_get.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_batch TYPE REF TO zcl_transport_batch_workflow.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_batch_pending TYPE zcl_transport_request_batch=>ts_batch_pending.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération Lot présent en Buffer
      " -----------------------------------------------------------

      " Retourne les données présente en Buffer
      lo_batch = zcl_transport_request_batch=>mt_batch_pending[ iv_batch ]-o_batch.
      rs_request_batch = lo_batch->data_return( ).

    CATCH cx_sy_itab_line_not_found.
      " Lot non présent en Buffer
      TRY.
          " Récupération en cours
          lo_batch = zca_transport_batch_workflow=>agent->get_transient( iv_batch ).

        CATCH cx_os_object_not_found.
          " Pas d'encours
          TRY.
              ""  --> Récupération persistant
              lo_batch = zca_transport_batch_workflow=>agent->get_persistent( iv_batch ).

            CATCH cx_os_object_not_found.
              " Pas de persistant non plus

          ENDTRY.

      ENDTRY.

      IF NOT lo_batch IS BOUND.
        "" --> Ajout dans le buffer
        INSERT VALUE #(
          zedbatch = iv_batch
          o_batch  = lo_batch
        ) INTO TABLE zcl_transport_request_batch=>mt_batch_pending.

      ENDIF.

  ENDTRY.

ENDMETHOD.


METHOD batch_lock.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Blocage du Lot
  " -----------------------------------------------------------

  " Blocage du Lot
  CALL FUNCTION 'ENQUEUE_EZ_ZTBREQUEST_BA'
    EXPORTING
      mode_ztbrequest_batch = 'E'
      zedbatch              = iv_batch
    EXCEPTIONS
      foreign_lock          = 1
      system_failure        = 2
      error_message         = 3
      OTHERS                = 4.

  " Retourne booléen
  rv_locked = boolc( sy-subrc EQ 0 ).

  " Retourne message
  IF sy-subrc NE 0 AND es_return IS SUPPLIED.
    " Echec du Blocage
    ""  --> Alimentation message retour
    IF sy-msgid IS INITIAL.
      MESSAGE e316(cowipb) INTO es_return-message WITH iv_batch.
    ENDIF.
    CALL FUNCTION 'WSRS_MSG_EXCEPTION_CATCH'
      CHANGING
        px_return = es_return.

  ENDIF.

ENDMETHOD.


 METHOD batch_lock_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
   DATA :
         lt_enq TYPE wlf_seqg3_tab.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
   DATA :
         lv_subrc TYPE sy-subrc.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

   " -----------------------------------------------------------
   " Lecture entrée blocage
   " -----------------------------------------------------------

   " Lecture entrée blocage sur la Livraison
   CALL FUNCTION 'ENQUEUE_READ'
     EXPORTING
       gname                 = CONV seqg3-gname( 'ZTBREQUEST_BATCH' ) "#EC NOTEXT
       garg                  = CONV seqg3-garg( |{ sy-mandt }{ iv_batch }| )
       guname                = space
     IMPORTING
       subrc                 = lv_subrc
     TABLES
       enq                   = lt_enq
     EXCEPTIONS
       communication_failure = 1
       system_failure        = 2
       OTHERS                = 3.

   " Retourne booléen
   rv_is_locked = boolc( sy-subrc NE 0 OR NOT lt_enq[] IS INITIAL ).

 ENDMETHOD.


METHOD batch_unlock.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Déblocage du Lot
  " -----------------------------------------------------------

  " Déblocage du Lot
  CALL FUNCTION 'DEQUEUE_EZ_ZTBREQUEST_BA'
    EXPORTING
      mode_ztbrequest_batch = 'E'
      zedbatch              = iv_batch
    EXCEPTIONS
      error_message         = 1
      OTHERS                = 2.

  " Retourne booléen Livraison Bloquée
  rv_unlocked = boolc( zcl_transport_request_batch=>batch_lock_check( iv_batch ) EQ abap_false ).

ENDMETHOD.


METHOD batch_validation.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_valid TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Sélection des données
  " -----------------------------------------------------------

  " Récupération données de la Demande
  SELECT SINGLE * FROM ztbrequest_batch
                 WHERE zedbatch EQ @iv_batch
                  INTO @rs_request_batch.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF  iv_validation_code         EQ abap_true
  AND rs_request_batch-zedcritic EQ abap_true.
    " Demande Critique
    IF NOT sy-uname IN zcl_transport_request_batch=>mr_sval_user.
      " Demande Critique et Utilisateur non autorisé à la Valider
      ""  --> Rejet de la Validation
      MESSAGE s026(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Affichage PopUp Validation
    CALL FUNCTION 'Z_REQUEST_CRITICITY_ASK_VAL'
      EXPORTING
        iv_batch_number = iv_batch
      IMPORTING
        ev_validated    = lv_valid.

    IF lv_valid EQ abap_false.
      " Utilisateur n'a pas Validé la Demande
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Détermination champ à mettre à jour
  " -----------------------------------------------------------

  IF iv_validation_code EQ abap_true.
    " Validation
    rs_request_batch-zedvalidated  = abap_true.
    rs_request_batch-zedsupvaluser = sy-uname.
    rs_request_batch-zedsupvaldate = sy-datum.
    rs_request_batch-zedsupvaltime = sy-uzeit.

*    " Fin du WF de Validation
*    zcl_transport_batch_workflow=>workflow_validation_done(
*      CONV #( |{ rs_request_batch-zedbatch ALPHA = IN }| )
*    ).

  ELSE.
    " Annulation Validation
    ""  --> Réinitialise Zone de Validation
    CLEAR : rs_request_batch-zedvalidated,
            rs_request_batch-zedsupvaluser,
            rs_request_batch-zedsupvaldate,
            rs_request_batch-zedsupvaltime.

*    ""  --> Relance WF de Validation
*    zcl_transport_batch_workflow=>workflow_validation_start(
*      CONV #( |{ rs_request_batch-zedbatch ALPHA = IN }| )
*    ).

  ENDIF.

  " -----------------------------------------------------------
  " MàJ DB
  " -----------------------------------------------------------

  " Mise à jour en DB
  UPDATE ztbrequest_batch SET zedvalidated  = @rs_request_batch-zedvalidated,
                              zedsupvaluser = @rs_request_batch-zedsupvaluser,
                              zedsupvaldate = @rs_request_batch-zedsupvaldate,
                              zedsupvaltime = @rs_request_batch-zedsupvaltime
                        WHERE zedbatch EQ @iv_batch.

  " Indicateur changement effectuée
  ev_changed = abap_true.

  " Commit
  COMMIT WORK.

ENDMETHOD.


METHOD class_constructor.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Hardcode
      " -----------------------------------------------------------

      " Récupération Hardcode
      zcl_transport_request_batch=>mo_hardcode =
        zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ). "#EC NOTEXT

      TRY.
          " Détermination utilisateur SVAL
          zcl_transport_request_batch=>mr_sval_user =
            zcl_transport_request_batch=>mo_hardcode->attribute_value_get(
                iv_parameter_name = 'CONFIGURATION'         "#EC NOTEXT
                iv_attribute_name = 'SUPER_VALIDATOR_USER'  "#EC NOTEXT
            )-range.

        CATCH zcx_hardcode.

      ENDTRY.

    CATCH zcx_hardcode.
      " Pas de Hardcode

  ENDTRY.

ENDMETHOD.


METHOD _BATCH_NUMBER_GET.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Détermination Numéro de Lot
  " -----------------------------------------------------------

  CALL FUNCTION 'NUMBER_GET_NEXT'
    EXPORTING
      nr_range_nr             = zcl_transport_request_batch=>mc_snro-nr_range_nr
      object                  = zcl_transport_request_batch=>mc_snro-object
      quantity                = 1
    IMPORTING
      number                  = rv_request_batch
    EXCEPTIONS
      interval_not_found      = 1
      number_range_not_intern = 2
      object_not_found        = 3
      quantity_is_0           = 4
      quantity_is_not_1       = 5
      interval_overflow       = 6
      buffer_overflow         = 7
      OTHERS                  = 8.
  IF sy-subrc NE 0.
    " Erreur
    ""  --> Récupération Numéro de Lot le plus grand dans la table
    SELECT MAX( zedbatch ) FROM ztbrequest_batch INTO @rv_request_batch.
    IF rv_request_batch EQ '99999999'.                      "#EC NOTEXT
      " N° de requête dépassé
      ""  --> ToDo

    ENDIF.

  ENDIF.

ENDMETHOD.
ENDCLASS.
