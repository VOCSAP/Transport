class ZCL_TRANSPORT_REQUEST_WORKFLOW definition
  public
  final
  create protected

  global friends ZCB_TRANSPORT_REQUEST_WORKFLOW .

public section.

  interfaces IF_OS_STATE .
  interfaces BI_OBJECT .
  interfaces BI_PERSISTENT .
  interfaces IF_PT_REQ_ITEM .
  interfaces IF_PT_REQ_ITEM_WF .
  interfaces IF_WORKFLOW .

  events WF_VALIDATION_EVENT_START
    exporting
      value(IS_REQUEST) type ZTBREQUEST
      value(IV_INITIATOR_EMAIL) type AD_SMTPADR
      value(IV_VALIDATOR_EMAIL) type AD_SMTPADR
      value(IT_VALIDATOR_EMAIL) type BCSY_SMTPA optional
      value(IT_SUPER_VALIDATOR_EMAIL) type BCSY_SMTPA optional .
  events WF_VALIDATION_EVENT_DONE
    exporting
      value(IS_REQUEST) type ZTBREQUEST .
  events WF_VALIDATION_EVENT_DONE_FT2
    exporting
      value(IS_REQUEST) type ZTBREQUEST .
  events WF_VALIDATION_EVENT_STOP .
  events WF_VALIDATION_EVENT_RESEND .
  events WF_VALIDATION_EVENT_DONE_SVAL
    exporting
      value(IS_REQUEST) type ZTBREQUEST .

  methods SET_ZEDSUPVALUSER
    importing
      !I_ZEDSUPVALUSER type ZEDSUPVALUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSUPVALTIME
    importing
      !I_ZEDSUPVALTIME type ZEDSUPVALTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSUPVALDATE
    importing
      !I_ZEDSUPVALDATE type ZEDSUPVALDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSUPERVALIDATED
    importing
      !I_ZEDSUPERVALIDATED type ICL_STATUS_RELEASED
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDREQCRITIC
    importing
      !I_ZEDREQCRITIC type ZEDREQCRITIC
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDREQBATCH
    importing
      !I_ZEDREQBATCH type ZEDREQBATCH
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPVALUSER
    returning
      value(RESULT) type ZEDSUPVALUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPVALTIME
    returning
      value(RESULT) type ZEDSUPVALTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPVALDATE
    returning
      value(RESULT) type ZEDSUPVALDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPERVALIDATED
    returning
      value(RESULT) type ICL_STATUS_RELEASED
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREQCRITIC
    returning
      value(RESULT) type ZEDREQCRITIC
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREQBATCH
    returning
      value(RESULT) type ZEDREQBATCH
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALUSER
    returning
      value(RESULT) type ZEDVALUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDCOMMENT
    importing
      !I_ZEDCOMMENT type ZEDCOMMENT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDELIGIBLE
    importing
      !I_ZEDELIGIBLE type ZEDELIGIBLE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDFUNAREA
    importing
      !I_ZEDFUNAREA type ZEDFUNAREA
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDIMPORT
    importing
      !I_ZEDIMPORT type ZEDIMPORT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDLANGU
    importing
      !I_ZEDLANGU type ZEDLANGU
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDMODDATE
    importing
      !I_ZEDMODDATE type ZEDMODDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDMODTIME
    importing
      !I_ZEDMODTIME type ZEDMODTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDMODUSER
    importing
      !I_ZEDMODUSER type ZEDMODUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDQTRPCOD
    importing
      !I_ZEDQTRPCOD type ZEDQTRPCOD
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDQUERY
    importing
      !I_ZEDQUERY type ZEDQUERY
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDREPROC
    importing
      !I_ZEDREPROC type ZEDREPROC
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDREQDATE
    importing
      !I_ZEDREQDATE type ZEDREQDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDREQTIME
    importing
      !I_ZEDREQTIME type ZEDREQTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDREQUSER
    importing
      !I_ZEDREQUSER type ZEDREQUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSOURMDT
    importing
      !I_ZEDSOURMDT type ZEDSOURMDT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSOURSYS
    importing
      !I_ZEDSOURSYS type ZEDSOURSYS
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTARGSYS
    importing
      !I_ZEDTARGSYS type ZEDTARGSYS
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRPCODE
    importing
      !I_ZEDTRPCODE type ZEDTRPCODE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRPDATE
    importing
      !I_ZEDTRPDATE type ZEDTRPDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRPTIME
    importing
      !I_ZEDTRPTIME type ZEDTRPTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRPTYPE
    importing
      !I_ZEDTRPTYPE type ZEDTRPTYPE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRTDATE
    importing
      !I_ZEDTRTDATE type ZEDTRTDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRTTIME
    importing
      !I_ZEDTRTTIME type ZEDTRTTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDUGROUP
    importing
      !I_ZEDUGROUP type ZEDUGROUP
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALCODE
    importing
      !I_ZEDVALCODE type ZEDVALCODE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALDATE
    importing
      !I_ZEDVALDATE type ZEDVALDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALFT2
    importing
      !I_ZEDVALFT2 type ZEDVALFT2
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALFT2DATE
    importing
      !I_ZEDVALFT2DATE type ZEDVALFT2DATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALTIME
    importing
      !I_ZEDVALTIME type ZEDVALTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALUSER
    importing
      !I_ZEDVALUSER type ZEDVALUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods CONSTRUCTOR .
  methods GET_ZEDCOMMENT
    returning
      value(RESULT) type ZEDCOMMENT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDELIGIBLE
    returning
      value(RESULT) type ZEDELIGIBLE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDFUNAREA
    returning
      value(RESULT) type ZEDFUNAREA
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDIMPORT
    returning
      value(RESULT) type ZEDIMPORT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDLANGU
    returning
      value(RESULT) type ZEDLANGU
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDMODDATE
    returning
      value(RESULT) type ZEDMODDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDMODTIME
    returning
      value(RESULT) type ZEDMODTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDMODUSER
    returning
      value(RESULT) type ZEDMODUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDQTRPCOD
    returning
      value(RESULT) type ZEDQTRPCOD
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDQUERY
    returning
      value(RESULT) type ZEDQUERY
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREPROC
    returning
      value(RESULT) type ZEDREPROC
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREQDATE
    returning
      value(RESULT) type ZEDREQDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREQNB
    returning
      value(RESULT) type ZEDREQNB
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREQTIME
    returning
      value(RESULT) type ZEDREQTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDREQUSER
    returning
      value(RESULT) type ZEDREQUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSOURMDT
    returning
      value(RESULT) type ZEDSOURMDT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSOURSYS
    returning
      value(RESULT) type ZEDSOURSYS
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTARGSYS
    returning
      value(RESULT) type ZEDTARGSYS
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRPCODE
    returning
      value(RESULT) type ZEDTRPCODE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRPDATE
    returning
      value(RESULT) type ZEDTRPDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRPTIME
    returning
      value(RESULT) type ZEDTRPTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRPTYPE
    returning
      value(RESULT) type ZEDTRPTYPE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRTDATE
    returning
      value(RESULT) type ZEDTRTDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRTTIME
    returning
      value(RESULT) type ZEDTRTTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDUGROUP
    returning
      value(RESULT) type ZEDUGROUP
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALCODE
    returning
      value(RESULT) type ZEDVALCODE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALDATE
    returning
      value(RESULT) type ZEDVALDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALFT2
    returning
      value(RESULT) type ZEDVALFT2
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALFT2DATE
    returning
      value(RESULT) type ZEDVALFT2DATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALTIME
    returning
      value(RESULT) type ZEDVALTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  class-methods WORKFLOW_VALIDATION_STOP
    importing
      !IV_REQNB type ZEDREQNB
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  class-methods WORKFLOW_VALIDATION_START
    importing
      !IV_REQNB type ZEDREQNB
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  class-methods WORKFLOW_VALIDATION_DONE
    importing
      !IV_REQNB type ZEDREQNB
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  class-methods WORKFLOW_VALIDATION_RESEND
    importing
      !IV_REQNB type ZEDREQNB
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  methods DATA_RETURN
    returning
      value(RS_REQUEST) type ZTBREQUEST .
  methods MAIL_NOTIFICATION
    importing
      !EXPRESS type SOS04-L_SEX optional
      !SIGN type SOS04-S_SEX optional
      !ENCRYPT type SOS04-S_SEX optional
      !TYPEID type SOS04-L_ART optional
      !ADDRESSSTRINGS type USMD_T_NOTIF_RECIVERS optional
      !ATTACHMENTS type ref to SOFM optional
      !_ATTACH_OBJECTS type SWF_UTL_PORB_TAB optional
      !_ATTACH_COMMENT_OBJECTS type SWF_UTL_PORB_TAB optional
      !IV_WI_ID type SWW_TASK optional .
protected section.

  data ZEDREQNB type ZEDREQNB .
  data ZEDLANGU type ZEDLANGU .
  data ZEDSOURSYS type ZEDSOURSYS .
  data ZEDSOURMDT type ZEDSOURMDT .
  data ZEDTARGSYS type ZEDTARGSYS .
  data ZEDTRPDATE type ZEDTRPDATE .
  data ZEDTRPTIME type ZEDTRPTIME .
  data ZEDTRPCODE type ZEDTRPCODE .
  data ZEDTRPTYPE type ZEDTRPTYPE .
  data ZEDREQUSER type ZEDREQUSER .
  data ZEDREQDATE type ZEDREQDATE .
  data ZEDREQTIME type ZEDREQTIME .
  data ZEDMODUSER type ZEDMODUSER .
  data ZEDMODDATE type ZEDMODDATE .
  data ZEDMODTIME type ZEDMODTIME .
  data ZEDVALCODE type ZEDVALCODE .
  data ZEDVALUSER type ZEDVALUSER .
  data ZEDVALDATE type ZEDVALDATE .
  data ZEDVALTIME type ZEDVALTIME .
  data ZEDTRTDATE type ZEDTRTDATE .
  data ZEDTRTTIME type ZEDTRTTIME .
  data ZEDUGROUP type ZEDUGROUP .
  data ZEDFUNAREA type ZEDFUNAREA .
  data ZEDQUERY type ZEDQUERY .
  data ZEDQTRPCOD type ZEDQTRPCOD .
  data ZEDIMPORT type ZEDIMPORT .
  data ZEDCOMMENT type ZEDCOMMENT .
  data ZEDREPROC type ZEDREPROC .
  data ZEDVALFT2 type ZEDVALFT2 .
  data ZEDVALFT2DATE type ZEDVALFT2DATE .
  data ZEDELIGIBLE type ZEDELIGIBLE .
  data ZEDREQCRITIC type ZEDREQCRITIC .
  data ZEDSUPVALUSER type ZEDSUPVALUSER .
  data ZEDSUPVALDATE type ZEDSUPVALDATE .
  data ZEDSUPVALTIME type ZEDSUPVALTIME .
  data ZEDSUPERVALIDATED type ICL_STATUS_RELEASED .
  data ZEDREQBATCH type ZEDREQBATCH .
private section.

  types:
    BEGIN OF ts_instance,
      instid     TYPE sibfinstid,
      o_instance TYPE REF TO zcl_transport_request_workflow,
    END OF   ts_instance .
  types:
    tt_instance TYPE SORTED TABLE OF ts_instance
                  WITH UNIQUE KEY primary_key COMPONENTS instid .
  types:
    BEGIN OF ts_work_area,
      o_hardcode              TYPE REF TO zcl_hardcode,
      initiator_user          TYPE sy-uname,
      initiator_email         TYPE ad_smtpadr,
      validator_email         TYPE ad_smtpadr,
      t_validator_email       TYPE piqt_mailaddr,
      t_super_validator_email TYPE piqt_mailaddr,
    END OF   ts_work_area .

  constants:
    BEGIN OF mc_workflow_event,
      objtype                   TYPE char50 VALUE 'ZCL_TRANSPORT_REQUEST_WORKFLOW', ##NOTEXT
      event_validation_start    TYPE char50 VALUE 'WF_VALIDATION_EVENT_START', ##NOTEXT
      event_validation_stop     TYPE char50 VALUE 'WF_VALIDATION_EVENT_STOP', ##NOTEXT
      event_validation_done     TYPE char50 VALUE 'WF_VALIDATION_EVENT_DONE', ##NOTEXT
      event_validation_done_ft2 TYPE char50 VALUE 'WF_VALIDATION_EVENT_DONE_FT2', ##NOTEXT
      event_validation_resend   TYPE char50 VALUE 'WF_VALIDATION_EVENT_RESEND', ##NOTEXT
    END OF  mc_workflow_event .
  class-data MT_INSTANCE type ZCL_TRANSPORT_REQUEST_WORKFLOW=>TT_INSTANCE .
  data MS_WORK_AREA type ZCL_TRANSPORT_REQUEST_WORKFLOW=>TS_WORK_AREA .

  methods GET_MS_WORK_AREA
    returning
      value(RESULT) type ZCL_TRANSPORT_REQUEST_WORKFLOW=>TS_WORK_AREA
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_MS_WORK_AREA
    importing
      !I_MS_WORK_AREA type ZCL_TRANSPORT_REQUEST_WORKFLOW=>TS_WORK_AREA
    raising
      CX_OS_OBJECT_NOT_FOUND .
ENDCLASS.



CLASS ZCL_TRANSPORT_REQUEST_WORKFLOW IMPLEMENTATION.


METHOD bi_object~default_attribute_value.

ENDMETHOD.


METHOD bi_object~execute_default_method.
ENDMETHOD.


METHOD bi_object~release.
ENDMETHOD.


METHOD bi_persistent~find_by_lpor.
***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_transport_request TYPE REF TO zcl_transport_request_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération instance Singleton
  " -----------------------------------------------------------

  " Récupération instance ST
  READ TABLE zcl_transport_request_workflow=>mt_instance
  WITH TABLE KEY instid = lpor-instid
       ASSIGNING FIELD-SYMBOL(<lfs_s_instance>).
  IF sy-subrc NE 0.
    " Aucune correspondance
    TRY.
        ""  --> Récupération instance basée sur DB
        lo_transport_request = zca_transport_request_workflow=>agent->get_persistent( CONV #( lpor-instid ) ).

      CATCH cx_root.
        " Erreur
        ""  --> Création instance
        CREATE OBJECT lo_transport_request.

    ENDTRY.

    ""  --> Ajout de l'entrée & création de l'instance
    INSERT VALUE #(
      instid     = lpor-instid
      o_instance = lo_transport_request
    ) INTO TABLE zcl_transport_request_workflow=>mt_instance
       ASSIGNING <lfs_s_instance>.

  ENDIF.

  " Retourne instance
  result ?= <lfs_s_instance>-o_instance.

ENDMETHOD.


METHOD bi_persistent~lpor.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne information WorkItem
  " -----------------------------------------------------------

  result-instid         = me->get_zedreqnb( ).
  result-objtype-catid  = cl_swf_evt_event=>mc_objcateg_cl.
  result-objtype-typeid = 'ZCL_TRANSPORT_REQUEST_WORKFLOW'. "#EC NOTEXT

ENDMETHOD.


METHOD bi_persistent~refresh.
ENDMETHOD.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_TRANSPORT_REQUEST_WORKFLOW                    *
*& Description     : Constructeur                                      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 16/07/2020                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
    lr_uname_validator       TYPE RANGE OF sy-uname,
    lr_uname_super_validator TYPE RANGE OF sy-uname.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation Attributs
  " -----------------------------------------------------------

  TRY.
      " Hardcode
      me->ms_work_area-o_hardcode = zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ). "#EC NOTEXT

      TRY.
          " Mail Validateur
          LOOP AT me->ms_work_area-o_hardcode->attribute_value_get(
             iv_parameter_name = 'CONFIGURATION'            "#EC NOTEXT
             iv_attribute_name = 'VALIDATOR_EMAIL'          "#EC NOTEXT
            )-range INTO DATA(ls_range).

            APPEND ls_range-low TO me->ms_work_area-t_validator_email.

          ENDLOOP.

        CATCH zcx_hardcode.
          " Paramétrage non existant

      ENDTRY.

      TRY.
          " Mail Super-Validateur
          LOOP AT me->ms_work_area-o_hardcode->attribute_value_get(
               iv_parameter_name = 'CONFIGURATION'          "#EC NOTEXT
               iv_attribute_name = 'SUPER_VALIDATOR_MAIL'   "#EC NOTEXT
            )-range INTO ls_range.

            APPEND ls_range-low TO me->ms_work_area-t_super_validator_email.

          ENDLOOP.

        CATCH zcx_hardcode.
          " Paramétrage non existant

      ENDTRY.

      TRY.
          " User Super-Validateur
          lr_uname_super_validator = me->ms_work_area-o_hardcode->attribute_value_get(
               iv_parameter_name = 'CONFIGURATION'          "#EC NOTEXT
               iv_attribute_name = 'SUPER_VALIDATOR_USER'   "#EC NOTEXT
            )-range.

        CATCH zcx_hardcode.
          " Paramétrage non existant
          CLEAR : lr_uname_super_validator.

      ENDTRY.

      TRY.
          " User Validateur
          lr_uname_validator = me->ms_work_area-o_hardcode->attribute_value_get(
               iv_parameter_name = 'CONFIGURATION'          "#EC NOTEXT
               iv_attribute_name = 'VALIDATOR_USER'         "#EC NOTEXT
            )-range.

        CATCH zcx_hardcode.
          " Paramétrage non existant

      ENDTRY.

    CATCH zcx_hardcode.
      " Hardcode non trouvée
      CLEAR : lr_uname_validator.

  ENDTRY.

  IF me->ms_work_area-validator_email IS INITIAL.
    " Initialisation données Validateur
    me->ms_work_area-validator_email = 'team_sap_tech@celio.com'. ##NOTEXT

  ENDIF.

  " -----------------------------------------------------------
  " Validateurs
  " -----------------------------------------------------------

  IF NOT lr_uname_validator[] IS INITIAL.
    " Récupération des Emails associés à ces Comptes
    SELECT adr6~smtp_addr
      FROM usr21 INNER JOIN adr6
                         ON adr6~addrnumber EQ usr21~addrnumber
                        AND adr6~persnumber EQ usr21~persnumber
     WHERE usr21~bname   IN @lr_uname_validator
            APPENDING TABLE @me->ms_work_area-t_validator_email.

  ENDIF.

  " -----------------------------------------------------------
  " Super-Validateurs
  " -----------------------------------------------------------

  IF NOT lr_uname_super_validator[] IS INITIAL.
    " Récupération des Emails associés à ces Comptes
    SELECT adr6~smtp_addr
      FROM usr21 INNER JOIN adr6
                         ON adr6~addrnumber EQ usr21~addrnumber
                        AND adr6~persnumber EQ usr21~persnumber
     WHERE usr21~bname   IN @lr_uname_super_validator
            APPENDING TABLE @me->ms_work_area-t_super_validator_email.

  ENDIF.

  " -----------------------------------------------------------
  " Mail Initiateur
  " -----------------------------------------------------------

  " Initialisation données initiateur (Nom & eMail)
  me->ms_work_area-initiator_user = sy-uname.
  SELECT SINGLE adr6~smtp_addr
    FROM usr21 INNER JOIN adr6
                       ON adr6~addrnumber EQ usr21~addrnumber
                      AND adr6~persnumber EQ usr21~persnumber
   WHERE usr21~bname EQ @sy-uname
    INTO @me->ms_work_area-initiator_email.
  IF sy-subrc NE 0.
    " Aucune correspondance
    "" --> Construction adresse Celio
    me->ms_work_area-initiator_email = |{ sy-uname CASE = LOWER }@celio.com|. "#EC NOTEXT

  ENDIF.

ENDMETHOD.


METHOD data_return.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_value_me>      TYPE any,
    <lfs_value_request> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Récupération des Attributs
  SELECT cmpname  FROM vseocompdf
   WHERE clsname    EQ 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ##NOTEXT
     AND attpersist EQ @abap_true
    INTO TABLE @DATA(lt_attributes).

  " -----------------------------------------------------------
  " Initialisation des données
  " -----------------------------------------------------------

  " Traite tous les attributs publiques
  LOOP AT lt_attributes ASSIGNING FIELD-SYMBOL(<lfs_s_attributes>).

    " Récupération valeur attribut
    ASSIGN me->(<lfs_s_attributes>-cmpname) TO <lfs_value_me>.
    IF sy-subrc EQ 0.
      " Initialisation pointeur sur la données
      ASSIGN COMPONENT <lfs_s_attributes>-cmpname
          OF STRUCTURE rs_request
                    TO <lfs_value_request>.

    ENDIF.
    IF sy-subrc NE 0.
      " Erreur initialisation pointeur
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Initialisation de la valeur
    <lfs_value_request> = <lfs_value_me>.

  ENDLOOP.

ENDMETHOD.


  method GET_MS_WORK_AREA.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute MS_WORK_AREA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = MS_WORK_AREA.

           " GET_MS_WORK_AREA
  endmethod.


  method GET_ZEDCOMMENT.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDCOMMENT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDCOMMENT.

           " GET_ZEDCOMMENT
  endmethod.


  method GET_ZEDELIGIBLE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDELIGIBLE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDELIGIBLE.

           " GET_ZEDELIGIBLE
  endmethod.


  method GET_ZEDFUNAREA.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDFUNAREA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDFUNAREA.

           " GET_ZEDFUNAREA
  endmethod.


  method GET_ZEDIMPORT.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDIMPORT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDIMPORT.

           " GET_ZEDIMPORT
  endmethod.


  method GET_ZEDLANGU.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDLANGU
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDLANGU.

           " GET_ZEDLANGU
  endmethod.


  method GET_ZEDMODDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDMODDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDMODDATE.

           " GET_ZEDMODDATE
  endmethod.


  method GET_ZEDMODTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDMODTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDMODTIME.

           " GET_ZEDMODTIME
  endmethod.


  method GET_ZEDMODUSER.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDMODUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDMODUSER.

           " GET_ZEDMODUSER
  endmethod.


  method GET_ZEDQTRPCOD.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDQTRPCOD
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDQTRPCOD.

           " GET_ZEDQTRPCOD
  endmethod.


  method GET_ZEDQUERY.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDQUERY
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDQUERY.

           " GET_ZEDQUERY
  endmethod.


  method GET_ZEDREPROC.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREPROC
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREPROC.

           " GET_ZEDREPROC
  endmethod.


  method GET_ZEDREQBATCH.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREQBATCH
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREQBATCH.

           " GET_ZEDREQBATCH
  endmethod.


  method GET_ZEDREQCRITIC.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREQCRITIC
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREQCRITIC.

           " GET_ZEDREQCRITIC
  endmethod.


  method GET_ZEDREQDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREQDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREQDATE.

           " GET_ZEDREQDATE
  endmethod.


  method GET_ZEDREQNB.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREQNB
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREQNB.

           " GET_ZEDREQNB
  endmethod.


  method GET_ZEDREQTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREQTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREQTIME.

           " GET_ZEDREQTIME
  endmethod.


  method GET_ZEDREQUSER.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDREQUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDREQUSER.

           " GET_ZEDREQUSER
  endmethod.


  method GET_ZEDSOURMDT.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSOURMDT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSOURMDT.

           " GET_ZEDSOURMDT
  endmethod.


  method GET_ZEDSOURSYS.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSOURSYS
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSOURSYS.

           " GET_ZEDSOURSYS
  endmethod.


  method GET_ZEDSUPERVALIDATED.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPERVALIDATED
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPERVALIDATED.

           " GET_ZEDSUPERVALIDATED
  endmethod.


  method GET_ZEDSUPVALDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPVALDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPVALDATE.

           " GET_ZEDSUPVALDATE
  endmethod.


  method GET_ZEDSUPVALTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPVALTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPVALTIME.

           " GET_ZEDSUPVALTIME
  endmethod.


  method GET_ZEDSUPVALUSER.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPVALUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPVALUSER.

           " GET_ZEDSUPVALUSER
  endmethod.


  method GET_ZEDTARGSYS.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTARGSYS
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTARGSYS.

           " GET_ZEDTARGSYS
  endmethod.


  method GET_ZEDTRPCODE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRPCODE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRPCODE.

           " GET_ZEDTRPCODE
  endmethod.


  method GET_ZEDTRPDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRPDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRPDATE.

           " GET_ZEDTRPDATE
  endmethod.


  method GET_ZEDTRPTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRPTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRPTIME.

           " GET_ZEDTRPTIME
  endmethod.


  method GET_ZEDTRPTYPE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRPTYPE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRPTYPE.

           " GET_ZEDTRPTYPE
  endmethod.


  method GET_ZEDTRTDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRTDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRTDATE.

           " GET_ZEDTRTDATE
  endmethod.


  method GET_ZEDTRTTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRTTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRTTIME.

           " GET_ZEDTRTTIME
  endmethod.


  method GET_ZEDUGROUP.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDUGROUP
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDUGROUP.

           " GET_ZEDUGROUP
  endmethod.


  method GET_ZEDVALCODE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALCODE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALCODE.

           " GET_ZEDVALCODE
  endmethod.


  method GET_ZEDVALDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALDATE.

           " GET_ZEDVALDATE
  endmethod.


  method GET_ZEDVALFT2.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALFT2
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALFT2.

           " GET_ZEDVALFT2
  endmethod.


  method GET_ZEDVALFT2DATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALFT2DATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALFT2DATE.

           " GET_ZEDVALFT2DATE
  endmethod.


  method GET_ZEDVALTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALTIME.

           " GET_ZEDVALTIME
  endmethod.


  method GET_ZEDVALUSER.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALUSER.

           " GET_ZEDVALUSER
  endmethod.


  method IF_OS_STATE~GET.
***BUILD 090501
     " returning result type ref to object
************************************************************************
* Purpose        : Get state.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* GENERATED: Do not modify
************************************************************************

  data: STATE_OBJECT type ref to CL_OS_STATE.

  create object STATE_OBJECT.
  call method STATE_OBJECT->SET_STATE_FROM_OBJECT( ME ).
  result = STATE_OBJECT.

  endmethod.


  method IF_OS_STATE~HANDLE_EXCEPTION.
***BUILD 090501
     " importing I_EXCEPTION type ref to IF_OS_EXCEPTION_INFO optional
     " importing I_EX_OS type ref to CX_OS_OBJECT_NOT_FOUND optional
************************************************************************
* Purpose        : Handles exceptions during attribute access.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : If an exception is raised during attribut access,
*                  this method is called and the exception is passed
*                  as a paramater. The default is to raise the exception
*                  again, so that the caller can handle the exception.
*                  But it is also possible to handle the exception
*                  here in the callee.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
* - 2000-08-02   : (SB)  OO Exceptions
************************************************************************
* Modify if you like
************************************************************************

  if i_ex_os is not initial.
    raise exception i_ex_os.
  endif.

  endmethod.


  method IF_OS_STATE~INIT.
***BUILD 090501
"#EC NEEDED
************************************************************************
* Purpose        : Initialisation of the transient state partition.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : Transient state is initial.
*
* OO Exceptions  : -
*
* Implementation : Caution!: Avoid Throwing ACCESS Events.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* Modify if you like
************************************************************************

  endmethod.


  method IF_OS_STATE~INVALIDATE.
***BUILD 090501
"#EC NEEDED
************************************************************************
* Purpose        : Do something before all persistent attributes are
*                  cleared.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : Whatever you like to do.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* Modify if you like
************************************************************************

  endmethod.


  method IF_OS_STATE~SET.
***BUILD 090501
     " importing I_STATE type ref to object
************************************************************************
* Purpose        : Set state.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* GENERATED: Do not modify
************************************************************************

  data: STATE_OBJECT type ref to CL_OS_STATE.

  STATE_OBJECT ?= I_STATE.
  call method STATE_OBJECT->SET_OBJECT_FROM_STATE( ME ).

  endmethod.


METHOD if_pt_req_item_wf~set_all_item_wf_attribs.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_workflow_data TYPE ztbrequest.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_structdescr TYPE REF TO cl_abap_structdescr.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_method TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
                 <lfs_attribute> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation tables des Attributs
  " -----------------------------------------------------------

*  " Récupération description de la structure
*  lo_structdescr ?= cl_abap_structdescr=>describe_by_data(  ).
*
*  LOOP AT lo_structdescr->components ASSIGNING FIELD-SYMBOL(<lfs_s_components>).
*
*    " Nom de la méthode
*    lv_method = |GET_{ <lfs_s_components>-name CASE = UPPER }|. "#EC NOTEXT
*
*    " Initialisation pointeur sur l'Attribut
*    ASSIGN (<lfs_s_components>-name) TO <lfs_attribute>.
*    IF sy-subrc NE 0.
*      " Aucune corrspondance
*      ""  --> Passe à l'itération suivante
*      CONTINUE.
*
*    ENDIF.
*
*    TRY.
*        " Appel de la méthode dynamiquement
*        CALL METHOD me->(lv_method)
*          RECEIVING
*            result = <lfs_attribute>.
*
*      CATCH cx_sy_dyn_call_illegal_method.
*        " Méthode inexistante
*
*    ENDTRY.
*
*    " Ajout dans la table des Valeurs
*    APPEND <lfs_attribute> TO if_pt_req_item_wf~attsval.
*
*    " Ajout dans la table des Attributs
*    APPEND <lfs_s_components>-name TO if_pt_req_item_wf~attsname.
*
*    " Ajout dans la table des Attributs / Valeurs
*    APPEND VALUE #(
*      name  = <lfs_s_components>-name
*      value = <lfs_attribute>
*    ) TO if_pt_req_item_wf~atts.
*
*    " Réinitialisation
*    CLEAR    : lv_method.
*    UNASSIGN : <lfs_attribute>.
*
*  ENDLOOP.

ENDMETHOD.


METHOD if_pt_req_item~compare_db_to_object.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_transport_workflow TYPE REF TO zcl_transport_request_workflow.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_field TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_source> TYPE any,
    <lfs_target> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Témoin indentique
  ret_identical = abap_true.

  " Move-Cast
  lo_transport_workflow ?= im_compare_item.

  " Récupération des Attributs
  SELECT cmpname  FROM vseocompdf
   WHERE clsname    EQ 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ##NOTEXT
     AND attpersist EQ @abap_true
    INTO TABLE @DATA(lt_attributes).

  " -----------------------------------------------------------
  " Compare les données
  " -----------------------------------------------------------

  LOOP AT lt_attributes ASSIGNING FIELD-SYMBOL(<lfs_s_attributes>).

    " Récupération valeur objet courant
    ASSIGN me->(<lfs_s_attributes>-cmpname) TO <lfs_source>.
    IF sy-subrc EQ 0.
      " Récupération valeur objet comparé
      lv_field = |lo_transport_workflow->{ <lfs_s_attributes>-cmpname }|. ##NOTEXT
      ASSIGN (lv_field) TO <lfs_target>.

    ENDIF.
    IF sy-subrc NE 0.
      " Pas de correspondance
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    IF <lfs_source> NE <lfs_target>.
      " Valeur divergente
      ""  --> Initialisation témoin
      ret_identical = abap_false.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Réinitialisation
    UNASSIGN : <lfs_target>, <lfs_source>.

  ENDLOOP.

ENDMETHOD.


METHOD if_pt_req_item~get_all_item_attribs.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_workflow_data TYPE ztbrequest.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_structdescr TYPE REF TO cl_abap_structdescr.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_method TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
                 <lfs_attribute> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation tables des Attributs
  " -----------------------------------------------------------

  " Récupération description de la structure
  lo_structdescr ?= cl_abap_structdescr=>describe_by_data( ls_workflow_data ).

  LOOP AT lo_structdescr->components ASSIGNING FIELD-SYMBOL(<lfs_s_components>).

    " Nom de la méthode
    lv_method = |GET_{ <lfs_s_components>-name CASE = UPPER }|. "#EC NOTEXT

    " Initialisation pointeur sur l'Attribut
    ASSIGN (<lfs_s_components>-name) TO <lfs_attribute>.
    IF sy-subrc NE 0.
      " Aucune corrspondance
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    TRY.
        " Appel de la méthode dynamiquement
        CALL METHOD me->(lv_method)
          RECEIVING
            result = <lfs_attribute>.

      CATCH cx_sy_dyn_call_illegal_method.
        " Méthode inexistante

    ENDTRY.

    " Ajout dans la table des Attributs / Valeurs
    APPEND VALUE #(
      name  = <lfs_s_components>-name
      value = <lfs_attribute>
    ) TO ex_attribs_tab.

    " Réinitialisation
    CLEAR    : lv_method.
    UNASSIGN : <lfs_attribute>.

  ENDLOOP.

  " Iniialisation Attribut WF
  CALL METHOD me->if_pt_req_item_wf~set_all_item_wf_attribs.

ENDMETHOD.


METHOD if_pt_req_item~get_item_id.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne ID
  " -----------------------------------------------------------

  result = me->get_zedreqnb( ).

ENDMETHOD.


METHOD if_pt_req_item~set_all_item_attribs.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_parameter_table TYPE abap_parmbind_tab.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_method TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
        <lfs_value> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation des Attributs
  " -----------------------------------------------------------

  LOOP AT im_attribs_tab ASSIGNING FIELD-SYMBOL(<lfs_s_attribts_tab>).

    " Initialisation pointeur sur la valeur
    ASSIGN (<lfs_s_attribts_tab>-name) TO <lfs_value>.
    IF sy-subrc NE 0.
      " Pointeur non initialisé
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Nom de la méthode
    lv_method = |SET_{ <lfs_s_attribts_tab>-name CASE = UPPER }|. "#EC NOTEXT

    " Initialisation paramètre d'appel de la méthode
    lt_parameter_table = VALUE #(
      (
        name  = |I_{ <lfs_s_attribts_tab>-name CASE = UPPER }| "#EC NOTEXT
        value = REF #( <lfs_value> )
      )
    ).

    TRY.
        " Appel de la méthde dynamniquement
        CALL METHOD me->(lv_method)
          PARAMETER-TABLE lt_parameter_table.

      CATCH cx_sy_dyn_call_illegal_method.
        " Méthode inexistante
        ""  --> Passe à l'itération suivante
        CONTINUE.

    ENDTRY.

    " Réinitialisation
    CLEAR   : lv_method.
    REFRESH : lt_parameter_table.

  ENDLOOP.

  TRY.
      " -----------------------------------------------------------
      " Initialisation des Attributs
      " -----------------------------------------------------------

      DATA(lv_id) = me->if_pt_req_item~get_item_id( ).

    CATCH cx_os_object_not_found.

  ENDTRY.

  " -----------------------------------------------------------
  " Initialisation des Attributs Workflow
  " -----------------------------------------------------------

  me->if_pt_req_item_wf~set_all_item_wf_attribs( ).

ENDMETHOD.


METHOD if_pt_req_item~set_item_id.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation ID
  " -----------------------------------------------------------

  " Initialisation ID
  me->zedreqnb = im_item_id.

ENDMETHOD.


 METHOD mail_notification.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
   DATA :
     lo_handle    TYPE REF TO if_swf_run_wim_internal,
     lo_container TYPE REF TO if_swf_cnt_container.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
   DATA :
     lt_command_lines    TYPE tline_t,
     lt_html_text_lines  TYPE htmltable,
     lt_ascii_text_lines TYPE tline_t.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
   DATA :
         lv_task TYPE rhobjects-object.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  RETURN.

   TRY.
       " -----------------------------------------------------------
       " Récupération paramétrage du Mail
       " -----------------------------------------------------------

       " Récupération de la Tâche
*       lo_handle = cl_swf_run_wim_factory=>find_by_wiid( iv_wi_id ).

       " Récupération Container
       lo_container = lo_handle->get_wi_container( ).

       " Récupération Tâche
       lv_task = |TS{ lo_handle->m_sww_wihead-wi_rh_task+2 }|. "#EC NOTEXT

       " Récupération Objet de la Tâche
       CALL FUNCTION 'SWU_GET_TASK_TEXTLINES'
         EXPORTING
           task              = lv_task
           usage             = 'W' ##NOTEXT
           linewidth         = 132
           language          = SWITCH sy-langu( lo_handle->m_sww_wihead-wi_lang
            WHEN space THEN sy-langu ELSE lo_handle->m_sww_wihead-wi_rh_task
           )
           container_handle  = lo_container
         TABLES
           command_lines     = lt_command_lines
           html_text_lines   = lt_html_text_lines
           ascii_text_lines  = lt_ascii_text_lines
         EXCEPTIONS
           wrong_usage       = 01
           text_not_found    = 02
           text_system_error = 03.

     CATCH cx_root.

   ENDTRY.

 ENDMETHOD.


  method SET_MS_WORK_AREA.
***BUILD 090501
     " importing I_MS_WORK_AREA
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute MS_WORK_AREA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_MS_WORK_AREA <> MS_WORK_AREA ).

    MS_WORK_AREA = I_MS_WORK_AREA.

  endif. "( I_MS_WORK_AREA <> MS_WORK_AREA )

           " GET_MS_WORK_AREA
  endmethod.


  method SET_ZEDCOMMENT.
***BUILD 090501
     " importing I_ZEDCOMMENT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDCOMMENT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDCOMMENT <> ZEDCOMMENT ).

    ZEDCOMMENT = I_ZEDCOMMENT.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDCOMMENT <> ZEDCOMMENT )

           " GET_ZEDCOMMENT
  endmethod.


  method SET_ZEDELIGIBLE.
***BUILD 090501
     " importing I_ZEDELIGIBLE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDELIGIBLE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDELIGIBLE <> ZEDELIGIBLE ).

    ZEDELIGIBLE = I_ZEDELIGIBLE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDELIGIBLE <> ZEDELIGIBLE )

           " GET_ZEDELIGIBLE
  endmethod.


  method SET_ZEDFUNAREA.
***BUILD 090501
     " importing I_ZEDFUNAREA
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDFUNAREA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDFUNAREA <> ZEDFUNAREA ).

    ZEDFUNAREA = I_ZEDFUNAREA.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDFUNAREA <> ZEDFUNAREA )

           " GET_ZEDFUNAREA
  endmethod.


  method SET_ZEDIMPORT.
***BUILD 090501
     " importing I_ZEDIMPORT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDIMPORT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDIMPORT <> ZEDIMPORT ).

    ZEDIMPORT = I_ZEDIMPORT.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDIMPORT <> ZEDIMPORT )

           " GET_ZEDIMPORT
  endmethod.


  method SET_ZEDLANGU.
***BUILD 090501
     " importing I_ZEDLANGU
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDLANGU
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDLANGU <> ZEDLANGU ).

    ZEDLANGU = I_ZEDLANGU.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDLANGU <> ZEDLANGU )

           " GET_ZEDLANGU
  endmethod.


  method SET_ZEDMODDATE.
***BUILD 090501
     " importing I_ZEDMODDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDMODDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDMODDATE <> ZEDMODDATE ).

    ZEDMODDATE = I_ZEDMODDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDMODDATE <> ZEDMODDATE )

           " GET_ZEDMODDATE
  endmethod.


  method SET_ZEDMODTIME.
***BUILD 090501
     " importing I_ZEDMODTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDMODTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDMODTIME <> ZEDMODTIME ).

    ZEDMODTIME = I_ZEDMODTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDMODTIME <> ZEDMODTIME )

           " GET_ZEDMODTIME
  endmethod.


  method SET_ZEDMODUSER.
***BUILD 090501
     " importing I_ZEDMODUSER
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDMODUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDMODUSER <> ZEDMODUSER ).

    ZEDMODUSER = I_ZEDMODUSER.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDMODUSER <> ZEDMODUSER )

           " GET_ZEDMODUSER
  endmethod.


  method SET_ZEDQTRPCOD.
***BUILD 090501
     " importing I_ZEDQTRPCOD
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDQTRPCOD
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDQTRPCOD <> ZEDQTRPCOD ).

    ZEDQTRPCOD = I_ZEDQTRPCOD.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDQTRPCOD <> ZEDQTRPCOD )

           " GET_ZEDQTRPCOD
  endmethod.


  method SET_ZEDQUERY.
***BUILD 090501
     " importing I_ZEDQUERY
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDQUERY
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDQUERY <> ZEDQUERY ).

    ZEDQUERY = I_ZEDQUERY.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDQUERY <> ZEDQUERY )

           " GET_ZEDQUERY
  endmethod.


  method SET_ZEDREPROC.
***BUILD 090501
     " importing I_ZEDREPROC
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDREPROC
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDREPROC <> ZEDREPROC ).

    ZEDREPROC = I_ZEDREPROC.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDREPROC <> ZEDREPROC )

           " GET_ZEDREPROC
  endmethod.


  method SET_ZEDREQBATCH.
***BUILD 090501
     " importing I_ZEDREQBATCH
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDREQBATCH
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDREQBATCH <> ZEDREQBATCH ).

    ZEDREQBATCH = I_ZEDREQBATCH.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDREQBATCH <> ZEDREQBATCH )

           " GET_ZEDREQBATCH
  endmethod.


  method SET_ZEDREQCRITIC.
***BUILD 090501
     " importing I_ZEDREQCRITIC
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDREQCRITIC
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDREQCRITIC <> ZEDREQCRITIC ).

    ZEDREQCRITIC = I_ZEDREQCRITIC.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDREQCRITIC <> ZEDREQCRITIC )

           " GET_ZEDREQCRITIC
  endmethod.


  method SET_ZEDREQDATE.
***BUILD 090501
     " importing I_ZEDREQDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDREQDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDREQDATE <> ZEDREQDATE ).

    ZEDREQDATE = I_ZEDREQDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDREQDATE <> ZEDREQDATE )

           " GET_ZEDREQDATE
  endmethod.


  method SET_ZEDREQTIME.
***BUILD 090501
     " importing I_ZEDREQTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDREQTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDREQTIME <> ZEDREQTIME ).

    ZEDREQTIME = I_ZEDREQTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDREQTIME <> ZEDREQTIME )

           " GET_ZEDREQTIME
  endmethod.


  method SET_ZEDREQUSER.
***BUILD 090501
     " importing I_ZEDREQUSER
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDREQUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDREQUSER <> ZEDREQUSER ).

    ZEDREQUSER = I_ZEDREQUSER.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDREQUSER <> ZEDREQUSER )

           " GET_ZEDREQUSER
  endmethod.


  method SET_ZEDSOURMDT.
***BUILD 090501
     " importing I_ZEDSOURMDT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSOURMDT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSOURMDT <> ZEDSOURMDT ).

    ZEDSOURMDT = I_ZEDSOURMDT.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSOURMDT <> ZEDSOURMDT )

           " GET_ZEDSOURMDT
  endmethod.


  method SET_ZEDSOURSYS.
***BUILD 090501
     " importing I_ZEDSOURSYS
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSOURSYS
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSOURSYS <> ZEDSOURSYS ).

    ZEDSOURSYS = I_ZEDSOURSYS.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSOURSYS <> ZEDSOURSYS )

           " GET_ZEDSOURSYS
  endmethod.


  method SET_ZEDSUPERVALIDATED.
***BUILD 090501
     " importing I_ZEDSUPERVALIDATED
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPERVALIDATED
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPERVALIDATED <> ZEDSUPERVALIDATED ).

    ZEDSUPERVALIDATED = I_ZEDSUPERVALIDATED.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPERVALIDATED <> ZEDSUPERVALIDATED )

           " GET_ZEDSUPERVALIDATED
  endmethod.


  method SET_ZEDSUPVALDATE.
***BUILD 090501
     " importing I_ZEDSUPVALDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPVALDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPVALDATE <> ZEDSUPVALDATE ).

    ZEDSUPVALDATE = I_ZEDSUPVALDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPVALDATE <> ZEDSUPVALDATE )

           " GET_ZEDSUPVALDATE
  endmethod.


  method SET_ZEDSUPVALTIME.
***BUILD 090501
     " importing I_ZEDSUPVALTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPVALTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPVALTIME <> ZEDSUPVALTIME ).

    ZEDSUPVALTIME = I_ZEDSUPVALTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPVALTIME <> ZEDSUPVALTIME )

           " GET_ZEDSUPVALTIME
  endmethod.


  method SET_ZEDSUPVALUSER.
***BUILD 090501
     " importing I_ZEDSUPVALUSER
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPVALUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPVALUSER <> ZEDSUPVALUSER ).

    ZEDSUPVALUSER = I_ZEDSUPVALUSER.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPVALUSER <> ZEDSUPVALUSER )

           " GET_ZEDSUPVALUSER
  endmethod.


  method SET_ZEDTARGSYS.
***BUILD 090501
     " importing I_ZEDTARGSYS
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTARGSYS
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTARGSYS <> ZEDTARGSYS ).

    ZEDTARGSYS = I_ZEDTARGSYS.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTARGSYS <> ZEDTARGSYS )

           " GET_ZEDTARGSYS
  endmethod.


  method SET_ZEDTRPCODE.
***BUILD 090501
     " importing I_ZEDTRPCODE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRPCODE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRPCODE <> ZEDTRPCODE ).

    ZEDTRPCODE = I_ZEDTRPCODE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRPCODE <> ZEDTRPCODE )

           " GET_ZEDTRPCODE
  endmethod.


  method SET_ZEDTRPDATE.
***BUILD 090501
     " importing I_ZEDTRPDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRPDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRPDATE <> ZEDTRPDATE ).

    ZEDTRPDATE = I_ZEDTRPDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRPDATE <> ZEDTRPDATE )

           " GET_ZEDTRPDATE
  endmethod.


  method SET_ZEDTRPTIME.
***BUILD 090501
     " importing I_ZEDTRPTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRPTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRPTIME <> ZEDTRPTIME ).

    ZEDTRPTIME = I_ZEDTRPTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRPTIME <> ZEDTRPTIME )

           " GET_ZEDTRPTIME
  endmethod.


  method SET_ZEDTRPTYPE.
***BUILD 090501
     " importing I_ZEDTRPTYPE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRPTYPE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRPTYPE <> ZEDTRPTYPE ).

    ZEDTRPTYPE = I_ZEDTRPTYPE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRPTYPE <> ZEDTRPTYPE )

           " GET_ZEDTRPTYPE
  endmethod.


  method SET_ZEDTRTDATE.
***BUILD 090501
     " importing I_ZEDTRTDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRTDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRTDATE <> ZEDTRTDATE ).

    ZEDTRTDATE = I_ZEDTRTDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRTDATE <> ZEDTRTDATE )

           " GET_ZEDTRTDATE
  endmethod.


  method SET_ZEDTRTTIME.
***BUILD 090501
     " importing I_ZEDTRTTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRTTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRTTIME <> ZEDTRTTIME ).

    ZEDTRTTIME = I_ZEDTRTTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRTTIME <> ZEDTRTTIME )

           " GET_ZEDTRTTIME
  endmethod.


  method SET_ZEDUGROUP.
***BUILD 090501
     " importing I_ZEDUGROUP
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDUGROUP
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDUGROUP <> ZEDUGROUP ).

    ZEDUGROUP = I_ZEDUGROUP.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDUGROUP <> ZEDUGROUP )

           " GET_ZEDUGROUP
  endmethod.


  method SET_ZEDVALCODE.
***BUILD 090501
     " importing I_ZEDVALCODE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALCODE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALCODE <> ZEDVALCODE ).

    ZEDVALCODE = I_ZEDVALCODE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALCODE <> ZEDVALCODE )

           " GET_ZEDVALCODE
  endmethod.


  method SET_ZEDVALDATE.
***BUILD 090501
     " importing I_ZEDVALDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALDATE <> ZEDVALDATE ).

    ZEDVALDATE = I_ZEDVALDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALDATE <> ZEDVALDATE )

           " GET_ZEDVALDATE
  endmethod.


  method SET_ZEDVALFT2.
***BUILD 090501
     " importing I_ZEDVALFT2
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALFT2
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALFT2 <> ZEDVALFT2 ).

    ZEDVALFT2 = I_ZEDVALFT2.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALFT2 <> ZEDVALFT2 )

           " GET_ZEDVALFT2
  endmethod.


  method SET_ZEDVALFT2DATE.
***BUILD 090501
     " importing I_ZEDVALFT2DATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALFT2DATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALFT2DATE <> ZEDVALFT2DATE ).

    ZEDVALFT2DATE = I_ZEDVALFT2DATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALFT2DATE <> ZEDVALFT2DATE )

           " GET_ZEDVALFT2DATE
  endmethod.


  method SET_ZEDVALTIME.
***BUILD 090501
     " importing I_ZEDVALTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALTIME <> ZEDVALTIME ).

    ZEDVALTIME = I_ZEDVALTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALTIME <> ZEDVALTIME )

           " GET_ZEDVALTIME
  endmethod.


  method SET_ZEDVALUSER.
***BUILD 090501
     " importing I_ZEDVALUSER
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALUSER <> ZEDVALUSER ).

    ZEDVALUSER = I_ZEDVALUSER.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALUSER <> ZEDVALUSER )

           " GET_ZEDVALUSER
  endmethod.


METHOD workflow_validation_done.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_container         TYPE REF TO if_swf_ifs_parameter_container,
    lo_transport_request TYPE REF TO zcl_transport_request_workflow.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_event TYPE char50.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération instance Transport
      " -----------------------------------------------------------

      " Récupération instance Transport
      lo_transport_request ?= zcl_transport_request_workflow=>bi_persistent~find_by_lpor( VALUE #(
        instid = iv_reqnb
      ) ).

    CATCH cx_root.

  ENDTRY.
  IF NOT lo_transport_request IS BOUND.
    " Instance non trouvée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Trigger Event Validation effectuée
      " -----------------------------------------------------------

      IF lo_transport_request->get_zedeligible( ) EQ abap_false.
        " Demande "normal"
        ""  --> Lance évenement fin de traitement "classique"
        lv_event = zcl_transport_request_workflow=>mc_workflow_event-event_validation_done.

      ELSE.
        " Demande "express"
        ""  --> Lance évenement fin de traitement Express
        lv_event = zcl_transport_request_workflow=>mc_workflow_event-event_validation_done_ft2.

      ENDIF.

      TRY.
          " -----------------------------------------------------------
          " Préparation Container WF
          " -----------------------------------------------------------


          " Création instance Container du WF
          lo_container = cl_swf_evt_event=>get_event_container(
              im_event    = lv_event
              im_objcateg = cl_swf_evt_event=>mc_objcateg_cl
              im_objtype  = zcl_transport_request_workflow=>mc_workflow_event-objtype
          ).

          IF lo_container IS BOUND.
            " Ajout dans le Container
            lo_container->set(
                name  = 'IS_REQUEST'
                value = lo_transport_request->data_return( )
            ).

          ENDIF.

        CATCH cx_root.

      ENDTRY.

      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_event           = lv_event
        im_objkey          = CONV char8( iv_reqnb )
        im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype         = zcl_transport_request_workflow=>mc_workflow_event-objtype
        im_event_container = lo_container
      ).

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.


METHOD workflow_validation_resend.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_transport_request TYPE REF TO zcl_transport_request_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération instance Transport
  " -----------------------------------------------------------

  " Récupération instance Transport
  lo_transport_request ?= zcl_transport_request_workflow=>bi_persistent~find_by_lpor( VALUE #(
    instid = iv_reqnb
  ) ).
  IF NOT lo_transport_request IS BOUND.
    " Instance non trouvée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype         = zcl_transport_request_workflow=>mc_workflow_event-objtype
        im_event           = zcl_transport_request_workflow=>mc_workflow_event-event_validation_resend
        im_objkey          = CONV char8( iv_reqnb )
      ).

      " Evénement levée
      rv_raised = abap_true.

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.


METHOD workflow_validation_start.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_container         TYPE REF TO if_swf_ifs_parameter_container,
    lo_transport_request TYPE REF TO zcl_transport_request_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération instance Transport
  " -----------------------------------------------------------

  " Récupération instance Transport
  lo_transport_request ?= zcl_transport_request_workflow=>bi_persistent~find_by_lpor( VALUE #(
    instid = iv_reqnb
  ) ).
  IF NOT lo_transport_request IS BOUND.
    " Instance non trouvée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF lo_transport_request->get_zedtrpcode( ) EQ zcl_transport_request_celio=>mc_request_type-authorization.
    " Demande de Transport Authorisation
    ""  --> Pas de Workflow
    RETURN.

  ENDIF.

  TRY.
      TRY.
          " -----------------------------------------------------------
          " Préparation Container WF
          " -----------------------------------------------------------

          " Création instance Container du WF
          lo_container = cl_swf_evt_event=>get_event_container(
              im_objcateg  = cl_swf_evt_event=>mc_objcateg_cl
              im_objtype  = zcl_transport_request_workflow=>mc_workflow_event-objtype
              im_event    = zcl_transport_request_workflow=>mc_workflow_event-event_validation_start
          ).

          IF lo_container IS BOUND.
            " Ajout dans le Container
            ""  --> Données Demande
            lo_container->set(
                name  = 'IS_REQUEST' ##NOTEXT
                value = lo_transport_request->data_return( )
            ).

            ""  --> Mail Initiateur
            lo_container->set(
                name  = 'IV_INITIATOR_EMAIL' ##NOTEXT
                value = lo_transport_request->ms_work_area-initiator_email
            ).

            ""  --> Mail Validateur
            lo_container->set(
                name  = 'IV_VALIDATOR_EMAIL' ##NOTEXT
                value = lo_transport_request->ms_work_area-validator_email
            ).

            ""  --> Mail Validateur
            lo_container->set(
                name  = 'IT_VALIDATOR_EMAIL' ##NOTEXT
                value = lo_transport_request->ms_work_area-t_validator_email
            ).

            ""  --> Mail Super Validateur
            lo_container->set(
                name  = 'IT_SUPER_VALIDATOR_EMAIL' ##NOTEXT
                value = lo_transport_request->ms_work_area-t_super_validator_email
            ).

          ENDIF.

        CATCH cx_root.

      ENDTRY.

      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype         = zcl_transport_request_workflow=>mc_workflow_event-objtype
        im_event           = zcl_transport_request_workflow=>mc_workflow_event-event_validation_start
        im_objkey          = CONV char8( iv_reqnb )
        im_event_container = lo_container
      ).

      " Evénement levée
      rv_raised = abap_true.

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.


METHOD workflow_validation_stop.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype         = zcl_transport_request_workflow=>mc_workflow_event-objtype
        im_event           = zcl_transport_request_workflow=>mc_workflow_event-event_validation_stop
        im_objkey          = CONV char8( iv_reqnb )
*        im_event_container = lo_container
      ).

      " Evénement levée
      rv_raised = abap_true.

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.
ENDCLASS.
