*&---------------------------------------------------------------------*
*&  Include           ZXSEUU08
*&---------------------------------------------------------------------*

" Suivant l'action utilisateur
CASE operation.

  WHEN 'EDIT'. ##NOTEXT
    " Edition du Code
    IF zcl_transport_request=>object_edition_check( program ) EQ abap_true.
      " L'utilisateur ne souhaite pas poursuivre l'édition
      RAISE cancelled.

    ENDIF.

  WHEN OTHERS.
    " Autre

ENDCASE.
