*&---------------------------------------------------------------------*
*&  Include           Z_BC_TRANSPORT_REQUEST_C02
*&---------------------------------------------------------------------*


*----------------------------------------------------------------------*
*       CLASS LCL_main IMPLEMENTATION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main IMPLEMENTATION.

  METHOD initialization.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " Import du dernier onglet visualisée
    IMPORT current_tab = gs_tab_current FROM MEMORY ID lcl_main=>mc_memory_id-tab_navigation.
    IF NOT gs_tab_current IS INITIAL.
      " Transaction en cours d'utilisation
      ""  --> Force l'affichage du dernier onglet visité
      tab = gs_tab_current.

    ENDIF.

    " -----------------------------------------------------------
    " Génération instance principale
    " -----------------------------------------------------------

    go_main = lcl_main=>factory( ).

  ENDMETHOD.

  METHOD factory.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Génération instance principale
    " -----------------------------------------------------------

    ro_instance = NEW #( ).

  ENDMETHOD.

  METHOD constructor.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation Attributs
    " -----------------------------------------------------------

    " Commun
    ""  --> Action utilisateur
    me->ms_global_area_private-ov_screen = REF #( p_screen ).

    " -----------------------------------------------------------
    " Initialisation Attributs - Création
    " -----------------------------------------------------------

    " Ecran de Sélection - Création
    DATA(lo_creation) = REF #( me->ms_selection_criteria-creation ).

    ""  --> Objet
    lo_creation->object-or_trkorr         = REF #( s_trkorr[] ).
    lo_creation->object-ov_system_target  = REF #( p_sysid ).
    lo_creation->object-ov_transport_code = REF #( p_type ).

    ""  --> Date & Heure
    lo_creation->time-ov_transport_date = REF #( p_datum ).
    lo_creation->time-ov_transport_hour = REF #( p_uzeit ).

    ""  --> Lot
    lo_creation->batch-ov_batch = REF #( p_batch ).

    ""  --> Criticité
    lo_creation->criticity-ov_critic = REF #( p_critic ).

    ""  --> Option
    lo_creation->option-ov_check                = REF #( p_check ).
    lo_creation->option-ov_transport_express    = REF #( p_expr ).
    lo_creation->option-ov_only_target_system   = REF #( p_only ).
    lo_creation->option-ov_launch_transport_job = REF #( p_ljob ).

    ""  --> Certification
    lo_creation->certification-ov_valid = REF #( p_acc ).

    " -----------------------------------------------------------
    " Initialisation Attributs - Modification
    " -----------------------------------------------------------

    " Ecran de Sélection - Modification
    DATA(lo_modification) = REF #( me->ms_selection_criteria-modification ).

    ""  --> Critère de sélection
    lo_modification->transport_selection-ov_request   = REF #( p_req ).
    lo_modification->transport_selection-ov_read_only = REF #( p_ronly ).

    " -----------------------------------------------------------
    " Initialisation Attributs - Exécution
    " -----------------------------------------------------------

    " Ecran de Sélection - Exécution
    DATA(lo_execution) = REF #( me->ms_selection_criteria-execution ).

    ""  --> Critère de sélection
    lo_execution->time-ov_uzeit = REF #( p_ehour ).
    lo_execution->time-ov_datum = REF #( p_edate ).

  ENDMETHOD.

  METHOD sysid_value_help.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_fields     TYPE dfies_tab,
      lt_valuetab   TYPE char10_t,
      lt_return_tab TYPE hrreturn_tab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Aide à la Recherche Système Cible
    " -----------------------------------------------------------

    lt_fields = VALUE #(
      (
        tabname   = 'ZTBDESTRFC'                            ##NO_TEXT
        fieldname = 'ZEDTARGSYS'                            ##NO_TEXT
      )
    ).

    " Récupération Liste des Systèmes Cibles
    SELECT DISTINCT ( zedtargsys ) FROM ztbdestrfc
     WHERE loekz EQ @abap_false ORDER BY zedtargsys
      INTO TABLE @lt_valuetab.

    " Appel PopUp Sélection
    CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
      EXPORTING
        retfield        = 'ZEDTARGSYS' ##NO_TEXT
        window_title    = text-ssy
      TABLES
        value_tab       = lt_valuetab
        field_tab       = lt_fields
        return_tab      = lt_return_tab
      EXCEPTIONS
        parameter_error = 1
        no_values_found = 2
        OTHERS          = 3.
    IF sy-subrc NE 0 OR lt_return_tab[] IS INITIAL.
      " Erreur appel Aide à la Recherche
      ""  --> Arrêt du traitement
      CLEAR : rv_sysid.
      RETURN.

    ELSE.
      " Initialisatin système sélectionné
      rv_sysid = lt_return_tab[ 1 ]-fieldval.

    ENDIF.

  ENDMETHOD.

  METHOD trkorr_value_help.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Aide à la recherche OT
    " -----------------------------------------------------------

    " Aide à la recherche OT
    CALL FUNCTION 'TR_F4_REQUESTS'
      EXPORTING
        iv_username         = sy-uname
        iv_trfunctions      = 'KTCEO' ##NO_TEXT
      IMPORTING
        ev_selected_request = rv_trkorr.

  ENDMETHOD.

  METHOD batch_value_help.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_fields     TYPE dfies_tab,
      lt_valuetab   TYPE char10_t,
      lt_return_tab TYPE hrreturn_tab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Aide à la Recherche du Lot
    " -----------------------------------------------------------

    lt_fields = VALUE #(
      (
        tabname   = 'ZTBREQUEST_BATCH' ##NO_TEXT
        fieldname = 'ZEDBATCH'         ##NO_TEXT
      )
    ).

    " Récupération Liste des Lots éligibles
    SELECT zedbatch FROM ztbrequest_batch
     WHERE zedvalidated EQ @abap_false
       AND zedtrpdate   GE @sy-datum
       AND zedtrtdate   EQ @cl_fdt_date_time=>mc_date_initial
      INTO TABLE @lt_valuetab.

    " Aide à la recherche du Lot
    CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
      EXPORTING
        retfield        = 'ZEDBATCH' ##NO_TEXT
        window_title    = text-sba
      TABLES
        value_tab       = lt_valuetab
        field_tab       = lt_fields
        return_tab      = lt_return_tab
      EXCEPTIONS
        parameter_error = 1
        no_values_found = 2
        OTHERS          = 3.
    IF sy-subrc NE 0 OR lt_return_tab[] IS INITIAL.
      " Erreur appel Aide à la Recherche
      ""  --> Arrêt du traitement
      CLEAR : rv_batch.
      RETURN.

    ELSE.
      " Initialisation Lot sélectionné
      rv_batch = lt_return_tab[ 1 ]-fieldval.

    ENDIF.

  ENDMETHOD.

  METHOD at_selection_screen.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_existing TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " Raccourci d'écriture
    DATA(lo_creation) = REF #( me->ms_selection_criteria-creation ).

    " -----------------------------------------------------------
    " Suivant l'Action utilisateur
    " -----------------------------------------------------------

    IF iv_ucomm EQ 'CBATCH' ##NO_TEXT OR iv_ucomm EQ 'CHK'  ##NO_TEXT.
      " Réinitialise indicateur Vérification
      CLEAR : lo_creation->certification-ov_valid->*.

    ENDIF.

    IF lo_creation->object-ov_system_target->* NE 'PE1' ##NO_TEXT.
      " Réinitialisation
      CLEAR : lo_creation->batch-ov_batch->*, me->ms_work_area_private-batch-batch_create.
      CLEAR : lo_creation->option-ov_transport_express->*.

    ENDIF.

    " Traitement
    CASE iv_ucomm.

      WHEN 'CRI' ##NO_TEXT.
        " Coche Criticité
        ""  --> Mode manuelle
        me->ms_work_area_private-criticity-critic_man = abap_true.

      WHEN 'CBATCH'  ##NO_TEXT.
        " Création de Lot
        ""  --> Traitement Création de Lot
        me->ms_work_area_private-batch-batch_data = zcl_transport_request_batch=>batch_create(
          IMPORTING
            ev_existing = lv_existing
        ).

        ""  --> Modifie Coche Critique
        lo_creation->criticity-ov_critic->* = me->ms_work_area_private-batch-batch_data-zedcritic.

        ""  --> Modifie Coche Express
        lo_creation->option-ov_transport_express->* = me->ms_work_area_private-batch-batch_data-zedeligible.

        ""  --> Modifie Date de Transport
        lo_creation->time-ov_transport_date->* = me->ms_work_area_private-batch-batch_data-zedtrpdate.
        lo_creation->time-ov_transport_hour->* = me->ms_work_area_private-batch-batch_data-zedtrptime.

        ""  --> Indicateur Batch créé
        me->ms_work_area_private-batch-batch_create = xsdbool( lv_existing EQ abap_false ).

        ""  --> Retourne Numéro de Lot
        lo_creation->batch-ov_batch->* = me->ms_work_area_private-batch-batch_data-zedbatch.

      WHEN OTHERS.
        " Autre Commande
        IF  me->ms_work_area_private-batch-batch_create EQ abap_false
        AND lo_creation->batch-ov_batch->* NE me->ms_work_area_private-batch-batch_data-zedbatch.
          " On a changé de Lot
          ""  --> Recharge Information
          me->ms_work_area_private-batch-batch_data = CORRESPONDING #(
            zcl_transport_request_batch=>batch_get( lo_creation->batch-ov_batch->* )
          ).

          ""  --> Modifie Coche Critique
          lo_creation->criticity-ov_critic->* = me->ms_work_area_private-batch-batch_data-zedcritic.

          ""  --> Modifie Coche Express
          lo_creation->option-ov_transport_express->* = me->ms_work_area_private-batch-batch_data-zedeligible.

          ""  --> Modifie Date de Transport
          lo_creation->time-ov_transport_date->* = me->ms_work_area_private-batch-batch_data-zedtrpdate.
          lo_creation->time-ov_transport_hour->* = me->ms_work_area_private-batch-batch_data-zedtrptime.

        ENDIF.

    ENDCASE.

  ENDMETHOD.

  METHOD at_selection_screen_output.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    IF sy-tcode EQ 'ZBC_REQUEST_CHANGE'.
      " Transaction de Modification
      ""  --> Modifie affichage de l'onglet par défaut
      tab-dynnr = 3000.
      tab-activetab = 'UCOMM2' ##NO_TEXT.

    ENDIF.

    " -----------------------------------------------------------
    " Lors de l'affichage de l'écran de sélection
    " -----------------------------------------------------------

    " Initialisation Ecran affiché
    lcl_main=>ms_global_area_private-ov_screen->* = sy-dynnr.

    CASE lcl_main=>ms_global_area_private-ov_screen->*.

      WHEN lcl_main=>mc_dynnr-creation.
        " Création
        me->_at_selection_screen_out_crea( ).

      WHEN lcl_main=>mc_dynnr-execution.
        " Exécution
        me->_at_selection_screen_out_exec( ).

      WHEN lcl_main=>mc_dynnr-modification.
        " Modification
        me->_at_selection_screen_out_modif( ).

      WHEN OTHERS.
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD at_selection_screen_on_exit.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement lors de la sortie du programme
    " -----------------------------------------------------------

    " Libération élèment mémoire
    ""  --> Dernier onglet visualisé
    FREE MEMORY ID lcl_main=>mc_memory_id-tab_navigation.

    IF me->ms_work_area_private-display_element-o_ccontainer IS BOUND.
      " Libération de l'instance du Custom Container
      me->ms_work_area_private-display_element-o_ccontainer->free( ).
      cl_gui_cfw=>flush( ).
      FREE : me->ms_work_area_private-display_element-o_ccontainer.

    ENDIF.

  ENDMETHOD.

  METHOD _at_selection_screen_out_exec.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " ToDo
    " -----------------------------------------------------------



  ENDMETHOD.

  METHOD _at_selection_screen_out_modif.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " ToDo
    " -----------------------------------------------------------



  ENDMETHOD.

  METHOD _at_selection_screen_out_crea.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " Dans le cas où l'utilisateur saisie sans tout valider
    ""  --> Contrôle criticité
    me->criticity_check( ).

    " -----------------------------------------------------------
    " Modification Ecran de Sélection
    " -----------------------------------------------------------

    LOOP AT SCREEN INTO DATA(ls_screen).

      CASE ls_screen-group1.

        WHEN 'REC'.                                           ##NO_TEXT
          " Recette
          ls_screen-input = SWITCH #(
            xsdbool( ( me->ms_selection_criteria-creation-object-ov_system_target->* NE 'PE1' ##NO_TEXT
                      AND NOT me->ms_selection_criteria-creation-object-ov_system_target->* IS INITIAL )
              OR ( me->ms_selection_criteria-creation-object-ov_system_target->* EQ 'PE1'
               AND me->ms_selection_criteria-creation-option-ov_only_target_system->* EQ abap_false ) ) ##NO_TEXT
            WHEN abap_true THEN 1 ELSE 0
          ).

        WHEN 'BAT'.                                           ##NO_TEXT
          " Batch
          ls_screen-input = SWITCH #( xsdbool( me->ms_selection_criteria-creation-batch-ov_batch->* IS INITIAL )
            WHEN abap_true THEN 1 ELSE 0
          ).

        WHEN 'MAN'.                                           ##NO_TEXT
          " Mandatory
          ls_screen-input = 0.

        WHEN 'PRD'.                                           ##NO_TEXT
          " Production
          IF me->ms_selection_criteria-creation-object-ov_system_target->* EQ 'PE1' ##NO_TEXT.
            " Production
            IF ls_screen-name EQ 'P_EXPR' ##NO_TEXT.
              " Express
              ls_screen-input = SWITCH #( xsdbool( me->ms_selection_criteria-creation-batch-ov_batch->* IS INITIAL )
                WHEN abap_true THEN 1 ELSE 0
              ).

            ELSEIF ls_screen-name EQ 'P_CRITIC' ##NO_TEXT.
              " Critique
              ""  --> RG spécifique au Lot
              ls_screen-input = SWITCH #(
                xsdbool( NOT me->ms_selection_criteria-creation-batch-ov_batch->* IS INITIAL
                          OR me->ms_work_area_private-criticity-critic_auto EQ abap_true )
                  WHEN abap_true THEN 0 ELSE 1
              ).

            ENDIF.

          ELSE.
            " Autre
            ""  --> Désactive saisie
            ls_screen-input  = 0.

          ENDIF.

        WHEN OTHERS.
          " Autre
          ""  --> Passe à l'itération suivante
          CONTINUE.

      ENDCASE.

      " Modification de l'écran
      MODIFY screen FROM ls_screen.

    ENDLOOP.

  ENDMETHOD.

  METHOD at_selection_screen_end_ot.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle criticité de la Demande
    " -----------------------------------------------------------

    " Réinitialisation Validation
    CLEAR : me->ms_selection_criteria-creation-certification-ov_valid->*.

    " Contrôle la Criticité
    me->criticity_check( ).

  ENDMETHOD.

  METHOD request_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_listasci   TYPE list_string_table,
      lt_listobject TYPE table_abaplist.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
      lor_data       TYPE REF TO data,
      lo_salv_table  TYPE REF TO cl_salv_table,
      lor_line_descr TYPE REF TO cl_abap_datadescr.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_value>    TYPE any,
      <lfs_t_result> TYPE STANDARD TABLE.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération Route de Transport
    " -----------------------------------------------------------

    " Récupération des Environnements
    DATA(lt_transport_road) = zcl_transport_request_celio=>transport_road_get(
      iv_sysid      = iv_target_system
      iv_only_sysid = iv_only_target_system
    ).

    " -----------------------------------------------------------
    " Paramétrage pour récupération ALV résultat
    " -----------------------------------------------------------

    " Récuépration données & metadata
    cl_salv_bs_runtime_info=>set(
      data     = abap_true
      display  = abap_false
      metadata = abap_true
    ).

    " -----------------------------------------------------------
    " Lance le programme de contrôle
    " -----------------------------------------------------------

    " Programme de Contrôle
    SUBMIT z_a_bc_transport_check
      WITH s_trkorr IN ir_trkorr[]
      WITH p_sysid  EQ iv_target_system
      EXPORTING LIST TO MEMORY
       AND RETURN.

    TRY.
        " -----------------------------------------------------------
        " Récupération résultat du contrôle
        " -----------------------------------------------------------

        " Récupération données
        cl_salv_bs_runtime_info=>get_data_ref( IMPORTING r_data = lor_data ).
        IF lor_data IS BOUND.
          " Données présente
          ASSIGN lor_data->* TO <lfs_t_result>.

        ENDIF.
        IF NOT <lfs_t_result> IS ASSIGNED
        OR <lfs_t_result> IS INITIAL.
          " Pas de données
          ""  --> Arrêt du traitement
          rv_subrc = 0.
          RETURN.

        ENDIF.

        " Retourne indicateur présence erreur / avertissement
        LOOP AT <lfs_t_result> ASSIGNING FIELD-SYMBOL(<lfs_s_result>).

          ASSIGN COMPONENT 'TRKORR' ##NO_TEXT OF STRUCTURE <lfs_s_result> TO <lfs_value>.
          IF sy-subrc EQ 0 AND <lfs_value> IN s_trkorr[].
            " OT en cours de Transport
            ASSIGN COMPONENT 'OBJNAME' ##NO_TEXT OF STRUCTURE <lfs_s_result> TO <lfs_value>.
            IF sy-subrc EQ 0 AND <lfs_value> IS INITIAL.
              " OT non présent dans le système X
              ""  --> On s'assure que l'utilisateur va le transporter dans les autres environnements
              READ TABLE lt_transport_road WITH KEY table_line = 'RE1' ##NO_TEXT TRANSPORTING NO FIELDS.
              IF sy-subrc EQ 0.
                " L'OT va être transporté
                ""  --> Supprime de la liste de résultat
                DELETE <lfs_t_result> USING KEY loop_key.
                CONTINUE.

              ENDIF.

            ENDIF.

          ENDIF.

          " Message d'erreur ?
          ASSIGN COMPONENT 'TYPE' ##NO_TEXT OF STRUCTURE <lfs_s_result> TO <lfs_value>.
          IF sy-subrc EQ 0 AND <lfs_value> CA 'EAXIW' ##NO_TEXT.
            rv_subrc = 4.
          ENDIF.
        ENDLOOP.
        IF rv_subrc IS INITIAL.
          " Aucune erreur / avertissement
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

        " Récupération metadata
        DATA(ls_metadata) = cl_salv_bs_runtime_info=>get_metadata( ).

        " Réinitialisation capture ALV
        cl_salv_bs_runtime_info=>clear_all( ).

        TRY.
            " -----------------------------------------------------------
            " Affichage résultat dans une fenêtre modale
            " -----------------------------------------------------------

            " Génération instance ALV
            cl_salv_table=>factory(
              IMPORTING
                r_salv_table   = lo_salv_table
              CHANGING
                t_table        = <lfs_t_result>
            ).

            " Activation fonctions standards
            lo_salv_table->get_functions( )->set_all( abap_true ).

            DATA(lv_end_line) = lines( <lfs_t_result> ) + 1.
            IF lv_end_line GT 20. lv_end_line = 20. ENDIF.

            " Initialisation taille fenêtre modale
            lo_salv_table->set_screen_popup(
              start_line   = 1
              end_line     = lv_end_line
              start_column = 20
              end_column   = 160
            ).

            " Modification Affichage
            zcl_salv_utilities=>fieldcatalog_lvc_to_salv(
              EXPORTING
                it_fieldcatalog = ls_metadata-t_fcat
              CHANGING
                co_salv_table   = lo_salv_table
            ).

            " Modification intitulé
            lo_salv_table->get_display_settings( )->set_list_header(
              |Contrôle Demande|                              ##NO_TEXT
            ).

            " Affichage de l'ALV
            lo_salv_table->display( ).

          CATCH cx_salv_msg.

        ENDTRY.

      CATCH cx_salv_bs_sc_runtime_info.
        " Erreur récupération données
        ""  --> Le message du programme s'affiche quand même

    ENDTRY.

  ENDMETHOD.

  METHOD criticity_check.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_critic TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    IF me->ms_work_area_private-batch-batch_data-zedcritic EQ abap_true.
      " Lot critique
      ""  --> Rien à faire
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle la Criticité des OTs
    " -----------------------------------------------------------

    LOOP AT s_trkorr[] ASSIGNING FIELD-SYMBOL(<lfs_sr_trkorr>).

      " Contrôle la Criticité
      lv_critic = zcl_transport_request=>criticity_check( <lfs_sr_trkorr>-low ).

      IF lv_critic EQ abap_true.
        " OT critique
        ""  --> Initialisation Criticité
        me->ms_selection_criteria-creation-criticity-ov_critic->* = abap_true.

        ""  --> Arrêt de la boucle
        EXIT.

      ENDIF.

    ENDLOOP.

    " Initialisation Indicateur Criticité automatique
    me->ms_work_area_private-criticity-critic_auto = lv_critic.

    IF me->ms_work_area_private-criticity-critic_auto EQ abap_false.

      IF me->ms_work_area_private-criticity-critic_man EQ abap_true.
        " Critique Manuelle et Contrôle Crit vide
        ""  --> Ne pas changer

      ELSE.
        " Contrôle Criticité Vide
        ""  --> Réinitialise indicateur Criticité
        me->ms_selection_criteria-creation-criticity-ov_critic->* = abap_false.

      ENDIF.

    ELSEIF me->ms_work_area_private-criticity-critic_auto EQ abap_true.
      " Critique Auto
      ""  --> Réinitialise indicateur Critique Manuelle
      me->ms_work_area_private-criticity-critic_man = abap_false.

    ENDIF.

  ENDMETHOD.

  METHOD process.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'Onglet affiché
    " -----------------------------------------------------------

    " Stocke les informations du dernier onglet visité
    gs_tab_current = tab.
    EXPORT current_tab = gs_tab_current TO MEMORY ID lcl_main=>mc_memory_id-tab_navigation.

    " En fonction de l'Onglet
    CASE lcl_main=>ms_global_area_private-ov_screen->*.

      WHEN lcl_main=>mc_dynnr-creation.
        " Création
        me->process_request_creation( ).

      WHEN lcl_main=>mc_dynnr-modification.
        " Modification
        me->process_request_modification( ).

      WHEN lcl_main=>mc_dynnr-execution.
        " Exécution
        ""  --> Déclenche JOB de Transport
        me->process_transport_execute(
          iv_execution_date = me->ms_selection_criteria-execution-time-ov_datum->*
          iv_execution_time = me->ms_selection_criteria-execution-time-ov_uzeit->*
        ).

        ""  --> Affiche message
        MESSAGE s002(ztools) WITH text-ste DISPLAY LIKE if_msg_output=>msgtype_success.

      WHEN OTHERS.

    ENDCASE.

  ENDMETHOD.

  METHOD pai_dispatch.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Appel PBO
    " -----------------------------------------------------------

    lv_method = |_PAI_{ sy-dynnr }|. ##NO_TEXT

    TRY.
        " Méthode PBO
        CALL METHOD me->(lv_method)
          EXPORTING
            !iv_ucomm = iv_ucomm.

      CATCH cx_root.
    ENDTRY.

  ENDMETHOD.

  METHOD pbo_dispatch.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_method TYPE string.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Appel PBO
    " -----------------------------------------------------------

    lv_method = |_PBO_{ sy-dynnr }|. ##NO_TEXT

    TRY.
        " Méthode PBO
        CALL METHOD me->(lv_method).

      CATCH cx_root.
    ENDTRY.

  ENDMETHOD.

  METHOD _pbo_3100.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_modified  TYPE xsdboolean,
      lv_read_only TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation barre d'état
    " -----------------------------------------------------------

    " En fonction édition / lecture-seule
    lv_read_only = me->ms_selection_criteria-modification-transport_selection-ov_read_only->*.
    IF lv_read_only EQ abap_false.
      " Edition
      SET TITLEBAR 'TITLEBAR_3100' ##NO_TEXT.
      SET PF-STATUS 'PF_STATUS_3100' ##NO_TEXT.

    ELSE.
      " Lecture seule
      SET TITLEBAR 'TITLEBAR_3100_RO' ##NO_TEXT.
      SET PF-STATUS 'PF_STATUS_3100_RO' ##NO_TEXT.

    ENDIF.

    " -----------------------------------------------------------
    " Modification affichage
    " -----------------------------------------------------------

    LOOP AT SCREEN INTO DATA(ls_screen).

      IF lv_read_only EQ abap_true.
        ls_screen-input = 0.
        MODIFY screen FROM ls_screen.
        CONTINUE.

      ENDIF.

      " Suivant le premier groupe
      CASE ls_screen-group1.

        WHEN 'PRD' ##NO_TEXT.
          " Production
          IF me->ms_work_area_private-display_data-request-request->zedtargsys EQ 'PE1' ##NO_TEXT.
            " Production
            IF ls_screen-name EQ 'GS_REQUEST-ZEDELIGIBLE' ##NO_TEXT.
              " Express
              ls_screen-input = SWITCH #( xsdbool(
                  me->ms_work_area_private-display_data-request-request->zedreqbatch IS INITIAL )
                WHEN abap_true THEN 1 ELSE 0
              ).

            ENDIF.

          ELSE.
            " Autre
            ""  --> Désactive saisie
            ls_screen-input  = 0.

          ENDIF.

          " Initialisation flag modif
          lv_modified = abap_true.

        WHEN OTHERS.
          " Autre

      ENDCASE.

      " Suivant le troisième groupe
      CASE ls_screen-group3.

        WHEN 'CRI' ##NO_TEXT.
          " Criticité
          ""  --> RG spécifique au Lot
          ls_screen-input = SWITCH #(
            xsdbool( NOT me->ms_work_area_private-display_data-request-request->zedreqbatch IS INITIAL
                      OR me->ms_work_area_private-criticity-critic_auto EQ abap_true
                      OR line_exists( me->ms_work_area_private-display_data-sequence-t_sequence[ zedcritic = abap_true ] )
                      OR line_exists( me->ms_work_area_private-display_data-sequence-t_sequence[ zedcritic_auto = abap_true ] )
                   )
              WHEN abap_true THEN 0 ELSE 1
          ).

          " Initialisation flag modif
          lv_modified = abap_true.

        WHEN OTHERS.
          " Autre

      ENDCASE.

      " Suivant le quatrième groupe
      CASE ls_screen-group4.

        WHEN 'CHK' ##NO_TEXT.
          " Contrôle
          IF me->ms_work_area_private-display_data-has_error-transport_date EQ abap_true.
            " Erreur sur la Date
            SET CURSOR FIELD 'GS_REQUEST-ZEDTRPDATE' ##NO_TEXT.
            ls_screen-intensified = 1.
            ls_screen-color = 6.

          ELSE.
            " Aucune erreur
            ls_screen-color       = 0.
            ls_screen-intensified = 0.

          ENDIF.

          " Initialisation flag modif
          lv_modified = abap_true.

        WHEN OTHERS.
          " Autre

      ENDCASE.

      IF lv_modified EQ abap_true.
        " Modification de l'écran
        MODIFY screen FROM ls_screen.

      ENDIF.

    ENDLOOP.

    me->ms_work_area_private-display_element-o_alv_grid->set_user_command( i_ucomm = 'DUMMY' ).

  ENDMETHOD.

  METHOD _pai_3100.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_existing TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suivant l'action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE iv_ucomm.

      WHEN lcl_main=>mc_event-exit
        OR lcl_main=>mc_event-back
        OR lcl_main=>mc_event-leave.
        " Retour / Arrêt
        IF me->ms_work_area_private-display_data-request-has_pending_change  EQ abap_true
        OR me->ms_work_area_private-display_data-sequence-has_pending_change EQ abap_true.
          " Données modifiées non persistée
          ""  --> PopUp confirmation perte de données
          IF lcl_main=>call_popup_confirm_data_loss( ) EQ abap_true.
            " Oui
            ""  --> Sauvegarde
            me->_request_modification_save( ).

          ENDIF.

        ENDIF.

        " Suivant l'action utilisateur
        CASE iv_ucomm.

          WHEN lcl_main=>mc_event-leave.
            "  Arrêt
            ""  --> Interruption du traitement
            me->_request_modification_leave( abap_true ).

          WHEN OTHERS.
            " Retour
            ""  --> Retourne à l'écran précédent
            me->_request_modification_leave( ).

        ENDCASE.

      WHEN lcl_main=>mc_event-check.
        " Contrôle
        ""  --> Contrôle de la séquence
        me->_sequence_transport_check( ).

      WHEN lcl_main=>mc_event-save.
        " Sauvegarde
        ""  --> Sauvegarde
        me->_request_modification_save( ).

      WHEN lcl_main=>mc_event-delete.
        " Suppression
        ""  --> Suppression de la Demande
        me->_request_modification_delete( ).

      WHEN lcl_main=>mc_event-batch_create.
        " Création du Lot
        ""  --> Traitement Création de Lot
        me->ms_work_area_private-batch-batch_data = zcl_transport_request_batch=>batch_create(
          IMPORTING
            ev_existing = lv_existing
        ).

        ""  --> Modifie criticité
        me->ms_work_area_private-criticity-critic_man  = me->ms_work_area_private-batch-batch_data-zedcritic.
        me->ms_work_area_private-criticity-critic_auto = me->ms_work_area_private-batch-batch_data-zedcritic.

        ""  --> Modifie Coche Express
        me->ms_work_area_private-display_data-request-request->zedeligible = me->ms_work_area_private-batch-batch_data-zedeligible.

        ""  --> Modifie Date de Transport
        me->ms_work_area_private-display_data-request-request->zedtrpdate  = me->ms_work_area_private-batch-batch_data-zedtrpdate.
        me->ms_work_area_private-display_data-request-request->zedtrptime  = me->ms_work_area_private-batch-batch_data-zedtrptime.
        me->ms_work_area_private-display_data-request-request->zedreqbatch = me->ms_work_area_private-batch-batch_data-zedbatch.

        ""  --> Indicateur Batch créé
        me->ms_work_area_private-batch-batch_create = xsdbool( lv_existing EQ abap_false ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD call_popup_confirm_data_loss.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer TYPE c LENGTH 1.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " PopUp Confirmation perte de données
    " -----------------------------------------------------------

    " Affichage PopUp confirmation
    CALL FUNCTION 'POPUP_TO_CONFIRM_DATA_LOSS' ##NO_TEXT
      EXPORTING
        defaultoption = 'J' ##NO_TEXT
        titel         = text-dlo
        start_column  = 5
        start_row     = 6
      IMPORTING
        answer        = lv_answer.

    " Retourne booléen confirmation
    rv_confirmed = xsdbool( lv_answer EQ 'J' ).             ##NO_TEXT

  ENDMETHOD.

  METHOD call_popup_confirmation.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_answer TYPE c LENGTH 1.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " PopUp Confirmation
    " -----------------------------------------------------------

    " PopUp Confirmation
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = iv_titlebar
*       DIAGNOSE_OBJECT       = ' '
        text_question         = iv_text_question
        text_button_1         = text-tye
*       ICON_BUTTON_1         = ' '
        text_button_2         = text-tno
*       ICON_BUTTON_2         = ' '
*       DEFAULT_BUTTON        = '1'
        display_cancel_button = abap_true
*       USERDEFINED_F1_HELP   = ' '
        start_column          = 25
        start_row             = 6
*       POPUP_TYPE            =
      IMPORTING
        answer                = lv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
    IF NOT sy-subrc IS INITIAL.
      " Erreur
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Retourne booléen confirmation
    rv_confirmed = xsdbool( lv_answer EQ '1' ##NO_TEXT ).

  ENDMETHOD.

  METHOD process_request_creation.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_request_to_create TYPE lcl_main=>tt_request_to_create.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_type         TYPE ztbrequest-zedtrpcode,
      lv_critic       TYPE xsdboolean,
      lv_message      TYPE string,
      lv_tr_not_exist TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle cohérence saisie
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-creation-object-ov_system_target->* IS INITIAL.
      " Système cible obligatoire
      rv_subrc = 1.
      MESSAGE s002(ztools) WITH text-e03 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSEIF me->ms_selection_criteria-creation-object-or_trkorr->*[] IS INITIAL.
      " OT obligatoire
      rv_subrc = 2.
      MESSAGE s002(ztools) WITH text-e04 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSEIF me->ms_selection_criteria-creation-certification-ov_valid->* EQ abap_false.
      " Validation obligatoire
      rv_subrc = 3.
      MESSAGE s020(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    IF zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' )->attribute_value_get(
        iv_parameter_name = 'BATCH_CONFIGURATION'             ##NO_TEXT
        iv_attribute_name = 'MANDATORY'                       ##NO_TEXT
    )-key1 EQ abap_true AND me->ms_selection_criteria-creation-object-ov_system_target->* EQ 'PE1'    ##NO_TEXT
                        AND me->ms_selection_criteria-creation-batch-ov_batch IS INITIAL.
      " Passage en Prod et Lot Obligatoire
      rv_subrc = 4.
      MESSAGE s018(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Contrôle cohérence saisie
    READ TABLE me->ms_selection_criteria-creation-object-or_trkorr->*
      WITH KEY option = if_trba_selection_c=>gc_option_cp
          TRANSPORTING NO FIELDS.
    IF sy-subrc EQ 0.
      " Recherche sur Pattern non autorisée
      rv_subrc = 5.
      MESSAGE s000(zcunity) WITH text-e01 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    IF me->ms_selection_criteria-creation-criticity-ov_critic->* EQ abap_false.
      " Force le contrôle de Criticité (dans le doute que l'utilisateur n'ai rien Validé)
      LOOP AT me->ms_selection_criteria-creation-object-or_trkorr->*
         ASSIGNING FIELD-SYMBOL(<lfs_sr_trkorr>).

        IF zcl_transport_request=>criticity_check( <lfs_sr_trkorr>-low ) EQ abap_true.
          me->ms_work_area_private-criticity-critic_auto =
            me->ms_selection_criteria-creation-criticity-ov_critic->* = abap_true.

        ENDIF.

      ENDLOOP.

    ENDIF.

    " -----------------------------------------------------------
    " Vérification Criticité en DB
    " -----------------------------------------------------------

    IF  NOT me->ms_selection_criteria-creation-batch-ov_batch->* IS INITIAL
    AND me->ms_selection_criteria-creation-criticity-ov_critic->* EQ abap_true
    AND me->ms_work_area_private-criticity-critic_auto EQ abap_true.
      " Dans le Cas d'un Lot et de la présence d'un OT critique
      ""  --> Bascule le Lot en Critique
      UPDATE ztbrequest_batch SET zedcritic =  @abap_true
                            WHERE zedbatch  EQ @me->ms_selection_criteria-creation-batch-ov_batch->*.
      COMMIT WORK.

    ENDIF.

    " -----------------------------------------------------------
    " Vérification liés aux autres Demandes de Transport
    " -----------------------------------------------------------

    " Vérifie que les OTs ne sont pas déjà présent dans une autre Demande
    SELECT SINGLE seq~zedtrpord, seq~zedreqnb, request~zedreqbatch
      FROM ztborderseq AS seq
               INNER JOIN ztbrequest AS request
                       ON request~zedreqnb    EQ seq~zedreqnb
                    WHERE request~zedtargsys  EQ @me->ms_selection_criteria-creation-object-ov_system_target->*
                      AND seq~zedtrpord       IN @me->ms_selection_criteria-creation-object-or_trkorr->*
                      AND request~zedtrtdate  EQ '00000000'   ##NO_TEXT
                     INTO @DATA(ls_already).
    IF sy-subrc EQ 0.
      " Au moins un OT présent dans une autre Demande
      IF ls_already-zedreqbatch IS INITIAL.
        " Pas de Lot
        rv_subrc = 5.
        MESSAGE s023(ztools) DISPLAY LIKE if_msg_output=>msgtype_error
           WITH ls_already-zedtrpord ls_already-zedreqnb.

      ELSE.
        " Lot
        rv_subrc = 6.
        MESSAGE s024(ztools) DISPLAY LIKE if_msg_output=>msgtype_error
           WITH ls_already-zedtrpord ls_already-zedreqnb ls_already-zedreqbatch.

      ENDIF.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Vérification OT vide
    " -----------------------------------------------------------

    " Récupération liste Objet des OTs
    SELECT e071~trkorr AS trkorr,
      CASE WHEN main~strkorr NE @space THEN main~strkorr ELSE main~trkorr END AS trkorr_main
      FROM e071 INNER JOIN e070 AS main ON e071~trkorr EQ main~trkorr
     WHERE (     main~trkorr  IN @me->ms_selection_criteria-creation-object-or_trkorr->*
              OR main~strkorr IN @me->ms_selection_criteria-creation-object-or_trkorr->* )
       AND (     pgmid  NE @if_dms_constants=>orig_type_corr
             AND object NE @if_cts_organizer_constants=>activity_release )
      INTO TABLE @DATA(lt_e071).
    IF sy-subrc NE 0.
      " Aucun Objet
      ""  --> Arrêt du traitement
      rv_subrc = 7.
      MESSAGE s029(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    SORT lt_e071 BY trkorr_main.
    LOOP AT me->ms_selection_criteria-creation-object-or_trkorr->* ASSIGNING <lfs_sr_trkorr>.

      " OT contient des Objets ?
      READ TABLE lt_e071 WITH KEY trkorr_main = <lfs_sr_trkorr>-low
                     TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc NE 0.
        " OT non trouvé // OT Vide
        ""  --> Arrêt du traitement
        rv_subrc = 8.
        MESSAGE s030(ztools) WITH <lfs_sr_trkorr>-low DISPLAY LIKE if_msg_output=>msgtype_error.
        RETURN.

      ENDIF.

    ENDLOOP.

    " -----------------------------------------------------------
    " Préparation Liste des OTs
    " -----------------------------------------------------------

    " Récupération données des OTs
    SELECT trkorr, trfunction
      FROM e070 WHERE trkorr IN @me->ms_selection_criteria-creation-object-or_trkorr->*
             ORDER BY trkorr
           INTO TABLE @DATA(lt_e070).
    IF sy-subrc NE 0.
      " OT inexistant
      rv_subrc = 9.
      MESSAGE s002(ztools) WITH text-e04 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Récupération des OTs
    LOOP AT me->ms_selection_criteria-creation-object-or_trkorr->* ASSIGNING <lfs_sr_trkorr>.

      " L'OT existe ?
      READ TABLE lt_e070 WITH KEY trkorr = <lfs_sr_trkorr>-low
                        ASSIGNING FIELD-SYMBOL(<lfs_s_e070>)
                           BINARY SEARCH.
      IF sy-subrc NE 0.
        " Aucune correspondance
        ""  --> Passe à l'itération suivante
        lv_tr_not_exist = abap_true.
        MESSAGE ID 'TR' TYPE if_msg_output=>msgtype_error ##NO_TEXT
                      NUMBER 807 WITH <lfs_sr_trkorr>-low
                                 INTO lv_message.
        WRITE : lv_message, /.
        CONTINUE.

      ENDIF.

      IF me->ms_selection_criteria-creation-object-ov_transport_code->*
         EQ zcl_transport_request_celio=>mc_request_type-authorization.
        " Demande transport Authorisation
        lv_type = me->ms_selection_criteria-creation-object-ov_transport_code->*.

      ELSE.
        " En foncion de la Typologie de l'OT
        IF  <lfs_s_e070>-trfunction EQ if_cts_organizer_constants=>tr_type_customizing_request
        AND zcl_transport_request=>transport_is_auth( <lfs_sr_trkorr>-low ) EQ abap_true.
          " OT Auth
          ""  --> Ajout de l'OT dans table Auth
          lv_type = zcl_transport_request_celio=>mc_request_type-authorization.

        ELSE.
          " Développement // Custo
          ""  --> Ajout de l'OT dans table classique
          lv_type = zcl_transport_request_celio=>mc_request_type-classic.

        ENDIF.

      ENDIF.

      " Ajout de l'OT dans catégorie respective
      READ TABLE lt_request_to_create WITH KEY type = lv_type
                                     ASSIGNING FIELD-SYMBOL(<lfs_s_request_to_create>)
                                        BINARY SEARCH.
      IF sy-subrc NE 0.
        " Aucune correspondance
        ""  --> Création nouvelle entrée
        APPEND VALUE #(
          type = lv_type
        ) TO lt_request_to_create ASSIGNING <lfs_s_request_to_create>.

      ENDIF.

      " Ajout de l'OT
      APPEND <lfs_sr_trkorr>-low TO <lfs_s_request_to_create>-t_trkorr.

    ENDLOOP.

    IF lv_tr_not_exist EQ abap_true.
      " Au moins un OT n'existe pas
      ""  ---> Arrêt du traitement
      rv_subrc = 10.
      RETURN.

    ENDIF.

    IF me->ms_selection_criteria-creation-option-ov_check->* EQ abap_true.
      " -----------------------------------------------------------
      " Contrôle les objets de la Demande
      " -----------------------------------------------------------

      " Contrôle séquence
      IF me->request_check(
          ir_trkorr             = me->ms_selection_criteria-creation-object-or_trkorr->*
          iv_target_system      = me->ms_selection_criteria-creation-object-ov_system_target->*
          iv_only_target_system = me->ms_selection_criteria-creation-option-ov_only_target_system->*
        ) NE 0.
        " Erreur contrôle
        ""  --> PopUp validation création
        DATA : lv_answer TYPE char1.
        CALL FUNCTION 'POPUP_TO_CONFIRM'
          EXPORTING
            titlebar       = text-tt1
            text_question  = text-q01
            text_button_1  = 'Oui'(001)
            text_button_2  = 'Non'(002)
            default_button = '2'
          IMPORTING
            answer         = lv_answer
          EXCEPTIONS
            text_not_found = 1
            OTHERS         = 2.
        IF sy-subrc NE 0 OR lv_answer NE '1'.
          " Erreur création PopUp // Utilisateur ne souhaite pas poursuivre
          ""  --> Arrêt du traitement
          RETURN.

        ENDIF.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Création de(s) Demande(s)
    " -----------------------------------------------------------

    LOOP AT lt_request_to_create ASSIGNING <lfs_s_request_to_create>.

      " Création de la Demande
      DATA(lt_request) = zcl_transport_request_celio=>request_create(
        EXPORTING
          iv_type           = <lfs_s_request_to_create>-type
          iv_batch          = me->ms_selection_criteria-creation-batch-ov_batch->*
          it_trkorr         = <lfs_s_request_to_create>-t_trkorr
          iv_critic         = me->ms_selection_criteria-creation-criticity-ov_critic->*
          iv_express        = me->ms_selection_criteria-creation-option-ov_transport_express->*
          is_system         = VALUE #(
           mandt = sy-mandt
           sysid = me->ms_selection_criteria-creation-object-ov_system_target->*
          )
          is_transport_date = VALUE #(
            datum = me->ms_selection_criteria-creation-time-ov_transport_date->*
            uzeit = me->ms_selection_criteria-creation-time-ov_transport_hour->*
          )
          iv_only_sysid = me->ms_selection_criteria-creation-option-ov_only_target_system->*
      ).

      IF me->ms_work_area_private-batch-batch_create EQ abap_true.
        " Lot créé
        ""  --> Sauvegarde le Lot
        zcl_transport_request_batch=>batch_commit_db(
          me->ms_selection_criteria-creation-batch-ov_batch->*
        ).

      ENDIF.

      LOOP AT lt_request ASSIGNING FIELD-SYMBOL(<lfs_s_request>).

        IF <lfs_s_request_to_create>-type EQ zcl_transport_request_celio=>mc_request_type-authorization.
          WRITE : |{ <lfs_s_request>-sysid } : Demande Authorisation { <lfs_s_request>-zedreqnb } créé|, /. ##NO_TEXT

        ELSE.
          WRITE : |{ <lfs_s_request>-sysid } : Demande { <lfs_s_request>-zedreqnb } créé|, /. ##NO_TEXT

        ENDIF.

      ENDLOOP.

    ENDLOOP.

    IF me->ms_selection_criteria-creation-option-ov_launch_transport_job->* EQ abap_true.
      " -----------------------------------------------------------
      " Lancement du Job de Transport
      " -----------------------------------------------------------

      " Exécution du transport
      me->process_transport_execute( ).

    ENDIF.

  ENDMETHOD.

  METHOD process_transport_execute.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_jobname  TYPE tbtcjob-jobname,
      lv_jobcount TYPE tbtcjob-jobcount.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Création du Job de Transport
    " -----------------------------------------------------------

    " Initialisation Nom du Job
    lv_jobname = condense( |TRANSPORT_MAN_{ sy-uname }| ).  ##NO_TEXT

    " Ouverture JOB
    CALL FUNCTION 'JOB_OPEN'
      EXPORTING
        jobname   = lv_jobname
        sdlstrtdt = iv_execution_date
        sdlstrttm = iv_execution_time
      IMPORTING
        jobcount  = lv_jobcount
      EXCEPTIONS
        OTHERS    = 1.
    IF sy-subrc EQ 0.
      " Appel du Programme avec variante
      SUBMIT z_a_bc_transport_job
         VIA JOB lv_jobname
          NUMBER lv_jobcount
             AND RETURN.

      " Fermeture du Job
      CALL FUNCTION 'JOB_CLOSE'
        EXPORTING
          jobcount  = lv_jobcount
          jobname   = lv_jobname
          strtimmed = abap_true
        EXCEPTIONS
          OTHERS    = 1.

    ENDIF.

  ENDMETHOD.

  METHOD process_request_modification.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Réinitialise données
    CLEAR : me->ms_work_area_private-display_data.
    CLEAR : me->ms_work_area_private-request.
    CLEAR : me->ms_work_area_private-batch.
    CLEAR : me->ms_work_area_private-criticity.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_selection_criteria-modification-transport_selection-ov_request->*
      IS INITIAL.
      " Pas de numéro de Demande
      ""  --> Arrêt du traitement
      MESSAGE s002(ztools) WITH text-e11 DISPLAY LIKE if_msg_output=>msgtype_error.
      rv_subrc = 11.
      RETURN.

    ENDIF.

    " Récupération données de la Demande
    SELECT SINGLE REQUEST~*,
                  batch~zedcritic       AS batch_critic,
                  batch~zedvalidated    AS batch_validated
             FROM ztbrequest            AS request
       LEFT OUTER JOIN ztbrequest_batch AS batch ON batch~zedbatch = request~zedreqbatch
     WHERE zedreqnb EQ @me->ms_selection_criteria-modification-transport_selection-ov_request->*
      INTO @DATA(ls_request).
    IF sy-subrc NE 0.
      " Demande n'existe pas
      ""  --> Arrêt du traitement
      rv_subrc = 1.
      MESSAGE s002(ztools) WITH text-e05 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSEIF NOT ls_request-request-zedreqbatch IS INITIAL
       AND  ( ls_request-request-zedvalcode   EQ abap_true
          OR zcl_transport_request_batch=>batch_lock_check( ls_request-request-zedreqbatch ) EQ abap_true ).
      " Demande faisant parti d'un Lot validé
      ""  --> Arrêt du traitement
      rv_subrc = 8.
      MESSAGE s002(ztools) WITH text-e09 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSEIF ls_request-request-zedimport NE '9999' ##NO_TEXT.
      " Demande déjà transportée
      ""  --> Arrêt du traitement
      rv_subrc = 2.
      MESSAGE s002(ztools) WITH text-e06 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSEIF ls_request-request-zedvalcode EQ abap_false.
      " Demande déjà validée
      ""  --> Arrêt du traitement
      rv_subrc = 3.
      MESSAGE s002(ztools) WITH text-e07 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSEIF zcl_transport_request_celio=>request_lock_check( ls_request-request-zedreqnb ) EQ abap_true.
      " Demande en cours de traitement
      ""  --> Arrêt du traitement
      rv_subrc = 4.
      MESSAGE s002(ztools) WITH text-e08 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Blocages des élèments (Demande et Lot)
    " -----------------------------------------------------------

    " Blocage de la Demande
    IF zcl_transport_request_celio=>request_lock( ls_request-request-zedreqnb ) EQ abap_false.
      " Demande en cours de traitement
      ""  --> Arrêt du traitement
      rv_subrc = 5.
      MESSAGE s002(ztools) WITH text-e08 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    IF NOT ls_request-request-zedreqbatch IS INITIAL.
      " Lot
      ""  --> Blocage du Lot
      IF zcl_transport_request_batch=>batch_lock( ls_request-request-zedreqbatch ) EQ abap_false.
        " Lot en cours de traitement
        ""  --> Arrêt du traitement
        rv_subrc = 11.
        MESSAGE s316(cowipb) WITH ls_request-request-zedreqbatch DISPLAY LIKE if_msg_output=>msgtype_error.
        RETURN.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération de la séquence
    " -----------------------------------------------------------

    " Initialisation des données de la requête
    me->ms_work_area_private-request = CORRESPONDING #( ls_request-request ).
    me->ms_work_area_private-display_data-request-request = REF #( gs_request ).
    me->ms_work_area_private-display_data-request-request->* = me->ms_work_area_private-request.

    " Récupération des OT à transporter
    SELECT * FROM ztborderseq
     WHERE zedreqnb EQ @ls_request-request-zedreqnb
      ORDER BY zedreqnb, zedreqpos
      INTO TABLE @me->ms_work_area_private-display_data-sequence-t_sequence.

    " Récupération autres données
    LOOP AT me->ms_work_area_private-display_data-sequence-t_sequence
      ASSIGNING FIELD-SYMBOL(<lfs_s_sequence>).

      " Initialisation des données additionnels
      me->_request_mod_set_addit_data( CHANGING cs_display_data = <lfs_s_sequence> ).

    ENDLOOP.

    " Initialisation flag criticité de la Demande
    ""  --> Critique
    me->ms_work_area_private-criticity-critic_man = xsdbool(
      ls_request-request-zedreqcritic EQ abap_true
        OR
      line_exists( me->ms_work_area_private-display_data-sequence-t_sequence[ zedcritic = abap_true ] )
        OR
      line_exists( me->ms_work_area_private-display_data-sequence-t_sequence[ zedcritic_auto = abap_true ] )

    ).

    ""  --> Critique Auto
    me->ms_work_area_private-criticity-critic_auto = xsdbool(
      ls_request-batch_critic EQ abap_true
        OR
       line_exists( me->ms_work_area_private-display_data-sequence-t_sequence[ zedcritic_auto = abap_true ] )
    ).

    " Initialisation données du Lot
    me->ms_work_area_private-batch-batch_data-zedbatch  = ls_request-request-zedreqbatch.
    me->ms_work_area_private-batch-batch_data-zedcritic = ls_request-batch_critic.

    " Historise la version d'origine (pour contrôle)
    me->ms_work_area_private-display_data-sequence-history-o_history = zcl_itab_history=>factory(
      it_data                 = REF #( me->ms_work_area_private-display_data-sequence-t_sequence )
      iv_history_version_max  = lcl_main=>mc_sequence-history-version_max
      iv_store_original_as_v0 = abap_true
    ).

    " Ajout de la version dans l'historique
    me->_sequence_history_save( ).

    " -----------------------------------------------------------
    " Affichage des élèments
    " -----------------------------------------------------------

    " Affichage de la séquence
    me->request_modification_display( ).

  ENDMETHOD.

  METHOD request_modification_display.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_fieldcat TYPE slis_t_fieldcat_alv.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_col_pos   TYPE slis_fieldcat_alv-col_pos,
      lv_edit_mode TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    TRY.
        " -----------------------------------------------------------
        " Affichage de la liste
        " -----------------------------------------------------------

        " Mode Edition ?
        lv_edit_mode = xsdbool( me->ms_selection_criteria-modification-transport_selection-ov_read_only->*
          EQ abap_false ).

        " Initialisation du Layout
        me->ms_work_area_private-display_element-s_layout-edit      = abap_false.
        me->ms_work_area_private-display_element-s_layout-zebra     = abap_false.
        me->ms_work_area_private-display_element-s_layout-edit_mode = lv_edit_mode.
        .

        IF me->ms_work_area_private-display_element-o_ccontainer IS BOUND.
          " Custom Container déjà instancié
          ""  --> Libération du CContainer
          me->ms_work_area_private-display_element-o_ccontainer->free(
            EXCEPTIONS
              cntl_error        = 1
              cntl_system_error = 2
              OTHERS            = 4
          ).

          FREE : me->ms_work_area_private-display_element-o_ccontainer.

          " Synchronise le client de l'utilisateur
          cl_gui_cfw=>flush(
            EXCEPTIONS
              cntl_error        = 0
              cntl_system_error = 0
          ).

        ENDIF.

        " Création du Custom Container -
        CREATE OBJECT me->ms_work_area_private-display_element-o_ccontainer
          EXPORTING
            container_name              = 'CC_ALV_REQUEST_MOD_SEQUENCE' ##NO_TEXT
          EXCEPTIONS
            cntl_error                  = 1
            cntl_system_error           = 2
            create_error                = 3
            lifetime_error              = 4
            lifetime_dynpro_dynpro_link = 5
            OTHERS                      = 6.
        IF sy-subrc EQ 0.
          " Création de la Grille ALV
          CREATE OBJECT me->ms_work_area_private-display_element-o_alv_grid
            EXPORTING
              i_parent          = me->ms_work_area_private-display_element-o_ccontainer
              i_appl_events     = abap_true
            EXCEPTIONS
              error_cntl_create = 1
              error_cntl_init   = 2
              error_cntl_link   = 3
              error_dp_create   = 4
              OTHERS            = 5.

        ENDIF.

        IF sy-subrc EQ 0.
          " -----------------------------------------------------------
          " Préparation du FieldCatalog
          " -----------------------------------------------------------

          " Récupération FC de la structure principale
          CALL FUNCTION 'REUSE_ALV_FIELDCATALOG_MERGE'
            EXPORTING
              i_program_name         = sy-repid
              i_structure_name       = 'ZTBORDERSEQ' ##NO_TEXT
              i_internal_tabname     = 'ZTBORDERSEQ' ##NO_TEXT
              i_client_never_display = abap_true
            CHANGING
              ct_fieldcat            = lt_fieldcat
            EXCEPTIONS
              inconsistent_interface = 1
              program_error          = 2
              error_message          = 3
              OTHERS                 = 4.
          IF sy-subrc EQ 0.
            " FC récupéré
            ""  --> Move-cast
            me->ms_work_area_private-display_element-t_fieldcatalog = CORRESPONDING #( lt_fieldcat
              MAPPING
                scrtext_l = seltext_l
                scrtext_m = seltext_m
                scrtext_s = seltext_s
             ).

          ENDIF.

          " Ajout des élèments non présent dans la table de séquence
          APPEND LINES OF VALUE lvc_t_fcat(
            (
              " Libéré le
              fieldname = 'RELEASED_ON' ##NO_TEXT
              scrtext_s = CONV #( text-cro )
              scrtext_m = CONV #( text-cro )
              scrtext_l = CONV #( text-cro )
            )
            (
              " Transportée en Recette le
              fieldname = 'TRANSPORTED_QA_ON' ##NO_TEXT
              scrtext_s = CONV #( text-cto )
              scrtext_m = CONV #( text-cto )
              scrtext_l = CONV #( text-cto )
            )
          ) TO me->ms_work_area_private-display_element-t_fieldcatalog.

          " Modification du FC
          LOOP AT me->ms_work_area_private-display_element-t_fieldcatalog
            ASSIGNING FIELD-SYMBOL(<lfs_s_fieldcatalog>).

            " Incrément du nombre de la position
            ADD 1 TO lv_col_pos.

            " Suivant le nom du champ
            CASE <lfs_s_fieldcatalog>-fieldname.

              WHEN 'ZEDCRITIC' ##NO_TEXT.
                " Critique
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-edit     = lv_edit_mode.
                <lfs_s_fieldcatalog>-col_opt  = abap_true.
                <lfs_s_fieldcatalog>-checkbox = abap_true.

              WHEN 'ZEDCRITIC_AUTO' ##NO_TEXT.
                " Critique automatique
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-no_out = abap_true.

              WHEN 'ZEDREQNB' ##NO_TEXT.
                " Numéro de la Demande
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-no_out = abap_true.

              WHEN 'ZEDREQPOS' ##NO_TEXT.
                " Numéro de séquence de la Demande
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-no_out = abap_true.

              WHEN 'ZEDTRPORD' ##NO_TEXT.
                " Numéro OT
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-edit       = lv_edit_mode.
                <lfs_s_fieldcatalog>-f4availabl = abap_true.

              WHEN 'ZEDWORDING' ##NO_TEXT.
                " Désignation OT
                ""  --> Modifie la colonne

              WHEN 'RELEASED_ON' ##NO_TEXT.
                " Libéré le
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-col_pos   = lv_col_pos.
                <lfs_s_fieldcatalog>-col_opt   = abap_true.
                <lfs_s_fieldcatalog>-edit_mask = '==TSTPS' ##NO_TEXT.

              WHEN 'TRANSPORTED_QA_ON' ##NO_TEXT.
                " Transporté en Recette le
                ""  --> Modifie la colonne
                <lfs_s_fieldcatalog>-col_pos   = lv_col_pos.
                <lfs_s_fieldcatalog>-col_opt   = abap_true.
                <lfs_s_fieldcatalog>-edit_mask = '==TSTPS' ##NO_TEXT.

              WHEN OTHERS.
                " Autre
                ""  --> Passe à l'itération suivante
                CONTINUE.

            ENDCASE.

          ENDLOOP.

          " -----------------------------------------------------------
          " Toolbar - Exclusion des fonctions
          " -----------------------------------------------------------

          " Exclusion des fonctions de la barre de tâche
          me->ms_work_area_private-display_element-t_toolbar_excluding = VALUE #(
            ( cl_gui_alv_grid=>mc_fc_sum )
            ( cl_gui_alv_grid=>mc_fc_sort )
            ( cl_gui_alv_grid=>mc_mb_sum )
            ( cl_gui_alv_grid=>mc_fc_info )
            ( cl_gui_alv_grid=>mc_fc_graph )
            ( cl_gui_alv_grid=>mc_fc_count )
            ( cl_gui_alv_grid=>mc_fc_subtot )
            ( cl_gui_alv_grid=>mc_mb_variant )
            ( cl_gui_alv_grid=>mc_fc_average )
            ( cl_gui_alv_grid=>mc_fc_sort_asc )
            ( cl_gui_alv_grid=>mc_fc_sort_dsc )
            ( cl_gui_alv_grid=>mc_fc_loc_copy_row )
            ( cl_gui_alv_grid=>mc_fc_col_optimize )
            ( cl_gui_alv_grid=>mc_fc_col_invisible )
            ( cl_gui_alv_grid=>mc_fc_variant_admin )
            ( cl_gui_alv_grid=>mc_fc_current_variant )
          ).

          IF lv_edit_mode EQ abap_false.
            " Lecture-seule
            ""  --> Retrait des fonctions de modifications
            APPEND LINES OF VALUE ui_functions(
              ( cl_gui_alv_grid=>mc_fc_loc_cut )
              ( cl_gui_alv_grid=>mc_fc_loc_undo )
              ( cl_gui_alv_grid=>mc_fc_loc_copy )
              ( cl_gui_alv_grid=>mc_fc_loc_paste )
              ( cl_gui_alv_grid=>mc_fc_loc_copy_row )
              ( cl_gui_alv_grid=>mc_fc_loc_move_row )
              ( cl_gui_alv_grid=>mc_fc_loc_append_row )
              ( cl_gui_alv_grid=>mc_fc_loc_insert_row )
              ( cl_gui_alv_grid=>mc_fc_loc_delete_row )
              ( cl_gui_alv_grid=>mc_fc_loc_paste_new_row )
            ) TO me->ms_work_area_private-display_element-t_toolbar_excluding.

          ENDIF.

          " -----------------------------------------------------------
          " Préparation de l'ALV
          " -----------------------------------------------------------

          " Préparation de l'affichage
          me->ms_work_area_private-display_element-o_alv_grid->set_table_for_first_display(
            EXPORTING
              is_layout                     = me->ms_work_area_private-display_element-s_layout
              it_toolbar_excluding          = me->ms_work_area_private-display_element-t_toolbar_excluding
            CHANGING
              it_outtab                     = me->ms_work_area_private-display_data-sequence-t_sequence
              it_fieldcatalog               = me->ms_work_area_private-display_element-t_fieldcatalog
            EXCEPTIONS
              invalid_parameter_combination = 1
              program_error                 = 2
              too_many_lines                = 3
              OTHERS                        = 4
          ).

        ENDIF.
        IF sy-subrc NE 0.
          " Erreur lors de la génération de l'ALV
          ""  --> Arrêt du traitement
          rv_subrc = 99.
          RETURN.

        ENDIF.

        " Active Edition de l'ALV
        CALL METHOD me->ms_work_area_private-display_element-o_alv_grid->set_ready_for_input
          EXPORTING
            i_ready_for_input = 1.

        " -----------------------------------------------------------
        " Evènement - Souscription aux évènements
        " -----------------------------------------------------------

        " Validation via la touche Entrée
        CALL METHOD me->ms_work_area_private-display_element-o_alv_grid->register_edit_event
          EXPORTING
            i_event_id = cl_gui_alv_grid=>mc_evt_enter.

        CALL METHOD me->ms_work_area_private-display_element-o_alv_grid->register_edit_event
          EXPORTING
            i_event_id = cl_gui_alv_grid=>mc_evt_modified.

        " Souscription évènement
        " --> Action utilisateur
        SET HANDLER me->alv_handler_user_command FOR me->ms_work_area_private-display_element-o_alv_grid.

        ""  --> Aide à la Recherche - Liste
        CALL METHOD me->ms_work_area_private-display_element-o_alv_grid->register_f4_for_fields
          EXPORTING
            it_f4 = VALUE #(
              (
                fieldname  = 'ZEDTRPORD' ##NO_TET
                register   = abap_true
                chngeafter = abap_true
              )
            ).

        ""  --> Aide à la Recherche
        SET HANDLER me->alv_handler_onf4 FOR me->ms_work_area_private-display_element-o_alv_grid.

        ""  --> Modifications
        SET HANDLER me->alv_handler_data_changed     FOR me->ms_work_area_private-display_element-o_alv_grid.
        SET HANDLER me->alv_handler_changed_finished FOR me->ms_work_area_private-display_element-o_alv_grid.

        " Ajout des boutons spécifiques
        SET HANDLER me->alv_handler_toolbar FOR me->ms_work_area_private-display_element-o_alv_grid.
        me->ms_work_area_private-display_element-o_alv_grid->set_toolbar_interactive( ).

        " -----------------------------------------------------------
        " Affichage de l'ALV
        " -----------------------------------------------------------

        " Affiche la séquence
        CALL SCREEN 3100.

      CATCH cx_root INTO DATA(lo_cx_root).
        " Erreur lors de la génération de l'ALV
        ""  --> Arrêt du traitement
        rv_subrc = 99.
        RETURN.

    ENDTRY.

  ENDMETHOD.

  METHOD _request_modification_save.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_orderseq TYPE STANDARD TABLE OF ztborderseq WITH EMPTY KEY.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_valid           TYPE xsdboolean,
      lv_critic_auto     TYPE xsdboolean,
      lov_request_number TYPE REF TO ztbrequest-zedreqnb.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Raccourci
    lov_request_number = me->ms_selection_criteria-modification-transport_selection-ov_request.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    " Contrôle données Demande
    lv_valid = xsdbool( me->_request_modification_check( ) IS INITIAL ).
    IF lv_valid EQ abap_true.
      " Données Demande correcte
      ""  --> Contrôle données saisies Séquence
      me->ms_work_area_private-display_element-o_alv_grid->check_changed_data(
        IMPORTING
          e_valid   = lv_valid
      ).

    ENDIF.

    IF lv_valid EQ abap_false
    OR me->ms_work_area_private-display_data-sequence-has_error       EQ abap_true
    OR me->ms_work_area_private-display_data-has_error-transport_date EQ abap_true.
      " Au moins une erreur présente
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF  me->ms_work_area_private-display_data-request-has_pending_change  EQ abap_false
    AND me->ms_work_area_private-display_data-sequence-has_pending_change EQ abap_false.
      " Aucune modification
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Confirmation avant la sauvegarde
    " -----------------------------------------------------------

    " Confirmation ?
    IF lcl_main=>call_popup_confirmation(
        iv_titlebar      = text-tbs
        iv_text_question = text-tqs
      ) EQ abap_false.
      " L'utilisateur n'a pas confirmé la sauvegarde
      ""  --> Arrêt du traitement
      MESSAGE s002(ztools) WITH text-i01 DISPLAY LIKE if_msg_output=>msgtype_warning.
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Prépration des données
    " -----------------------------------------------------------

    " Préparation des entrées
    LOOP AT me->ms_work_area_private-display_data-sequence-t_sequence
      ASSIGNING FIELD-SYMBOL(<lfs_s_sequence>).

      IF <lfs_s_sequence>-zedtrpord IS INITIAL.
        " Pas d'OT
        ""  --> Passe à l'itération suivante
        CONTINUE.

      ENDIF.

      " Ajout de l'entrée
      APPEND CORRESPONDING #( <lfs_s_sequence> ) TO lt_orderseq ASSIGNING FIELD-SYMBOL(<lfs_s_order_seq>).

      " Modification de la position
      <lfs_s_order_seq>-zedreqpos = CONV #( sy-tabix ).

      " Flag criticité
      <lfs_s_order_seq>-zedcritic = me->ms_work_area_private-criticity-critic_man.

      " Criticité auto
      <lfs_s_order_seq>-zedcritic_auto = xsdbool(
           me->ms_work_area_private-criticity-critic_auto EQ abap_true
        OR zcl_transport_request=>criticity_check( <lfs_s_order_seq>-zedtrpord ) ).
      IF <lfs_s_order_seq>-zedcritic_auto EQ abap_true.
        " Objet critique à transporter
        ""  --> Initialisation flag criticité
        lv_critic_auto = abap_true.

      ENDIF.

    ENDLOOP.

    TRY.
        " -----------------------------------------------------------
        " Mise à jour en DB
        " -----------------------------------------------------------

        " Suppression des entrées
        DELETE FROM ztborderseq
         WHERE zedreqnb EQ @lov_request_number->*.

        " Ajout des entrées
        INSERT ztborderseq FROM TABLE @lt_orderseq.

        IF me->ms_work_area_private-batch-batch_create EQ abap_true.
          " Lot créé
          " --> Ajout du Lot en DB
          zcl_transport_request_batch=>batch_commit_db(
              iv_batch  = me->ms_work_area_private-batch-batch_data-zedbatch
              iv_commit = abap_false
          ).

        ENDIF.

        IF lv_critic_auto EQ abap_true.
          " Criticité
          ""  --> Modification de la criticité
          me->ms_work_area_private-display_data-request-request->zedreqcritic = abap_true.

          IF me->ms_work_area_private-display_data-request-request->* NE me->ms_work_area_private-request.
            " Données Demande modifié
            ""  --> Indicateur données modifiées
            me->ms_work_area_private-display_data-request-has_pending_change = abap_true.

          ENDIF.

          IF  me->ms_work_area_private-batch-batch_data-zedcritic EQ abap_false
          AND NOT me->ms_work_area_private-batch-batch_data-zedbatch IS INITIAL.
            " Lot non critique
            ""  --> Force la criticité
            UPDATE ztbrequest_batch SET zedcritic = @abap_true
                                  WHERE zedbatch EQ @me->ms_work_area_private-batch-batch_data-zedbatch.

          ENDIF.

        ENDIF.

        IF me->ms_work_area_private-display_data-request-has_pending_change EQ abap_true.
          ""  --> Modification en DB
          MODIFY ztbrequest FROM me->ms_work_area_private-display_data-request-request->*.

        ENDIF.

        " Demande modifiée
        MESSAGE s002(ztools) WITH text-s02.

        " Commit
        COMMIT WORK AND WAIT.

      CATCH cx_root.
        " Erreur lors de la modification en DB
        rv_subrc = 1.
        MESSAGE s002(ztools) WITH text-edb DISPLAY LIKE if_msg_output=>msgtype_error.
        ROLLBACK WORK.
        RETURN.

    ENDTRY.

    " -----------------------------------------------------------
    " Post-Traitement
    " -----------------------------------------------------------

    " Déblocage de la Demande
    zcl_transport_request_celio=>request_unlock( lov_request_number->* ).

    " Déblocage du Lot
    zcl_transport_request_batch=>batch_unlock( me->ms_work_area_private-batch-batch_data-zedbatch ).

    " Réinitialise témoin de modification
    me->ms_work_area_private-display_data-request-has_pending_change  = abap_false.
    me->ms_work_area_private-display_data-sequence-has_pending_change = abap_false.

    " Retour à l'écran de sélection
    me->_request_modification_leave( ).

  ENDMETHOD.

  METHOD _request_modification_delete.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Suppression de la Demande
    " -----------------------------------------------------------

    IF me->ms_work_area_private-display_data-request-request->zedreqnb IS INITIAL.
      " Pas de demande
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    IF NOT zcl_transport_request_celio=>request_delete(
        me->ms_work_area_private-display_data-request-request->zedreqnb ) IS INITIAL.
      " Erreur suppression
      MESSAGE s039(rsbk) DISPLAY LIKE if_msg_output=>msgtype_error WITH me->ms_work_area_private-display_data-request-request->zedreqnb.

    ELSE.
      " Suppression effectuée
      ""  --> Retour à l'écran de sélection
      MESSAGE s257(pwww).
      me->_request_modification_leave( ).

    ENDIF.

  ENDMETHOD.

  METHOD _request_modification_leave.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Arrêt du programme
    " -----------------------------------------------------------

    " Exécute traitement sortie de la transaction
    me->at_selection_screen_on_exit( ).

    IF iv_leave_transaction EQ abap_true.
      " Arrêt de la transaction
      ""  --> Arrêt du programme
      LEAVE PROGRAM.

    ELSE.
      " Arrêt de la transaction
      LEAVE TO SCREEN 0.

    ENDIF.

  ENDMETHOD.

  METHOD alv_handler_toolbar.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    IF me->ms_selection_criteria-modification-transport_selection-ov_read_only->* EQ abap_false.
      " Edition

      " -----------------------------------------------------------
      " Ajout des boutons spécifiques à l'édition
      " -----------------------------------------------------------

      INSERT LINES OF VALUE ttb_button(
        (
          " Move-up
          function   = lcl_main=>mc_function-move_up
          icon       = text-imu
          quickinfo  = text-fmu
          butn_type  = cntb_btype_button
        )
        (
          " Move-down
          function   = lcl_main=>mc_function-move_down
          icon       = text-imd
          quickinfo  = text-fmd
          butn_type  = cntb_btype_button
        )
        (
          " Séparateur
          butn_type  = cntb_btype_sep
        )
      ) INTO e_object->mt_toolbar INDEX 1.

      " -----------------------------------------------------------
      " Remplacement des fonctions standards
      " -----------------------------------------------------------

      " Bouton Annuler
      READ TABLE e_object->mt_toolbar WITH KEY function = cl_gui_alv_grid=>mc_fc_loc_undo
                                     ASSIGNING FIELD-SYMBOL(<lfs_s_toolbar>).
      IF sy-subrc EQ 0.
        " Correspondance trouvée
        ""  --> Modification de la fonction
        <lfs_s_toolbar>-function = lcl_main=>mc_function-undo.
        <lfs_s_toolbar>-disabled = xsdbool(
              me->ms_work_area_private-display_data-sequence-history-version_current       LT 1
           OR (     me->ms_work_area_private-display_data-sequence-history-version_current EQ 1
                AND me->ms_work_area_private-display_data-sequence-has_pending_change      EQ abap_false )
        ).

        ""  --> Création bouton "Répeter"
        INSERT VALUE #(
          " Remettre
          function   = lcl_main=>mc_function-redo
          icon       = text-ire
          quickinfo  = text-fre
          butn_type  = cntb_btype_button
          disabled   = xsdbool( me->ms_work_area_private-display_data-sequence-history-redo_enabled EQ abap_false )
        ) INTO e_object->mt_toolbar INDEX sy-tabix + 1.

      ENDIF.

    ENDIF.

    " -----------------------------------------------------------
    " Ajout des boutons spécifiques commun
    " -----------------------------------------------------------

    " Bouton Contrôler
    READ TABLE e_object->mt_toolbar WITH KEY function = cl_gui_alv_grid=>mc_fc_check
                                   ASSIGNING <lfs_s_toolbar>.
    IF sy-subrc EQ 0.
      " Correspondance trouvée
      ""  --> Modification de la fonction
      <lfs_s_toolbar>-function = lcl_main=>mc_function-check.

    ELSE.
      " Pas de correspondance
      ""  --> Ajout bouton Contrôler
      INSERT VALUE #(
        function = lcl_main=>mc_function-check
        icon       = text-ick
        quickinfo  = text-fck
        butn_type  = cntb_btype_button
      ) INTO e_object->mt_toolbar INDEX 4.

    ENDIF.

  ENDMETHOD.

  METHOD alv_handler_user_command.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement de l'action utilisateur
    " -----------------------------------------------------------

    " Suivant l'action utilisateur
    CASE e_ucomm.

      WHEN lcl_main=>mc_function-move_up
        OR lcl_main=>mc_function-move_down.
        " Monter // Descendre
        me->_sequence_move_order( xsdbool( e_ucomm EQ lcl_main=>mc_function-move_up ) ).

      WHEN lcl_main=>mc_function-check.
        " Contrôle
        IF me->_sequence_transport_check( ) IS INITIAL.
          " Séquence correcte
          MESSAGE s026(zbc).

        ENDIF.

      WHEN lcl_main=>mc_function-undo.
        " Annuler
        me->_sequence_undo( ).

      WHEN lcl_main=>mc_function-redo.
        " Répéter
        me->_sequence_redo( ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD alv_handler_onf4.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_t_data> TYPE lvc_t_modi.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Aide à la Recherche
    " -----------------------------------------------------------

    " Initialisation FS
    ASSIGN er_event_data->m_data->* TO <lfs_t_data>.

    " Suivant le champ d'Aide à la Recherche
    CASE e_fieldname.

      WHEN 'ZEDTRPORD' ##NO_TEXT.
        " OT
        ""  --> Aide à la recherche OT
        APPEND VALUE #(
          row_id    = es_row_no-row_id
          fieldname = e_fieldname
          value     = lcl_main=>trkorr_value_help( )
        ) TO <lfs_t_data>.

        ""  --> Evènement catché
        er_event_data->m_event_handled = abap_true.

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD alv_handler_data_changed.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_protocol TYPE lvc_t_msg1.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_check_done     TYPE xsdboolean,
      lv_pending_change TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    IF e_onf4 EQ abap_true.
      " -----------------------------------------------------------
      " Aide à la Recherche
      " -----------------------------------------------------------

      " Traitement sur Aide à la Recherche
      CASE abap_true.

        WHEN e_onf4_after.
          " Après l'aide à la Recherche

        WHEN e_onf4_before.
          " Avant l'aide à la Recherche

        WHEN OTHERS.
          " Autre

      ENDCASE.

    ELSEIF NOT e_ucomm IS INITIAL AND NOT e_ucomm EQ lcl_main=>mc_event-dummy.
      " -----------------------------------------------------------
      " Action utilisateur
      " -----------------------------------------------------------

      " Action utilisateur
      CASE e_ucomm.

        WHEN cl_gui_alv_grid=>mc_fc_check.
          " Contrôle
          ""  --> Séquence
          lt_protocol = me->_sequence_modification_check( er_data_changed ).

          ""  --> Cohérence
          me->_sequence_transport_check( ).

        WHEN OTHERS.
          " Autre
          ""  --> Pas de traitement

      ENDCASE.

    ELSE.
      " -----------------------------------------------------------
      " Saisie
      " -----------------------------------------------------------

      " Contrôle
      lt_protocol = me->_sequence_modification_check( er_data_changed ).

      ""  --> Contrôle effectuée
      lv_check_done = abap_true.

    ENDIF.

    " -----------------------------------------------------------
    " Contrôle si modification
    " -----------------------------------------------------------

    IF er_data_changed IS BOUND.
      " Pas encore de changement identifié
      ""  --> Des changements ont-ils effectués ?
      lv_pending_change = xsdbool(
          NOT er_data_changed->mp_mod_rows      IS INITIAL
       OR NOT er_data_changed->mt_mod_cells     IS INITIAL
       OR NOT er_data_changed->mt_good_cells    IS INITIAL
       OR NOT er_data_changed->mt_deleted_rows  IS INITIAL
       OR NOT er_data_changed->mt_inserted_rows IS INITIAL
     ).

    ENDIF.

    IF lv_pending_change EQ abap_true.
      " Changement apportée
      ""  --> Modification de l'indicateur
      me->ms_work_area_private-display_data-sequence-has_pending_change = lv_pending_change.

      IF e_ucomm NE lcl_main=>mc_event-dummy.
        IF lv_check_done EQ abap_false.
          "  Contrôle pas encore effectuée et changement apportée
          ""  --> Exécute contrôle
          lt_protocol = me->_sequence_modification_check( er_data_changed ).

        ENDIF.

        ""  --> Flag nouvelle modification
        me->ms_work_area_private-display_data-sequence-newly_change = abap_true.

      ENDIF.

    ENDIF.

    IF me->ms_work_area_private-display_data-sequence-has_error EQ abap_false.
      " Pas d'erreur identifié
      ""  --> Présence d'erreur ?
      me->ms_work_area_private-display_data-sequence-has_error = xsdbool( NOT lt_protocol[] IS INITIAL ).

    ENDIF.

    IF NOT lt_protocol[] IS INITIAL
    AND er_data_changed IS BOUND.
      " Erreur détecté
      ""  --> Ajout des entrées dans le protocole
      SORT lt_protocol BY row_id fieldname.
      DELETE ADJACENT DUPLICATES FROM lt_protocol COMPARING row_id fieldname.
      LOOP AT lt_protocol ASSIGNING FIELD-SYMBOL(<lfs_s_protocol>).
        er_data_changed->add_protocol_entry(
          i_msgid     = <lfs_s_protocol>-msgid
          i_msgty     = <lfs_s_protocol>-msgty
          i_msgno     = <lfs_s_protocol>-msgno
          i_msgv1     = <lfs_s_protocol>-msgv1
          i_msgv2     = <lfs_s_protocol>-msgv2
          i_msgv3     = <lfs_s_protocol>-msgv3
          i_msgv4     = <lfs_s_protocol>-msgv4
          i_row_id    = <lfs_s_protocol>-row_id
          i_fieldname = <lfs_s_protocol>-fieldname
        ).

      ENDLOOP.

    ENDIF.

    " Réactualise toolbar
    me->ms_work_area_private-display_element-o_alv_grid->set_toolbar_interactive( ).

  ENDMETHOD.

  METHOD _sequence_modification_check.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

    TYPES :
      BEGIN OF ts_link,
        original_row_id TYPE sy-tabix,
        new_row_id      TYPE sy-tabix,
        fieldname       TYPE string,
        mod_cells       TYPE REF TO lvc_s_modi,
        mod_rows        TYPE REF TO lcl_main=>ts_sequence_display_data,
      END OF   ts_link.

    TYPES : tt_link TYPE STANDARD TABLE OF ts_link
                    WITH NON-UNIQUE KEY primary_key COMPONENTS original_row_id fieldname.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_link           TYPE tt_link,
      lt_local_sequence TYPE lcl_main=>tt_sequence_display_data.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
    DATA :
          ls_protocol TYPE lvc_s_msg1.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_tabix  TYPE sy-tabix,
      lv_number TYPE i.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
      <lfs_value>      TYPE any,
      <lfs_t_mod_rows> TYPE lcl_main=>tt_sequence_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Initialisation locale de contrôle
    lt_local_sequence[] = me->ms_work_area_private-display_data-sequence-t_sequence[].

    IF ir_data_changed IS BOUND.

      IF ir_data_changed->mp_mod_rows IS BOUND.
        " Initialisation pointeur sur données
        ASSIGN ir_data_changed->mp_mod_rows->* TO <lfs_t_mod_rows>.

      ENDIF.

      ""  --> Aggrége les données
      LOOP AT ir_data_changed->mt_mod_cells ASSIGNING FIELD-SYMBOL(<lfs_s_mod_cells>).

        " Initialisation pointeur sur la ligne correspondante
        ASSIGN lt_local_sequence[ <lfs_s_mod_cells>-row_id ] TO FIELD-SYMBOL(<lfs_s_local_sequence>).
        IF sy-subrc EQ 0.
          " Initialisation pointeur sur le champ
          ASSIGN COMPONENT <lfs_s_mod_cells>-fieldname OF STRUCTURE <lfs_s_local_sequence>
                        TO <lfs_value>.

        ENDIF.
        IF sy-subrc EQ 0.
          " Modification de la valeur
          <lfs_value> = <lfs_s_mod_cells>-value.

          " Ligne modifiée
          <lfs_s_local_sequence>-has_changed = abap_true.

        ENDIF.

        IF <lfs_s_mod_cells>-fieldname EQ 'ZEDTRPORD' ##NO_TEXT.
          " Modification de l'OT
          ""  --> Ajout combinaison
          READ TABLE lt_link WITH TABLE KEY original_row_id = <lfs_s_mod_cells>-row_id
                                            fieldname       = <lfs_s_mod_cells>-fieldname
                            TRANSPORTING NO FIELDS.
          IF sy-subrc NE 0.
            APPEND VALUE #(
              original_row_id = <lfs_s_mod_cells>-row_id
              new_row_id      = <lfs_s_mod_cells>-row_id
              fieldname       = <lfs_s_mod_cells>-fieldname
              mod_cells       = REF #( <lfs_s_mod_cells> )
              mod_rows        = REF #( <lfs_t_mod_rows>[ <lfs_s_mod_cells>-tabix ] )
            ) TO lt_link.

          ENDIF.

        ENDIF.

      ENDLOOP.

      " Agrége données modifiées avec données existantes
      ""  --> Supprime les lignes (par ordre décroissant)
      DATA(lv_lines) = lines( ir_data_changed->mt_deleted_rows ).
      WHILE lv_lines GT 0.

        " Récupération dernière ligne
        READ TABLE ir_data_changed->mt_deleted_rows ASSIGNING FIELD-SYMBOL(<lfs_s_deleted_rows>)
             INDEX lv_lines.
        IF sy-subrc NE 0.
          " Pas de correspondance d'index
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        " Modification position dans table des liens
        LOOP AT lt_link ASSIGNING FIELD-SYMBOL(<lfs_s_link>).

          IF <lfs_s_link>-original_row_id EQ <lfs_s_deleted_rows>-row_id.
            " Il s'agit de la ligne supprimée
            ""  --> Suppression de l'entrée correspondante
            DELETE lt_link USING KEY loop_key.

          ELSEIF <lfs_s_link>-original_row_id GT <lfs_s_deleted_rows>-row_id.
            " La ligne supprimée est supérieure à la ligne supprimée
            ""  --> Décremente la ligne
            SUBTRACT 1 FROM <lfs_s_link>-new_row_id.

          ELSEIF <lfs_s_link>-original_row_id LT <lfs_s_deleted_rows>-row_id.
            " La ligne supprimée est inférieur à la ligne supprimée
            ""  --> Pas de changement

          ENDIF.

        ENDLOOP.

        " Suppression de la ligne
        DELETE lt_local_sequence INDEX <lfs_s_deleted_rows>-row_id.

        " Décrémentation de l'index
        SUBTRACT 1 FROM lv_lines.

      ENDWHILE.

      ""  --> Ajoute les lignes (par ordre décroissant)
      LOOP AT ir_data_changed->mt_inserted_rows ASSIGNING FIELD-SYMBOL(<lfs_s_inserted_rows>).

        " Récupération de l'index dans l'affichage
        READ TABLE ir_data_changed->mt_mod_cells WITH KEY row_id = <lfs_s_inserted_rows>-row_id
                                                ASSIGNING <lfs_s_mod_cells>.
        IF sy-subrc EQ 0.
          " Ajout de la ligne à l'emplacement correspondant
          INSERT INITIAL LINE INTO lt_local_sequence INDEX <lfs_s_mod_cells>-tabix
                         ASSIGNING <lfs_s_local_sequence>.

        ELSE.
          " Ajout à la position de l'ID
          INSERT INITIAL LINE INTO lt_local_sequence INDEX <lfs_s_inserted_rows>-row_id
                         ASSIGNING <lfs_s_local_sequence>.
          IF sy-subrc NE 0.
            " Erreur indéxation
            ""  --> Que faire ... ?

          ENDIF.

        ENDIF.

        " Ligne modifiée
        <lfs_s_local_sequence>-has_changed = abap_true.

      ENDLOOP.

    ENDIF.

    " -----------------------------------------------------------
    " Récupération des données pour contrôle
    " -----------------------------------------------------------

    " Récupération des libellés des OT
    SELECT e070~trkorr, e07t~as4text
             FROM e070
       LEFT OUTER JOIN e07t ON e07t~trkorr EQ e070~trkorr
    FOR ALL ENTRIES IN @lt_local_sequence
                 WHERE e070~trkorr EQ @lt_local_sequence-zedtrpord
                   AND e07t~langu  EQ @sy-langu
            INTO TABLE @DATA(lt_e07).

    " Tri pour performance
    SORT lt_e07 BY trkorr.

    " -----------------------------------------------------------
    " Contrôle les données
    " -----------------------------------------------------------

    LOOP AT lt_local_sequence ASSIGNING <lfs_s_local_sequence>.

      " Stockage position dans la table
      lv_tabix = sy-tabix.

      IF <lfs_s_local_sequence>-zedtrpord IS INITIAL
      OR <lfs_s_local_sequence>-has_changed EQ abap_false.
        " Pas d'OT || Pas de modification
        ""  --> Pas de contrôle
        CONTINUE.

      ENDIF.

      IF <lfs_s_local_sequence>-zedcritic EQ abap_false.
        " OT non critique
        ""  --> Vérifie la criticité
        <lfs_s_local_sequence>-zedcritic =
        <lfs_s_local_sequence>-zedcritic_auto =
          zcl_transport_request=>criticity_check( <lfs_s_local_sequence>-zedtrpord ).

      ENDIF.

      IF <lfs_s_local_sequence>-zedcritic      EQ abap_true
      OR <lfs_s_local_sequence>-zedcritic_auto EQ abap_true.
        " OT Critique
        IF me->ms_work_area_private-request-zedreqcritic EQ abap_false.
          " Demande non critique
          ""  --> Initialisation flag Criticité
          me->ms_work_area_private-display_data-request-request->zedreqcritic = abap_true.

          me->ms_work_area_private-display_data-request-has_pending_change = abap_true.

        ENDIF.

      ENDIF.

      " Recherche si modification présent sur cette ligne
      READ TABLE lt_link WITH KEY new_row_id = lv_tabix
                                  fieldname  = 'ZEDTRPORD' ##NO_TEXT
                        ASSIGNING <lfs_s_link>.

      " Vérification OT et récupération du libellé
      READ TABLE lt_e07 WITH KEY trkorr = <lfs_s_local_sequence>-zedtrpord
                       ASSIGNING FIELD-SYMBOL(<fs_s_e070>) BINARY SEARCH.
      IF sy-subrc NE 0.
        " OT inexistant
        ""  --> Initialisation message d'erreur
        ls_protocol-msgid     = 'CTS_ORGANIZER_MSG' ##NO_TEXT.
        ls_protocol-msgno     = 017.
        ls_protocol-msgty     = if_msg_output=>msgtype_error.
        ls_protocol-msgv1     = <lfs_s_local_sequence>-zedtrpord.
        ls_protocol-row_id    = lv_tabix.
        ls_protocol-fieldname = 'ZEDTRPORD'  ##NO_TEXT.

        IF <lfs_s_link> IS ASSIGNED.
          " OT modifié
          ""  --> Mise en erreur
          <lfs_s_link>-mod_cells->error = abap_true.

        ENDIF.

      ENDIF.

      " Recherche présence de doublon
      LOOP AT lt_local_sequence
        TRANSPORTING NO FIELDS WHERE zedtrpord EQ <lfs_s_local_sequence>-zedtrpord.
        ADD 1 TO lv_number.
      ENDLOOP.
      IF lv_number GT 1.
        " Plus d'une entrée
        ""  --> Initialisation message d'erreur
        ls_protocol-msgid     = 'ZTOOLS' ##NO_TEXT.
        ls_protocol-msgno     = 023.
        ls_protocol-msgty     = if_msg_output=>msgtype_error.
        ls_protocol-msgv1     = <lfs_s_local_sequence>-zedtrpord.
        ls_protocol-row_id    = lv_tabix.
        ls_protocol-fieldname = 'ZEDTRPORD'  ##NO_TEXT.

        IF <lfs_s_link> IS ASSIGNED.
          " OT modifié
          ""  --> Mise en erreur
          <lfs_s_link>-mod_cells->error = abap_true.

        ENDIF.

      ENDIF.

      IF ls_protocol IS INITIAL.
        " Pas d'erreur
        IF <lfs_s_link> IS ASSIGNED.
          " Modification des données
          <lfs_s_link>-mod_rows->zedwording  = <fs_s_e070>-as4text.
          <lfs_s_link>-mod_rows->has_changed = abap_true.

          ""  --> Changement libellé
          me->_request_mod_set_addit_data( CHANGING cs_display_data = <lfs_s_link>-mod_rows->* ).

          ""  --> Ajout pour modification Désignation
          APPEND VALUE #(
            row_id    = <lfs_s_link>-original_row_id
            fieldname = 'ZEDWORDING' ##NO_TEXT
            tabix     = <lfs_s_link>-mod_cells->tabix
            value     = <fs_s_e070>-as4text
          ) TO ir_data_changed->mt_mod_cells.

          ""  --> Ajout pour modification Désignation
          APPEND VALUE #(
            row_id    = <lfs_s_link>-original_row_id
            fieldname = 'ZEDWORDING' ##NO_TEXT
            tabix     = <lfs_s_link>-mod_cells->tabix
            value     = <fs_s_e070>-as4text
          ) TO ir_data_changed->mt_good_cells.

          ""  --> Ajout pour modification Date Transport
          APPEND VALUE #(
            row_id    = <lfs_s_link>-original_row_id
            fieldname = 'TRANSPORTED_QA_ON' ##NO_TEXT
            tabix     = <lfs_s_link>-mod_cells->tabix
            value     = <lfs_s_link>-mod_rows->*-transported_qa_on
          ) TO ir_data_changed->mt_mod_cells.

          ""  --> Ajout pour modification Date Transport
          APPEND VALUE #(
            row_id    = <lfs_s_link>-original_row_id
            fieldname = 'TRANSPORTED_QA_ON' ##NO_TEXT
            tabix     = <lfs_s_link>-mod_cells->tabix
            value     = <lfs_s_link>-mod_rows->*-transported_qa_on
          ) TO ir_data_changed->mt_good_cells.

          ""  --> Ajout pour modification Date libération
          APPEND VALUE #(
            row_id    = <lfs_s_link>-original_row_id
            fieldname = 'RELEASED_ON' ##NO_TEXT
            tabix     = <lfs_s_link>-mod_cells->tabix
            value     = <lfs_s_link>-mod_rows->*-released_on
          ) TO ir_data_changed->mt_mod_cells.

          ""  --> Ajout pour modification Date libération
          APPEND VALUE #(
            row_id    = <lfs_s_link>-original_row_id
            fieldname = 'RELEASED_ON' ##NO_TEXT
            tabix     = <lfs_s_link>-mod_cells->tabix
            value     = <lfs_s_link>-mod_rows->*-released_on
          ) TO ir_data_changed->mt_good_cells.

        ENDIF.

      ELSE.
        " Présence d'erreur
        ""  --> Ajout dans le protocole
        APPEND ls_protocol TO rt_protocol.
        CLEAR : ls_protocol.

      ENDIF.

      CLEAR : lv_number.

    ENDLOOP.

  ENDMETHOD.

  METHOD _sequence_transport_check.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle validité de la séquence
    " -----------------------------------------------------------

    " Contrôle la séquence
    rv_subrc = me->request_check(
        iv_target_system      = me->ms_work_area_private-display_data-request-request->zedtargsys
        iv_only_target_system = abap_true
        ir_trkorr             = VALUE #( FOR <lfs_s_sequence>
                                         IN me->ms_work_area_private-display_data-sequence-t_sequence
                                       WHERE ( NOT zedtrpord IS INITIAL ) (
                                              sign = if_trba_selection_c=>gc_sign_incl
                                            option = if_trba_selection_c=>gc_option_eq
                                               low = <lfs_s_sequence>-zedtrpord
                                           )
                              )
    ).

  ENDMETHOD.

  METHOD _sequence_history_save.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Historise la Version de la séquence
    " -----------------------------------------------------------

    " Historise la Version
    me->ms_work_area_private-display_data-sequence-history-o_history->history_version_create( ).

    IF me->ms_work_area_private-display_data-sequence-history-o_history->ms_history_public-version_current-version_current
      EQ lcl_main=>mc_sequence-history-version_max.
      ""  --> Désactive la fonction "Répéter"
      me->ms_work_area_private-display_data-sequence-history-redo_enabled = abap_false.

    ENDIF.

    " Changement de la Version courrante
    me->ms_work_area_private-display_data-sequence-history-version_current =
      me->ms_work_area_private-display_data-sequence-history-o_history->ms_history_public-version_current-version_current.

  ENDMETHOD.

  METHOD _request_modification_check.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
        lt_sequence_initial TYPE lcl_main=>tt_sequence_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle les données de la Demande
    " -----------------------------------------------------------

    IF me->ms_work_area_private-display_data-request-has_pending_change EQ abap_false.
      " Pas de modification
      "" --> Vérifie flag données modifiées ?
      me->ms_work_area_private-display_data-request-has_pending_change = xsdbool(
        me->ms_work_area_private-display_data-request-request->* NE me->ms_work_area_private-request
      ).

    ENDIF.

    IF me->ms_work_area_private-display_data-sequence-has_pending_change EQ abap_false.
      " Pas de modification
      ""  --> Récupération de la version d'origine
      me->ms_work_area_private-display_data-sequence-history-o_history->history_version_get(
        EXPORTING
          iv_version = zcl_itab_history=>mc_history-version_origin_v0
        IMPORTING
          et_data    = lt_sequence_initial
      ).

      ""  --> Vérifie s'il y a des modifications ?
      me->ms_work_area_private-display_data-sequence-has_pending_change = xsdbool(
        me->ms_work_area_private-display_data-sequence-t_sequence[] NE lt_sequence_initial[]
      ).

    ENDIF.

    IF me->ms_work_area_private-display_data-request-request->zedtrpdate     LT sy-datum
    OR (   me->ms_work_area_private-display_data-request-request->zedtrpdate EQ sy-datum
       AND me->ms_work_area_private-display_data-request-request->zedtrptime LT sy-uzeit ).
      " Date vide ou antérieur à la date du jour
      ""  --> Erreur
      rv_subrc = 1.
      me->ms_work_area_private-display_data-has_error-transport_date = abap_true.
      MESSAGE s025(rq) DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ELSE.
      " Date ok
      me->ms_work_area_private-display_data-has_error-transport_date = abap_false.

    ENDIF.

  ENDMETHOD.

  METHOD alv_handler_changed_finished.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_work_area_private-display_data-sequence-history-undo_redo_function EQ abap_true.
      " En cours de changement de Version
      ""  --> Réinitialise flag
      me->ms_work_area_private-display_data-sequence-history-undo_redo_function = abap_false.

    ELSE.
      " Pas en cours de changement de Version
      IF e_modified EQ abap_true.
        " Au moins une modification
        ""  --> Désactive la possibilité de "Répéter" les modifications
        me->ms_work_area_private-display_data-sequence-history-redo_enabled = abap_false.

        IF me->ms_work_area_private-display_data-sequence-newly_change EQ abap_false.
          ""  --> Supprime les Versions historisés supérieur à la Version courante
          me->ms_work_area_private-display_data-sequence-history-o_history->history_version_delete(
            ir_version = VALUE #( (
              sign   = if_trba_selection_c=>gc_sign_incl
              option = if_trba_selection_c=>gc_option_gt
              low    = me->ms_work_area_private-display_data-sequence-history-version_current
            ) )
          ).

          ""  --> Change l'indicateur de changement pour forcer création nouvelle version (si pas d'erreur)
          me->ms_work_area_private-display_data-sequence-newly_change = abap_true.

        ENDIF.

      ENDIF.

    ENDIF.

    IF me->ms_work_area_private-display_data-sequence-has_pending_change EQ abap_false.
      " Pas encore de modification déterminée
      ""  --> Initialise flag modification ?
      me->ms_work_area_private-display_data-sequence-has_pending_change = e_modified.

    ENDIF.

    IF  me->ms_work_area_private-display_data-sequence-has_error    EQ abap_false
    AND me->ms_work_area_private-display_data-sequence-newly_change EQ abap_true.
      " Pas d'erreur & Changement effectif
      ""  --> Sauvegarde la Version actuelle
      me->_sequence_history_save( ).

      ""  --> Réinitialise flag
      me->ms_work_area_private-display_data-sequence-newly_change = abap_false.

    ENDIF.

    " Réactualise affichage Toolbar
    me->ms_work_area_private-display_element-o_alv_grid->set_toolbar_interactive( ).

    IF e_modified EQ abap_false.
      " Aucune modification
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDMETHOD.

  METHOD _request_mod_set_addit_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Initialisation des données additionnels
    " -----------------------------------------------------------

    " Récupération historique
    DATA(lt_cofile_lines) = zcl_transport_request=>transport_request_cofile_get(
        iv_trkorr = cs_display_data-zedtrpord
    ).

    " Conserve dernière entrée
    SORT lt_cofile_lines BY tarsystem function trdate DESCENDING trtime DESCENDING.
    DELETE ADJACENT DUPLICATES FROM lt_cofile_lines COMPARING tarsystem function.

    " Récupération date d'Import Recette
    READ TABLE lt_cofile_lines WITH KEY tarsystem = 'RE1' ##NO_TEXT
                                        function  = cl_cts_change_tracking_api=>co_import_status_imported
                              ASSIGNING FIELD-SYMBOL(<lfs_s_cofile_line>)
                                 BINARY SEARCH.
    IF sy-subrc EQ 0.
      " OT transporté en Recette
      ""  --> Récupération date d'Import
      CONVERT DATE <lfs_s_cofile_line>-trdate TIME <lfs_s_cofile_line>-trtime
        INTO TIME STAMP cs_display_data-transported_qa_on TIME ZONE sy-zonlo.

    ENDIF.

    " Récupération date Libération
    READ TABLE lt_cofile_lines WITH KEY tarsystem = 'DE1' ##NO_TEXT
                                        function  = 'E'   ##NO_TEXT
                              ASSIGNING <lfs_s_cofile_line>
                                 BINARY SEARCH.
    IF sy-subrc EQ 0.
      " OT libérée
      ""  --> Récupération date de Libération
      CONVERT DATE <lfs_s_cofile_line>-trdate TIME <lfs_s_cofile_line>-trtime
        INTO TIME STAMP cs_display_data-released_on TIME ZONE sy-zonlo.

    ENDIF.

  ENDMETHOD.

  METHOD _sequence_move_order.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
    DATA :
      lt_cell       TYPE lvc_t_cell,
      lt_index_rows TYPE lvc_t_row.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
    DATA :
      lv_at_least_one_movement TYPE xsdboolean.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Récupération des lignes sélectionées
    " -----------------------------------------------------------

    " Récupération des lignes sélectionées
    me->ms_work_area_private-display_element-o_alv_grid->get_selected_rows(
      IMPORTING
        et_index_rows = lt_index_rows
    ).
    IF lt_index_rows[] IS INITIAL.
      " Aucune ligne séléctionnées
      ""  --> Récupération ligne des cellules sélectionnées
      me->ms_work_area_private-display_element-o_alv_grid->get_selected_cells(
        IMPORTING
          et_cell = lt_cell
      ).

      ""  --> Move-corresponding pour initialiser les numéros de ligne
      lt_index_rows = CORRESPONDING #( lt_cell MAPPING index = row_id ).

    ENDIF.
    IF lt_index_rows[] IS INITIAL.
      " Rien à faire
      ""  --> Arrêt du traitement
      MESSAGE s002(ztools) WITH text-e10 DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

    " Raccourci d'écriture
    DATA(lo_sequence) = REF #( me->ms_work_area_private-display_data-sequence-t_sequence ).

    " -----------------------------------------------------------
    " Réorganise la séquence
    " -----------------------------------------------------------

    DATA(lt_moving_index) = zcl_itab_utilities=>reorder_lines(
      EXPORTING
        iv_move_direction        = SWITCH #( iv_move_up
          WHEN abap_true THEN zcl_itab_utilities=>mc_move_direction-move_up
          ELSE zcl_itab_utilities=>mc_move_direction-move_down
        )
        it_row_to_move           = VALUE #( FOR <lfs_s_index_rows> IN lt_index_rows ( <lfs_s_index_rows>-index ) )
      IMPORTING
        ev_at_least_one_movement = lv_at_least_one_movement
      CHANGING
        ct_itab                  = lo_sequence->*
    ).

    IF lv_at_least_one_movement EQ abap_true.
      " Au moins une ligne déplacée
      ""  --> Initialise indicateur de données modifiées
      me->ms_work_area_private-display_data-sequence-has_pending_change = lv_at_least_one_movement.

      ""  --> Historise la Version
      me->_sequence_history_save( ).

    ENDIF.

    " -----------------------------------------------------------
    " Réactualise l'affichage
    " -----------------------------------------------------------

    " Réactualise l'affichage
    me->ms_work_area_private-display_element-o_alv_grid->refresh_table_display(
      EXCEPTIONS
        OTHERS = 0
    ).

    " Conserve la sélection sur les lignes
    lt_index_rows = VALUE #( FOR <lfs_moving_index> IN lt_moving_index ( index = <lfs_moving_index>-index_new ) ).
    me->ms_work_area_private-display_element-o_alv_grid->set_selected_rows(
        it_index_rows = lt_index_rows
    ).

  ENDMETHOD.

  METHOD module_input_dispath.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Traitement après saisie
    " -----------------------------------------------------------

    " Suivant le champ modifié
    CASE iv_input.

      WHEN lcl_main=>mc_module_input-request_modification_check.
        " Contrôle Modification Demande
        ""  --> Contrôle
        me->_request_modification_check( ).

      WHEN OTHERS.
        " Autre
        ""  --> Arrêt du traitement
        RETURN.

    ENDCASE.

  ENDMETHOD.

  METHOD _sequence_undo.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
    FIELD-SYMBOLS :
          <lfs_t_version> TYPE lcl_main=>tt_sequence_display_data.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_work_area_private-display_data-sequence-has_pending_change EQ abap_false
    OR me->ms_work_area_private-display_data-sequence-history-version_current LT 1.
      " Aucun changement || Pas d'historique de version
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Réstitue la version précédente
    " -----------------------------------------------------------

    " Initialisation flag changement de Version
    me->ms_work_area_private-display_data-sequence-history-undo_redo_function = abap_true.

    " Décrémente la version courrante
    SUBTRACT 1 FROM me->ms_work_area_private-display_data-sequence-history-version_current.
    IF me->ms_work_area_private-display_data-sequence-history-version_current LE 1.
      " Hors limite
      ""  --> Récupération Version d'Origine
      DATA(lot_version) = me->ms_work_area_private-display_data-sequence-history-o_history->history_version_get(
          iv_version = zcl_itab_history=>mc_history-version_origin_v0
      ).
      IF lot_version IS BOUND.
        ASSIGN lot_version->* TO <lfs_t_version>.

      ENDIF.

      ""  --> Ramène à la première version
      me->ms_work_area_private-display_data-sequence-history-version_current = 1.

    ENDIF.

    " Récupération des données de la version précédente
    lot_version = me->ms_work_area_private-display_data-sequence-history-o_history->history_version_get(
      EXPORTING
        iv_version = me->ms_work_area_private-display_data-sequence-history-version_current
      IMPORTING
        et_data    = me->ms_work_area_private-display_data-sequence-t_sequence[]
    ).

    IF me->ms_work_area_private-display_data-sequence-history-version_current EQ 1 AND <lfs_t_version> IS ASSIGNED.
      ""  --> Réinitialise flag changement ?
      me->ms_work_area_private-display_data-sequence-has_pending_change = xsdbool(
        <lfs_t_version> NE me->ms_work_area_private-display_data-sequence-t_sequence
      ).

      ""  --> Libération mémoire
      FREE : lot_version.

    ENDIF.

    " Active la fonction "Répéter"
    me->ms_work_area_private-display_data-sequence-history-redo_enabled = abap_true.

    " Modifie les données affichées
    me->ms_work_area_private-display_element-o_alv_grid->refresh_table_display(
      EXCEPTIONS
        OTHERS = 0
    ).

    " Déclenche la vérification des données pour cohérence
    me->ms_work_area_private-display_element-o_alv_grid->check_changed_data( ).

  ENDMETHOD.

  METHOD _sequence_redo.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
    DATA :
          lo_history TYPE REF TO zcl_itab_history.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

    " -----------------------------------------------------------
    " Pré-Traitement
    " -----------------------------------------------------------

    " Raccourci
    lo_history = me->ms_work_area_private-display_data-sequence-history-o_history.

    " -----------------------------------------------------------
    " Contrôle
    " -----------------------------------------------------------

    IF me->ms_work_area_private-display_data-sequence-history-redo_enabled    EQ abap_false
    OR me->ms_work_area_private-display_data-sequence-history-version_current GE lcl_main=>mc_sequence-history-version_max.
      " Aucun changement || Pas de version suivante
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " -----------------------------------------------------------
    " Réstitue la version suivante
    " -----------------------------------------------------------

    " Initialisation flag changement de Version
    me->ms_work_area_private-display_data-sequence-history-undo_redo_function = abap_true.

    " Initialisation flag modification
    me->ms_work_area_private-display_data-sequence-has_pending_change = abap_true.

    " Incrémente la version courrante
    ADD 1 TO me->ms_work_area_private-display_data-sequence-history-version_current.
    IF me->ms_work_area_private-display_data-sequence-history-version_current
        GT lcl_main=>mc_sequence-history-version_max.
      " Dépasse la limite de Version
      ""  --> Ramène à la Verison max
      me->ms_work_area_private-display_data-sequence-history-version_current =
        lcl_main=>mc_sequence-history-version_max.

    ENDIF.

    IF me->ms_work_area_private-display_data-sequence-history-version_current EQ lcl_main=>mc_sequence-history-version_max
    OR me->ms_work_area_private-display_data-sequence-history-version_current
        GE lines( lo_history->ms_history_public-t_history ) - 1.
      " Nombre max. de Version || N° Version > Nb de version historisée
      ""  --> Désactive la possibilité de "Répéter"
      me->ms_work_area_private-display_data-sequence-history-redo_enabled = abap_false.

    ENDIF.

    " Récupération des données de la version
    lo_history->history_version_get(
      EXPORTING
        iv_version = me->ms_work_area_private-display_data-sequence-history-version_current
      IMPORTING
        et_data    = me->ms_work_area_private-display_data-sequence-t_sequence
    ).

    " Modifie les données affichées
    me->ms_work_area_private-display_element-o_alv_grid->refresh_table_display(
      EXCEPTIONS
        OTHERS = 0
    ).

    " Déclenche la vérification des données pour cohérence
    me->ms_work_area_private-display_element-o_alv_grid->check_changed_data( ).

  ENDMETHOD.

ENDCLASS.
