*&---------------------------------------------------------------------*
*&  Include           Z_BC_TRANSPORT_REQUEST_C01
*&---------------------------------------------------------------------*


*----------------------------------------------------------------------*
*       CLASS LCL_main DEFINIION
*----------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
CLASS lcl_main DEFINITION FINAL CREATE PRIVATE.

*-- Publique
  PUBLIC SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Initialisation
    CLASS-METHODS initialization.

    " Aide à la recherche - Système cible
    CLASS-METHODS sysid_value_help
      RETURNING VALUE(rv_sysid) TYPE ztbdestrfc-zedtargsys.

    " Aide à la recherche - Batch
    CLASS-METHODS batch_value_help
      RETURNING VALUE(rv_batch) TYPE ztbrequest_batch-zedbatch.

    " Aide à la recherche - OT
    CLASS-METHODS trkorr_value_help
      RETURNING VALUE(rv_trkorr) TYPE e070-trkorr.

    " PopUp Confirmation Perte de données
    CLASS-METHODS call_popup_confirm_data_loss
      RETURNING VALUE(rv_confirmed) TYPE xsdboolean.

    " PopUp Confirmation
    CLASS-METHODS call_popup_confirmation
      IMPORTING
                !iv_titlebar        TYPE clike
                !iv_text_question   TYPE clike
      RETURNING VALUE(rv_confirmed) TYPE xsdboolean.

    " Evènement - Ecran de sélection
    METHODS at_selection_screen
      IMPORTING
        !iv_ucomm TYPE sy-ucomm.

    " Evènement - Affichage Ecran de sélection
    METHODS at_selection_screen_output.

    " Evènement - Fin saisie OT
    METHODS at_selection_screen_end_ot.

    " Evènement - Arrêt
    METHODS at_selection_screen_on_exit.

    " Traitement
    METHODS process
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " PBO
    METHODS pbo_dispatch
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " PAI
    METHODS pai_dispatch
      IMPORTING
                !iv_ucomm       TYPE sy-ucomm
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Module Saisie
    METHODS module_input_dispath
      IMPORTING
        !iv_input TYPE clike.

    " Handler - Aide à la Recherche
    METHODS alv_handler_onf4
                  FOR EVENT onf4 OF cl_gui_alv_grid
      IMPORTING !e_fieldname !e_fieldvalue !es_row_no !er_event_data !et_bad_cells !e_display.

    " Handler - Action utilisateur
    METHODS alv_handler_user_command
                  FOR EVENT user_command OF cl_gui_alv_grid
      IMPORTING !e_ucomm.

    " Handler - Modification saisie
    METHODS alv_handler_data_changed
                  FOR EVENT data_changed OF cl_gui_alv_grid
      IMPORTING !er_data_changed !e_onf4 !e_onf4_before !e_onf4_after !e_ucomm.

    " Handler
    METHODS alv_handler_changed_finished
                  FOR EVENT data_changed_finished OF cl_gui_alv_grid
      IMPORTING !e_modified !et_good_cells.

    " Handler Clique Toolbar ALV
    METHODS alv_handler_toolbar
      FOR EVENT toolbar
                  OF cl_gui_alv_grid
      IMPORTING !e_object !e_interactive.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    CONSTANTS :
      BEGIN OF mc_dynnr,
        creation     TYPE sy-dynnr VALUE 2000,
        modification TYPE sy-dynnr VALUE 3000,
        execution    TYPE sy-dynnr VALUE 4000,
      END OF  mc_dynnr.

    CONSTANTS :
      BEGIN OF mc_module_input,
        request_modification_check TYPE numc1 VALUE 1 ##NO_TEXT,
      END OF mc_module_input.

*-- Privée
  PRIVATE SECTION.

***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

*   Déclaration de type

    TYPES :
      BEGIN OF ts_request_to_create,
        type     TYPE ztbrequest-zedtrpcode,
        t_trkorr TYPE trkorrs,
      END OF   ts_request_to_create.

    TYPES : tt_request_to_create TYPE STANDARD TABLE OF ts_request_to_create
                    WITH NON-UNIQUE KEY primary_key COMPONENTS type.


    TYPES :
      BEGIN OF ts_selection_criteria_crea,

        BEGIN OF object,
          or_trkorr         LIKE REF TO s_trkorr[],
          ov_system_target  LIKE REF TO p_sysid,
          ov_transport_code LIKE REF TO p_type,
        END OF object,

        BEGIN OF time,
          ov_transport_date LIKE REF TO p_datum,
          ov_transport_hour LIKE REF TO p_uzeit,
        END OF time,

        BEGIN OF batch,
          ov_batch LIKE REF TO p_batch,
        END OF batch,

        BEGIN OF criticity,
          ov_critic LIKE REF TO p_critic,
        END OF criticity,

        BEGIN OF option,
          ov_check                LIKE REF TO p_check,
          ov_only_target_system   LIKE REF TO p_only,
          ov_transport_express    LIKE REF TO p_expr,
          ov_launch_transport_job LIKE REF TO p_ljob,
        END OF option,

        BEGIN OF certification,
          ov_valid LIKE REF TO p_acc,
        END OF certification,

      END OF   ts_selection_criteria_crea.

    TYPES :
      BEGIN OF ts_selection_criteria_modi,

        BEGIN OF transport_selection,
          ov_request   LIKE REF TO p_req,
          ov_read_only LIKE REF TO p_ronly,
        END OF transport_selection,

      END OF   ts_selection_criteria_modi.

    TYPES :
      BEGIN OF ts_selection_criteria_exec,

        BEGIN OF time,
          ov_datum LIKE REF TO p_edate,
          ov_uzeit LIKE REF TO p_ehour,
        END OF time,

      END OF   ts_selection_criteria_exec.

    TYPES :
      BEGIN OF ts_selection_criteria,
        creation     TYPE lcl_main=>ts_selection_criteria_crea,
        modification TYPE lcl_main=>ts_selection_criteria_modi,
        execution    TYPE lcl_main=>ts_selection_criteria_exec,
      END OF   ts_selection_criteria.

    TYPES :
      BEGIN OF ts_display_element,
        s_layout            TYPE        lvc_s_layo,
        t_fieldcatalog      TYPE        lvc_t_fcat,
        t_toolbar_excluding TYPE ui_functions,
        o_toolbar           TYPE REF TO cl_gui_toolbar,
        o_alv_grid          TYPE REF TO cl_gui_alv_grid,
        o_ccontainer        TYPE REF TO cl_gui_custom_container,
      END OF   ts_display_element.

    TYPES :
        BEGIN OF ts_sequence_display_data.
            INCLUDE TYPE ztborderseq.
    TYPES :
      created_on        TYPE timestamp,
      released_on       TYPE timestamp,
      transported_qa_on TYPE timestamp,
      has_changed       TYPE xsdboolean,
      END OF   ts_sequence_display_data.

    TYPES : tt_sequence_display_data TYPE STANDARD TABLE OF ts_sequence_display_data
                    WITH NON-UNIQUE KEY primary_key COMPONENTS zedreqnb zedreqpos.

    TYPES :
      BEGIN OF ts_sequence_history,
        version    TYPE int1,
        t_sequence TYPE lcl_main=>tt_sequence_display_data,
      END OF   ts_sequence_history.

    TYPES : tt_sequence_history TYPE SORTED TABLE OF ts_sequence_history
                    WITH NON-UNIQUE KEY primary_key COMPONENTS version.

    TYPES :
      BEGIN OF ts_work_area_private,

        BEGIN OF criticity,
          critic_man  TYPE xsdboolean,
          critic_auto TYPE xsdboolean,
        END OF criticity,

        BEGIN OF batch,
          batch_create TYPE xsdboolean,
          batch_data   TYPE zst_request_transport_batch,
        END OF batch,

        request         TYPE ztbrequest,

        display_element TYPE lcl_main=>ts_display_element,

        BEGIN OF display_data,
          BEGIN OF sequence,
            " Séquence
            t_sequence         TYPE lcl_main=>tt_sequence_display_data,
            has_pending_change TYPE xsdboolean,
            newly_change       TYPE xsdboolean,
            has_error          TYPE xsdboolean,

            BEGIN OF history,
              o_history          TYPE REF TO zcl_itab_history,
              redo_enabled       TYPE xsdboolean,
              version_current    TYPE zcl_itab_history=>ts_history_version-version,
              undo_redo_function TYPE xsdboolean,
            END OF history,

          END OF sequence,

          BEGIN OF request,
            " Requête
            request            TYPE REF TO ztbrequest,
            has_pending_change TYPE xsdboolean,
          END OF request,

          BEGIN OF has_error,
            transport_date TYPE xsdboolean,
          END OF has_error,

        END OF display_data,
      END OF   ts_work_area_private.

    TYPES :
      BEGIN OF ts_global_area_private,
        ov_screen TYPE REF TO sy-dynnr,
      END OF   ts_global_area_private.

***------------------------------------------------------------------***
**                           MÉTHODES                                 **
***------------------------------------------------------------------***

*	Déclaration de méthodes

    " Génération instance
    CLASS-METHODS factory
      RETURNING VALUE(ro_instance) TYPE REF TO lcl_main.

    " Constructeur
    METHODS constructor.

    " Contrôle Criticité
    METHODS criticity_check
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Contrôle cohérence de la Demande
    METHODS request_check
      IMPORTING
                !iv_target_system      TYPE ztbdestrfc-zedtargsys
                !iv_only_target_system TYPE xsdboolean
                !ir_trkorr             LIKE s_trkorr[]
      RETURNING VALUE(rv_subrc)        TYPE sy-subrc.

    " Traitement - Création
    METHODS process_request_creation
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Traitement - Modification
    METHODS process_request_modification
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Demande - Modification - Affichage
    METHODS request_modification_display
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Traitement
    METHODS process_transport_execute
      IMPORTING
                !iv_execution_date TYPE sy-datum OPTIONAL
                !iv_execution_time TYPE sy-uzeit OPTIONAL
      RETURNING VALUE(rv_subrc)    TYPE sy-subrc.


    " Evènement - Affichage écran de sélection - Création
    METHODS _at_selection_screen_out_crea.

    " Evènement - Affichage écran de sélection - Exécution
    METHODS _at_selection_screen_out_exec.

    " Evènement - Affichage écran de sélection - Modification
    METHODS _at_selection_screen_out_modif.

    " Demande - Modification - PBO
    METHODS _pbo_3100.

    " Demande - Modification - PAI
    METHODS _pai_3100
      IMPORTING !iv_ucomm TYPE sy-ucomm.

    " Modification ordre de la séquence
    METHODS _sequence_move_order
      IMPORTING !iv_move_up TYPE xsdboolean.

    " Demande - Modification - Sauvegarde
    METHODS _request_modification_save
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Demande - Modification - Contrôle
    METHODS _request_modification_check
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Demande - Suppression
    METHODS _request_modification_delete
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Séquence - Modification - Contrôle
    METHODS _sequence_modification_check
      IMPORTING
                !ir_data_changed   TYPE REF TO cl_alv_changed_data_protocol OPTIONAL
      RETURNING VALUE(rt_protocol) TYPE lvc_t_msg1.

    " Séquence - Historise la Version
    METHODS _sequence_history_save
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Séquence - Annuler
    METHODS _sequence_undo
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Séquence - Répéter
    METHODS _sequence_redo
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Séquence - Contrôle Transport
    METHODS _sequence_transport_check
      RETURNING VALUE(rv_subrc) TYPE sy-subrc.

    " Lors de la sortie de l'écran de modification
    METHODS _request_modification_leave
      IMPORTING !iv_leave_transaction TYPE xsdboolean OPTIONAL.

    " Modification données additional
    METHODS _request_mod_set_addit_data
      CHANGING !cs_display_data TYPE lcl_main=>ts_sequence_display_data.

***------------------------------------------------------------------***
**                            ATTRIBUTS                               **
***------------------------------------------------------------------***

*	Déclaration d'attributs

    CLASS-DATA : ms_global_area_private TYPE lcl_main=>ts_global_area_private.
    DATA : ms_work_area_private  TYPE lcl_main=>ts_work_area_private.
    DATA : ms_selection_criteria TYPE lcl_main=>ts_selection_criteria.

    CONSTANTS :
      BEGIN OF mc_event,
        back         TYPE sy-ucomm VALUE 'BACK',             ##NO_TEXT
        exit         TYPE sy-ucomm VALUE 'EXIT',             ##NO_TEXT
        save         TYPE sy-ucomm VALUE 'SAVE',             ##NO_TEXT
        dummy        TYPE sy-ucomm VALUE 'DUMMY',            ##NO_TEXT
        leave        TYPE sy-ucomm VALUE 'LEAVE',            ##NO_TEXT
        check        TYPE sy-ucomm VALUE 'CHECK',            ##NO_TEXT
        delete       TYPE sy-ucomm VALUE 'DELETE',           ##NO_TEXT
        refresh      TYPE sy-ucomm VALUE 'REFRESH',          ##NO_TEXT
        batch_create TYPE sy-ucomm VALUE 'CBATCH',           ##NO_TEXT
      END OF mc_event.

    CONSTANTS :
      BEGIN OF mc_function,
        none      TYPE ui_func VALUE 'NONE',         ##NO_TEXT
        undo      TYPE ui_func VALUE 'UNDO',         ##NO_TEXT
        redo      TYPE ui_func VALUE 'REDO',         ##NO_TEXT
        check     TYPE ui_func VALUE 'CHECK',        ##NO_TEXT
        move_up   TYPE ui_func VALUE 'MOVE_UP',      ##NO_TEXT
        move_down TYPE ui_func VALUE 'MOVE_DOWN',    ##NO_TEXT
      END OF mc_function.

    CONSTANTS :
      BEGIN OF mc_sequence,
        BEGIN OF history,
          version_max TYPE int4 VALUE 10,
        END OF history,

      END OF mc_sequence.

    CONSTANTS :
      BEGIN OF mc_memory_id,
        tab_navigation TYPE c LENGTH 20 VALUE 'ZMEM_ID_TAB_NAV', ##NO_TEXT
      END OF  mc_memory_id.

ENDCLASS.             "lcl_main DEFINITION
