*&---------------------------------------------------------------------*
*& Report  Z_BC_TRANSPORT_REQUEST_CREATE
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT z_bc_transport_request_create.


TABLES : e070.
DATA : gv_batch_create TYPE xsdboolean.
DATA : gv_critic_auto TYPE xsdboolean.
DATA : gv_critic_man TYPE xsdboolean.
DATA: gs_batch TYPE zst_request_transport_batch.

CONSTANTS :
  BEGIN OF mc_dynnr,
    creation     TYPE sy-dynnr VALUE 1000,
    modification TYPE sy-dynnr VALUE 3000,
  END OF  mc_dynnr.

TYPES :
  BEGIN OF ts_request_to_create,
    type     TYPE ztbrequest-zedtrpcode,
    t_trkorr TYPE trkorrs,
  END OF   ts_request_to_create.

TYPES : tt_request_to_create TYPE STANDARD TABLE OF ts_request_to_create
                WITH NON-UNIQUE KEY primary_key COMPONENTS type.

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

SELECTION-SCREEN BEGIN OF SCREEN 2000 AS SUBSCREEN.
" -----------------------------------------------------------
" Création
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Paramètres
" -----------------------------------------------------------

" Liste OT
SELECT-OPTIONS : s_trkorr FOR e070-trkorr NO INTERVALS.

" Système Cible
PARAMETERS : p_sysid TYPE ztbdestrfc-zedtargsys.

" Type de Transport
PARAMETERS : p_type TYPE ztbrequest-zedtrpcode.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE text-tb3.

" Date de Transport souhaité
PARAMETERS : p_datum TYPE sy-datum DEFAULT sy-datum OBLIGATORY MODIF ID bat.

" Heure de Transport souhaité
PARAMETERS : p_uzeit TYPE sy-uzeit DEFAULT sy-uzeit OBLIGATORY MODIF ID bat.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF BLOCK b4 WITH FRAME TITLE text-tb4.

SELECTION-SCREEN:
  BEGIN OF LINE,
  COMMENT 1(12) text-bat FOR FIELD p_batch.
PARAMETERS p_batch TYPE ztbrequest_batch-zedbatch MODIF ID prd MATCHCODE OBJECT zh_request_batch_open.
SELECTION-SCREEN :
    COMMENT 25(11) text-tcb,
    PUSHBUTTON 37(4) text-cba USER-COMMAND cbatch MODIF ID prd, POSITION 46.
SELECTION-SCREEN :
END OF LINE.

SELECTION-SCREEN END OF BLOCK b4.

SELECTION-SCREEN BEGIN OF BLOCK b5 WITH FRAME TITLE text-tb5.

" Au moins un OT critique
PARAMETERS : p_critic AS CHECKBOX MODIF ID prd USER-COMMAND cri.

SELECTION-SCREEN END OF BLOCK b5.

SELECTION-SCREEN END OF BLOCK b3.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Options de Transport supplémentaires
" -----------------------------------------------------------

" Contrôler cohérence
PARAMETERS : p_check AS CHECKBOX DEFAULT 'X' USER-COMMAND chk MODIF ID man. ##NO_TEXT

" Uniquement ce Sytème
PARAMETERS : p_only AS CHECKBOX MODIF ID prd USER-COMMAND chk.

" Express
PARAMETERS : p_expr AS CHECKBOX MODIF ID prd USER-COMMAND chk.

" Déclencher Job Transport
PARAMETERS : p_ljob AS CHECKBOX MODIF ID rec USER-COMMAND chk.

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b6 WITH FRAME TITLE text-tb6.
" -----------------------------------------------------------
" Certification
" -----------------------------------------------------------

" Certifie
PARAMETERS : p_acc AS CHECKBOX USER-COMMAND acc.

SELECTION-SCREEN END OF BLOCK b6.

SELECTION-SCREEN END OF SCREEN 2000.

SELECTION-SCREEN BEGIN OF SCREEN 3000 AS SUBSCREEN.
" -----------------------------------------------------------
" Modification
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK tb7 WITH FRAME TITLE text-tb7.

" Requête
PARAMETERS : p_uname TYPE sy-uname DEFAULT sy-uname MODIF ID man.

SELECTION-SCREEN END OF BLOCK tb7.

SELECTION-SCREEN END OF SCREEN 3000.

" -----------------------------------------------------------
" Gestion Onglets
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF TABBED BLOCK tab FOR 30 LINES.

" Création
SELECTION-SCREEN TAB (30) text-sc1 USER-COMMAND ucomm1
  DEFAULT SCREEN 2000.

" Modification
*SELECTION-SCREEN TAB (30) text-sc2 USER-COMMAND ucomm2
*  DEFAULT SCREEN 3000.

SELECTION-SCREEN END OF BLOCK tab.

***==================================================================***
**                AT SELECTION-SCREEN  ON VALUE-REQUEST               **
***==================================================================***

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_sysid.
  " Système Cible - Aide à la recherche
  PERFORM sysid_value_help CHANGING p_sysid.

***==================================================================***
**                       AT SELECTION-SCREEN                          **
***==================================================================***

AT SELECTION-SCREEN.
  " Commande Utilisateur
  PERFORM at_selection_screen USING sy-ucomm.

***==================================================================***
**                   AT SELECTION-SCREEN ON END OF                    **
***==================================================================***
AT SELECTION-SCREEN ON END OF s_trkorr.
  " Fin saisi OT
  PERFORM at_selection_screen_end_ot.

***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***

AT SELECTION-SCREEN OUTPUT.
  " Modification Ecran
  PERFORM at_selection_screen_output.

***==================================================================***
**                         START-OF-SELECTION                         **
***==================================================================***
START-OF-SELECTION.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_request_to_create TYPE tt_request_to_create.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_type         TYPE ztbrequest-zedtrpcode,
    lv_subrc        TYPE sy-subrc,
    lv_critic       TYPE xsdboolean,
    lv_message      TYPE string,
    lv_tr_not_exist TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " En fonction de l'Onglet
  CASE sy-dynnr.

    WHEN mc_dynnr-creation.
      " Création
      PERFORM request_creation.

    WHEN mc_dynnr-modification.
      " Modification
      PERFORM request_modification.

    WHEN OTHERS.

  ENDCASE.

FORM request_creation.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle cohérence saisie
  " -----------------------------------------------------------

  IF p_sysid IS INITIAL.
    " Système cible obligatoire
    MESSAGE s002(ztools) WITH text-e03 DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ELSEIF s_trkorr[] IS INITIAL.
    " OT obligatoire
    MESSAGE s002(ztools) WITH text-e04 DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ELSEIF p_acc EQ abap_false.                               ##NO_TEXT
    " Validation obligatoire
    MESSAGE s020(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  IF zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' )->attribute_value_get(
      iv_parameter_name = 'BATCH_CONFIGURATION'             ##NO_TEXT
      iv_attribute_name = 'MANDATORY'                       ##NO_TEXT
  )-key1 EQ abap_true AND p_sysid EQ 'PE1'                  ##NO_TEXT
                      AND p_batch IS INITIAL.
    " Passage en Prod et Lot Obligatoire
    MESSAGE s018(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  " Contrôle cohérence saisie
  READ TABLE s_trkorr WITH KEY option = if_trba_selection_c=>gc_option_cp
                  TRANSPORTING NO FIELDS.
  IF sy-subrc EQ 0.
    " Recherche sur Pattern non autorisée
    MESSAGE s000(zcunity) WITH text-e01 DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  IF p_critic EQ abap_false.
    " Force le contrôle de Criticité (dans le doute que l'utilisateur n'ai rien Validé)
    LOOP AT s_trkorr ASSIGNING FIELD-SYMBOL(<lfs_sr_trkorr>).

      lv_critic = zcl_transport_request=>criticity_check( <lfs_sr_trkorr>-low ).

      IF lv_critic EQ abap_true.
        gv_critic_auto = p_critic = lv_critic.

      ENDIF.

    ENDLOOP.

  ENDIF.

  " -----------------------------------------------------------
  " Vérification Criticité en DB
  " -----------------------------------------------------------

  IF  NOT p_batch IS INITIAL
  AND p_critic EQ abap_true AND gv_critic_auto EQ abap_true.
    " Dans le Cas d'un Lot et de la présence d'un OT critique
    ""  --> Bascule le Lot en Critique
    UPDATE ztbrequest_batch SET zedcritic = @abap_true
                          WHERE zedbatch  EQ @p_batch.
    COMMIT WORK.

  ENDIF.

  " -----------------------------------------------------------
  " Vérification liés aux autres Demandes de Transport
  " -----------------------------------------------------------

  " Vérifie que les OTs ne sont pas déjà présent dans une autre Demande
  SELECT SINGLE seq~zedtrpord, seq~zedreqnb, request~zedreqbatch
    FROM ztborderseq AS seq
             INNER JOIN ztbrequest AS request
                     ON request~zedreqnb    EQ seq~zedreqnb
                  WHERE request~zedtargsys  EQ @p_sysid
                    AND seq~zedtrpord       IN @s_trkorr[]
                    AND request~zedtrtdate  EQ '00000000'   ##NO_TEXT
                   INTO @DATA(ls_already).
  IF sy-subrc EQ 0.
    " Au moins un OT présent dans une autre Demande
    IF ls_already-zedreqbatch IS INITIAL.
      " Pas de Lot
      MESSAGE s023(ztools) DISPLAY LIKE if_msg_output=>msgtype_error
         WITH ls_already-zedtrpord ls_already-zedreqnb.

    ELSE.
      " Lot
      MESSAGE s024(ztools) DISPLAY LIKE if_msg_output=>msgtype_error
         WITH ls_already-zedtrpord ls_already-zedreqnb ls_already-zedreqbatch.

    ENDIF.

    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Vérification OT vide
  " -----------------------------------------------------------

  " Récupération liste Objet des OTs
  SELECT e071~trkorr AS trkorr,
    CASE WHEN main~strkorr NE @space THEN main~strkorr ELSE main~trkorr END AS trkorr_main
    FROM e071 INNER JOIN e070 AS main ON e071~trkorr EQ main~trkorr
   WHERE (     main~trkorr  IN @s_trkorr[]
            OR main~strkorr IN @s_trkorr[] )
     AND (     pgmid  NE @if_dms_constants=>orig_type_corr
           AND object NE @if_cts_organizer_constants=>activity_release )
    INTO TABLE @DATA(lt_e071).
  IF sy-subrc NE 0.
    " Aucun Objet
    ""  --> Arrêt du traitement
    MESSAGE s029(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  SORT lt_e071 BY trkorr_main.
  LOOP AT s_trkorr ASSIGNING <lfs_sr_trkorr>.

    " OT contient des Objets ?
    READ TABLE lt_e071 WITH KEY trkorr_main = <lfs_sr_trkorr>-low
                   TRANSPORTING NO FIELDS BINARY SEARCH.
    IF sy-subrc NE 0.
      " OT non trouvé // OT Vide
      ""  --> Arrêt du traitement
      MESSAGE s030(ztools) WITH <lfs_sr_trkorr>-low DISPLAY LIKE if_msg_output=>msgtype_error.
      RETURN.

    ENDIF.

  ENDLOOP.

  " -----------------------------------------------------------
  " Préparation Liste des OTs
  " -----------------------------------------------------------

  " Récupération données des OTs
  SELECT trkorr, trfunction
    FROM e070 WHERE trkorr IN @s_trkorr[]
           ORDER BY trkorr
         INTO TABLE @DATA(lt_e070).
  IF sy-subrc NE 0.
    " OT inexistant
    MESSAGE s002(ztools) WITH text-e04 DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  " Récupération des OTs
  LOOP AT s_trkorr ASSIGNING <lfs_sr_trkorr>.

    " L'OT existe ?
    READ TABLE lt_e070 WITH KEY trkorr = <lfs_sr_trkorr>-low
                      ASSIGNING FIELD-SYMBOL(<lfs_s_e070>)
                         BINARY SEARCH.
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Passe à l'itération suivante
      lv_tr_not_exist = abap_true.
      MESSAGE ID 'TR' TYPE if_msg_output=>msgtype_error ##NO_TEXT
                    NUMBER 807 WITH <lfs_sr_trkorr>-low
                               INTO lv_message.
      WRITE : lv_message, /.
      CONTINUE.

    ENDIF.

    IF p_type EQ zcl_transport_request_celio=>mc_request_type-authorization.
      " Demande transport Authorisation
      lv_type = p_type.

    ELSE.
      " En foncion de la Typologie de l'OT
      IF  <lfs_s_e070>-trfunction EQ if_cts_organizer_constants=>tr_type_customizing_request
      AND zcl_transport_request=>transport_is_auth( <lfs_sr_trkorr>-low ) EQ abap_true.
        " OT Auth
        ""  --> Ajout de l'OT dans table Auth
        lv_type = zcl_transport_request_celio=>mc_request_type-authorization.

      ELSE.
        " Développement // Custo
        ""  --> Ajout de l'OT dans table classique
        lv_type = zcl_transport_request_celio=>mc_request_type-classic.

      ENDIF.

    ENDIF.

    " Ajout de l'OT dans catégorie respective
    READ TABLE lt_request_to_create WITH KEY type = lv_type
                                   ASSIGNING FIELD-SYMBOL(<lfs_s_request_to_create>)
                                      BINARY SEARCH.
    IF sy-subrc NE 0.
      " Aucune correspondance
      ""  --> Création nouvelle entrée
      APPEND VALUE #(
        type = lv_type
      ) TO lt_request_to_create ASSIGNING <lfs_s_request_to_create>.

    ENDIF.

    " Ajout de l'OT
    APPEND <lfs_sr_trkorr>-low TO <lfs_s_request_to_create>-t_trkorr.

  ENDLOOP.

  IF lv_tr_not_exist EQ abap_true.
    " Au moins un OT n'existe pas
    ""  ---> Arrêt du traitement
    RETURN.

  ENDIF.

  IF p_check EQ abap_true.
    " -----------------------------------------------------------
    " Contrôle les objets de la Demande
    " -----------------------------------------------------------

    " Contrôle séquence
    PERFORM request_check CHANGING lv_subrc.
    IF lv_subrc NE 0.
      " Erreur contrôle
      ""  --> PopUp validation création
      DATA : lv_answer TYPE char1.
      CALL FUNCTION 'POPUP_TO_CONFIRM'
        EXPORTING
          titlebar       = text-tt1
          text_question  = text-q01
          text_button_1  = 'Oui'(001)
          text_button_2  = 'Non'(002)
          default_button = '2'
        IMPORTING
          answer         = lv_answer
        EXCEPTIONS
          text_not_found = 1
          OTHERS         = 2.
      IF sy-subrc NE 0 OR lv_answer NE '1'.
        " Erreur création PopUp // Utilisateur ne souhaite pas poursuivre
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Création de(s) Demande(s)
  " -----------------------------------------------------------

  LOOP AT lt_request_to_create ASSIGNING <lfs_s_request_to_create>.

    " Création de la Demande
    DATA(lt_request) = zcl_transport_request_celio=>request_create(
      EXPORTING
        iv_type           = <lfs_s_request_to_create>-type
        iv_batch          = p_batch
        it_trkorr         = <lfs_s_request_to_create>-t_trkorr
        iv_critic         = p_critic
        iv_express        = p_expr
        is_system         = VALUE #(
         mandt = sy-mandt
         sysid = p_sysid
        )
        is_transport_date = VALUE #(
          datum = p_datum
          uzeit = p_uzeit
        )
        iv_only_sysid = p_only
    ).

    IF gv_batch_create EQ abap_true.
      " Lot créé
      ""  --> Sauvegarde le Lot
      zcl_transport_request_batch=>batch_commit_db( p_batch ).

    ENDIF.

    LOOP AT lt_request ASSIGNING FIELD-SYMBOL(<lfs_s_request>).

      IF <lfs_s_request_to_create>-type EQ zcl_transport_request_celio=>mc_request_type-authorization.
        WRITE : |{ <lfs_s_request>-sysid } : Demande Authorisation { <lfs_s_request>-zedreqnb } créé|, /. ##NO_TEXT

      ELSE.
        WRITE : |{ <lfs_s_request>-sysid } : Demande { <lfs_s_request>-zedreqnb } créé|, /. ##NO_TEXT

      ENDIF.

    ENDLOOP.

  ENDLOOP.

  IF p_ljob EQ abap_true.

    DATA :
      lv_jobname  TYPE tbtcjob-jobname,
      lv_jobcount TYPE tbtcjob-jobcount.

    " -----------------------------------------------------------
    " Lancement du Job de Transport
    " -----------------------------------------------------------

    " Initialisation Nom du Job
    lv_jobname = condense( |TRANSPORT_MAN_{ sy-uname }| ).  ##NO_TEXT

    " Ouverture JOB
    CALL FUNCTION 'JOB_OPEN'
      EXPORTING
        jobname          = lv_jobname
      IMPORTING
        jobcount         = lv_jobcount
      EXCEPTIONS
        cant_create_job  = 1
        invalid_job_data = 2
        jobname_missing  = 3
        OTHERS           = 4.
    IF sy-subrc EQ 0.
      " Appel du Programme avec variante
      SUBMIT z_a_bc_transport_job
         VIA JOB lv_jobname
          NUMBER lv_jobcount
             AND RETURN.

      " Fermeture du Job
      CALL FUNCTION 'JOB_CLOSE'
        EXPORTING
          jobcount             = lv_jobcount
          jobname              = lv_jobname
          strtimmed            = abap_true
        EXCEPTIONS
          cant_start_immediate = 1
          invalid_startdate    = 2
          jobname_missing      = 3
          job_close_failed     = 4
          job_nosteps          = 5
          job_notex            = 6
          lock_failed          = 7
          invalid_target       = 8
          OTHERS               = 9.

    ENDIF.

  ENDIF.

ENDFORM.

FORM request_modification.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Modification
  " -----------------------------------------------------------

ENDFORM.

FORM sysid_value_help CHANGING ev_sysid TYPE ztbdestrfc-zedtargsys.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_fields     TYPE dfies_tab,
    lt_valuetab   TYPE char10_t,
    lt_return_tab TYPE hrreturn_tab.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Aide à la Recherche Système Cible
  " -----------------------------------------------------------

  lt_fields = VALUE #(
    (
      tabname   = 'ZTBDESTRFC'                            ##NO_TEXT
      fieldname = 'ZEDTARGSYS'                            ##NO_TEXT
    )
  ).

  " Récupération Liste des Systèmes Cibles
  SELECT DISTINCT ( zedtargsys ) FROM ztbdestrfc
   WHERE loekz EQ @abap_false ORDER BY zedtargsys
    INTO TABLE @lt_valuetab.

  " Appel PopUp Sélection
  CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
    EXPORTING
      retfield        = 'ZEDTARGSYS' ##NO_TEXT
      window_title    = text-ssy
    TABLES
      value_tab       = lt_valuetab
      field_tab       = lt_fields
      return_tab      = lt_return_tab
    EXCEPTIONS
      parameter_error = 1
      no_values_found = 2
      OTHERS          = 3.
  IF sy-subrc NE 0 OR lt_return_tab[] IS INITIAL.
    " Erreur appel Aide à la Recherche
    ""  --> Arrêt du traitement
    CLEAR : ev_sysid.
    RETURN.

  ELSE.
    " Initialisatin système sélectionné
    ev_sysid = lt_return_tab[ 1 ]-fieldval.

  ENDIF.

ENDFORM. " SYSID_VALUE_HELP

*&---------------------------------------------------------------------*
*&      Form  REQUEST_CHECK
*&---------------------------------------------------------------------*
*       Contrôle la cohérence de la Demande
*----------------------------------------------------------------------*
*  <-- EV_SUBRC     Code retour
*----------------------------------------------------------------------*
FORM request_check CHANGING ev_subrc TYPE sy-subrc.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_listasci   TYPE list_string_table,
    lt_listobject TYPE table_abaplist.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lor_data       TYPE REF TO data,
    lo_salv_table  TYPE REF TO cl_salv_table,
    lor_line_descr TYPE REF TO cl_abap_datadescr.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_value>    TYPE any,
    <lfs_t_result> TYPE STANDARD TABLE.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  CLEAR : ev_subrc.

  " -----------------------------------------------------------
  " Récupération Route de Transport
  " -----------------------------------------------------------

  " Récupération des Environnements
  DATA(lt_transport_road) = zcl_transport_request_celio=>transport_road_get(
    iv_sysid      = p_sysid
    iv_only_sysid = p_only
  ).

  " -----------------------------------------------------------
  " Paramétrage pour récupération ALV résultat
  " -----------------------------------------------------------

  " Récuépration données & metadata
  cl_salv_bs_runtime_info=>set(
    data     = abap_true
    display  = abap_false
    metadata = abap_true
  ).

  " -----------------------------------------------------------
  " Lance le programme de contrôle
  " -----------------------------------------------------------

  " Programme de Contrôle
  SUBMIT z_a_bc_transport_check
    WITH s_trkorr IN s_trkorr[]
    WITH p_sysid  EQ p_sysid
    EXPORTING LIST TO MEMORY
     AND RETURN.

  TRY.
      " -----------------------------------------------------------
      " Récupération résultat du contrôle
      " -----------------------------------------------------------

      " Récupération données
      cl_salv_bs_runtime_info=>get_data_ref( IMPORTING r_data = lor_data ).
      IF lor_data IS BOUND.
        " Données présente
        ASSIGN lor_data->* TO <lfs_t_result>.

      ENDIF.
      IF NOT <lfs_t_result> IS ASSIGNED
      OR <lfs_t_result> IS INITIAL.
        " Pas de données
        ""  --> Arrêt du traitement
        ev_subrc = 0.
        RETURN.

      ENDIF.

      " Retourne indicateur présence erreur / avertissement
      LOOP AT <lfs_t_result> ASSIGNING FIELD-SYMBOL(<lfs_s_result>).

        ASSIGN COMPONENT 'TRKORR' OF STRUCTURE <lfs_s_result> TO <lfs_value>. ##NO_TEXT
        IF sy-subrc EQ 0 AND <lfs_value> IN s_trkorr[].
          " OT en cours de Transport
          ASSIGN COMPONENT 'OBJNAME' OF STRUCTURE <lfs_s_result> TO <lfs_value>. ##NO_TEXT
          IF sy-subrc EQ 0 AND <lfs_value> IS INITIAL.
            " OT non présent dans le système X
            ""  --> On s'assure que l'utilisateur va le transporter dans les autres environnements
            READ TABLE lt_transport_road WITH KEY 'RE1' TRANSPORTING NO FIELDS. ##NO_TEXT
            IF sy-subrc EQ 0.
              " L'OT va être transporté
              ""  --> Supprime de la liste de résultat
              DELETE <lfs_t_result> USING KEY loop_key.
              CONTINUE.

            ENDIF.

          ENDIF.

        ENDIF.

        " Message d'erreur ?
        ASSIGN COMPONENT 'TYPE' OF STRUCTURE <lfs_s_result> TO <lfs_value>. ##NO_TEXT
        IF sy-subrc EQ 0 AND <lfs_value> CA 'EAXIW'.        ##NO_TEXT
          ev_subrc = 4.
        ENDIF.
      ENDLOOP.
      IF ev_subrc IS INITIAL.
        " Aucune erreur / avertissement
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

      " Récupération metadata
      DATA(ls_metadata) = cl_salv_bs_runtime_info=>get_metadata( ).

      " Réinitialisation capture ALV
      cl_salv_bs_runtime_info=>clear_all( ).

      TRY.
          " -----------------------------------------------------------
          " Affichage résultat dans une fenêtre modale
          " -----------------------------------------------------------

          " Génération instance ALV
          cl_salv_table=>factory(
            IMPORTING
              r_salv_table   = lo_salv_table
            CHANGING
              t_table        = <lfs_t_result>
          ).

          " Activation fonctions standards
          lo_salv_table->get_functions( )->set_all( abap_true ).

          DATA(lv_end_line) = lines( <lfs_t_result> ) + 1.
          IF lv_end_line GT 20. lv_end_line = 20. ENDIF.

          " Initialisation taille fenêtre modale
          lo_salv_table->set_screen_popup(
            start_line   = 1
            end_line     = lv_end_line
            start_column = 20
            end_column   = 160
          ).

          " Modification Affichage
          zcl_salv_utilities=>fieldcatalog_lvc_to_salv(
            EXPORTING
              it_fieldcatalog = ls_metadata-t_fcat
            CHANGING
              co_salv_table   = lo_salv_table
          ).

          " Modification intitulé
          lo_salv_table->get_display_settings( )->set_list_header(
            |Contrôle Demande|                              ##NO_TEXT
          ).

          " Affichage de l'ALV
          lo_salv_table->display( ).

        CATCH cx_salv_msg.

      ENDTRY.

    CATCH cx_salv_bs_sc_runtime_info.
      " Erreur récupération données
      ""  --> Le message du programme s'affiche quand même

  ENDTRY.

ENDFORM.

FORM batch_value_help CHANGING ev_batch TYPE ztbrequest_batch-zedbatch.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Sélection des données
  " -----------------------------------------------------------

*CALL FUNCTION 'ZH_REQUEST_BATCH_OPEN'
*  TABLES
*    shlp_tab          =
*    record_tab        =
*  CHANGING
*    shlp              =
*    callcontrol       = .


ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  AT_SELECTION_SCREEN
*&---------------------------------------------------------------------*
*       Action Utilisateur
*----------------------------------------------------------------------*
*      --> IV_UCOMM     Commande Utilisateur
*----------------------------------------------------------------------*
FORM at_selection_screen USING iv_ucomm TYPE sy-ucomm.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_existing TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Suivant l'Action utilisateur
  " -----------------------------------------------------------

  IF iv_ucomm EQ 'CBATCH' OR iv_ucomm EQ 'CHK'.
    " Réinitialise indicateur Vérification
    CLEAR : p_acc.

  ENDIF.

  IF p_sysid NE 'PE1'.
    " Réinitialisation
    CLEAR : p_batch, gv_batch_create.
    CLEAR : p_expr.

  ENDIF.

  " Traitement
  CASE iv_ucomm.

    WHEN 'CRI'.                                             ##NO_TEXT
      " Coche Criticité
      ""  --> Mode manuelle
      gv_critic_man = abap_true.

    WHEN 'CBATCH'.                                          ##NO_TEXT
      " Création de Lot
      ""  --> Traitement Création de Lot
      gs_batch = zcl_transport_request_batch=>batch_create(
        IMPORTING
          ev_existing = lv_existing
      ).

      ""  --> Modifie Coche Critique
      p_critic = gs_batch-zedcritic.

      ""  --> Modifie Coche Express
      p_expr = gs_batch-zedeligible.

      ""  --> Modifie Date de Transport
      p_datum = gs_batch-zedtrpdate.
      p_uzeit = gs_batch-zedtrptime.

      ""  --> Indicateur Batch créé
      gv_batch_create = xsdbool( lv_existing EQ abap_false ).

      ""  --> Retourne Numéro de Lot
      p_batch = gs_batch-zedbatch.

    WHEN OTHERS.
      " Autre Commande
      IF  gv_batch_create EQ abap_false
      AND p_batch NE gs_batch-zedbatch.
        " On a changé de Lot
        ""  --> Recharge Information
        gs_batch = CORRESPONDING #( zcl_transport_request_batch=>batch_get( p_batch ) ).

        ""  --> Modifie Coche Critique
        p_critic = gs_batch-zedcritic.

        ""  --> Modifie Coche Express
        p_expr = gs_batch-zedeligible.

        ""  --> Modifie Date de Transport
        p_datum = gs_batch-zedtrpdate.
        p_uzeit = gs_batch-zedtrptime.

      ENDIF.

*      ""  --> Arrêt du traitement
*      RETURN.

  ENDCASE.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  AT_SELECTION_SCREEN_OUTPUT
*&---------------------------------------------------------------------*
*       Modification Ecran de Sélection
*----------------------------------------------------------------------*
FORM at_selection_screen_output.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Traitement obligatoire
  " -----------------------------------------------------------

  " Dans le cas où l'utilisateur saisie sans tout valider
  ""  --> Contrôle criticité
  PERFORM criticity_check.

  " -----------------------------------------------------------
  " Modification Ecran de Sélection
  " -----------------------------------------------------------

  LOOP AT SCREEN INTO DATA(ls_screen).

    CASE ls_screen-group1.

      WHEN 'REC'.                                           ##NO_TEXT
        " Recette
        ls_screen-input = SWITCH #( xsdbool( p_sysid NE 'PE1' ##NO_TEXT
            OR ( p_sysid EQ 'PE1' AND p_only EQ abap_false ) ) ##NO_TEXT
          WHEN abap_true THEN 1 ELSE 0
        ).

      WHEN 'BAT'.                                           ##NO_TEXT
        " Batch
        ls_screen-input = SWITCH #( xsdbool( p_batch IS INITIAL )
          WHEN abap_true THEN 1 ELSE 0
        ).

      WHEN 'MAN'.                                           ##NO_TEXT
        " Mandatory
        ls_screen-input = 0.

      WHEN 'PRD'.                                           ##NO_TEXT
        " Production
        IF p_sysid EQ 'PE1'.                                ##NO_TEXT
          " Production
          IF ls_screen-name EQ 'P_EXPR'.                    ##NO_TEXT
            ls_screen-input = SWITCH #( xsdbool( p_batch IS INITIAL )
              WHEN abap_true THEN 1 ELSE 0
            ).

          ELSEIF ls_screen-name EQ 'P_CRITIC'.              ##NO_TEXT
            " Express // Critique
            ""  --> RG spécifique au Lot
            ls_screen-input = SWITCH #(
              xsdbool( NOT p_batch IS INITIAL OR gv_critic_auto EQ abap_true )
                WHEN abap_true THEN 0 ELSE 1
            ).

          ENDIF.

        ELSE.
          " Autre
          ""  --> Désactive saisie
          ls_screen-input  = 0.

        ENDIF.

      WHEN OTHERS.
        " Autre
        ""  --> Passe à l'itération suivante
        CONTINUE.

    ENDCASE.

    " Modification de l'écran
    MODIFY screen FROM ls_screen.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  AT_SELECTION_SCREEN_END_OT
*&---------------------------------------------------------------------*
*       A la fin de la saisie des OTs
*----------------------------------------------------------------------*
FORM at_selection_screen_end_ot.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle criticité de la Demande
  " -----------------------------------------------------------

  " Réinitialisation Validation
  CLEAR : p_acc.

  " Contrôle la Criticité
  PERFORM criticity_check.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  CRITICITY_CHECK
*&---------------------------------------------------------------------*
*
*----------------------------------------------------------------------*
FORM criticity_check.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_critic TYPE xsdboolean.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  IF gs_batch-zedcritic EQ abap_true.
    " Lot critique
    ""  --> Rien à faire
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle la Criticité des OTs
  " -----------------------------------------------------------

  LOOP AT s_trkorr[] ASSIGNING FIELD-SYMBOL(<lfs_sr_trkorr>).

    " Contrôle la Criticité
    lv_critic = zcl_transport_request=>criticity_check( <lfs_sr_trkorr>-low ).

    IF lv_critic EQ abap_true.
      " OT critique
      ""  --> Initialisation Criticité
      p_critic = abap_true.

      ""  --> Arrêt de la boucle
      EXIT.

    ENDIF.

  ENDLOOP.

  " Initialisation Indicateur Criticité automatique
  gv_critic_auto = lv_critic.

  IF gv_critic_auto EQ abap_false.

    IF gv_critic_man EQ abap_true.
      " Critique Manuelle et Contrôle Crit vide
      ""  --> Ne pas changer

    ELSE.
      " Contrôle Criticité Vide
      ""  --> Réinitialise indicateur Criticité
      p_critic = abap_false.

    ENDIF.

  ELSEIF gv_critic_auto EQ abap_true.
    " Critique Auto
    ""  --> Réinitialise indicateur Critique Manuelle
    gv_critic_man = abap_false.

  ENDIF.

ENDFORM.
