class ZCL_TRANSPORT_REQUEST definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ts_criticity_result,
        trkorr      TYPE e071-trkorr,
        pgmid       TYPE e071-pgmid,
        object      TYPE e071-object,
        obj_name    TYPE e071-obj_name,
        critic      TYPE xsdboolean,
        explication TYPE string,
      END OF   ts_criticity_result .
  types:
    tt_criticity_result TYPE STANDARD TABLE OF ts_criticity_result
                      WITH NON-UNIQUE KEY primary_key COMPONENTS trkorr pgmid object obj_name .

  class-methods CLASS_CONSTRUCTOR .
  class-methods CRITICITY_CHECK
    importing
      !IV_TRKORR type TRKORR optional
      !IT_TRKORR type TRKORRS optional
    preferred parameter IV_TRKORR
    exporting
      !ET_CRITICITY_RESULT type TT_CRITICITY_RESULT
    returning
      value(RV_CRITIC) type XSDBOOLEAN .
  class-methods TRANSPORT_IS_AUTH
    importing
      !IV_TRKORR type TRKORR
    returning
      value(RV_ONLY_AUTH) type XSDBOOLEAN .
  class-methods TRANSPORT_REQUEST_RELEASE
    importing
      !IV_TRKORR type TRKORR
      !IV_SIMULATION type XSDBOOLEAN optional
    exporting
      !ES_RETURN type BAPIRET2
    returning
      value(RV_SUBRC) type SY-SUBRC .
  class-methods TRANSPORT_REQUEST_IS_RELEASED
    importing
      !IV_TRKORR type TRKORR
    returning
      value(RV_RELEASED) type XSDBOOLEAN .
  class-methods TRANSPORT_REQUEST_CHECK_IMPORT
    importing
      !IV_TRKORR type TRKORR
      !IV_TARSYSTEM type TRTARSYS
    exporting
      !ES_COFILE_HEADER type TSTRFCOFIH
    returning
      value(RV_IMPORTED) type XSDBOOLEAN .
  class-methods TRANSPORT_REQUEST_COFILE_GET
    importing
      !IV_TRKORR type TRKORR
    exporting
      !ES_COFILE_HEADER type TSTRFCOFIH
    returning
      value(RT_COFILE_LINES) type TR_COFILINES .
  class-methods OBJECT_EDITION_CHECK
    importing
      !IV_OBJECT type CLIKE
    returning
      value(RV_CANCELLED) type XSDBOOLEAN .
protected section.
PRIVATE SECTION.

  TYPES :
    BEGIN OF ts_cofile,
      trkorr          TYPE e070-trkorr,
      s_cofile_header TYPE tstrfcofih,
      t_cofile        TYPE tr_cofilines,
    END OF   ts_cofile.

  TYPES : tt_cofile TYPE SORTED TABLE OF ts_cofile
                  WITH UNIQUE KEY primary_key COMPONENTS trkorr.

  TYPES :
    BEGIN OF ts_object_edition,
      object         TYPE string,
      first_edit     TYPE xsdboolean,
      trkorr         TYPE e071-trkorr,
      as4text        TYPE e07t-as4text,
      user_cancelled TYPE xsdboolean,
    END OF   ts_object_edition.

  TYPES : tt_object_edition TYPE SORTED TABLE OF ts_object_edition
                  WITH NON-UNIQUE KEY primary_key COMPONENTS object.

  CLASS-DATA : mo_hardcode TYPE REF TO zcl_hardcode.
  CLASS-DATA : mv_destination TYPE string.
  CLASS-DATA : mt_cofile TYPE zcl_transport_request=>tt_cofile.
  CLASS-DATA : mt_object_edition TYPE tt_object_edition.
ENDCLASS.



CLASS ZCL_TRANSPORT_REQUEST IMPLEMENTATION.


METHOD class_constructor.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Hardcode
      " -----------------------------------------------------------

      zcl_transport_request=>mo_hardcode = zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ). "#EC NOTEXT

    CATCH zcx_hardcode.
      " Hardcode non trouvé


  ENDTRY.

  " -----------------------------------------------------------
  " Initialisation Attribut
  " -----------------------------------------------------------

  " Destination COFILE
  SELECT SINGLE zedrfccons FROM ztbdestrfc
          WHERE zedsoursys EQ 'DE1'                         "#EC NOTEXT
           INTO @zcl_transport_request=>mv_destination.

ENDMETHOD.


METHOD criticity_check.
***------------------------------------------------------------------***
**                              TYPES                                 **
***------------------------------------------------------------------***

  TYPES :
    BEGIN OF lts_result_select_ddic_dd03l,
      tabname TYPE dd03l-tabname,
    END OF   lts_result_select_ddic_dd03l.

  TYPES : ltt_result_select_ddic_dd03l TYPE STANDARD TABLE OF lts_result_select_ddic_dd03l
                  WITH NON-UNIQUE KEY primary_key COMPONENTS tabname.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
        lr_trkorr TYPE ucon_tr_req_range.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
    lt_trkorr            TYPE trkorrs,
    lt_split_result      TYPE stringtab,
    lt_result_ddic_dd03l TYPE ltt_result_select_ddic_dd03l.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lot_result TYPE REF TO data.

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
    lr_range_list_incl TYPE RANGE OF e071-obj_name,
    lr_range_list_excl TYPE RANGE OF e071-obj_name.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
    ls_critic_rules TYPE zcl_hardcode=>tt_attribute_value.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_where           TYPE string,
    lv_tabname         TYPE dd03l-tabname,
    lv_select_exec     TYPE string,
    lv_select_pre_load TYPE string.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  REFRESH : et_criticity_result.

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  IF NOT it_trkorr[] IS INITIAL.
    " Liste OT
    ""  --> Utilisation de cette Liste
    lt_trkorr[] = it_trkorr[].

  ELSEIF NOT iv_trkorr IS INITIAL.
    " OT transmis
    ""  --> Ajout de cet OT
    APPEND iv_trkorr TO lt_trkorr.

  ELSE.
    " Aucun paramètre
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " Mise en Range
  LOOP AT lt_trkorr ASSIGNING FIELD-SYMBOL(<lfs_sr_trkorr>).
    APPEND VALUE #(
      sign   = if_trba_selection_c=>gc_sign_incl
      option = if_trba_selection_c=>gc_option_eq
      low    = <lfs_sr_trkorr>
    ) TO lr_trkorr.
  ENDLOOP.

  TRY.
      " -----------------------------------------------------------
      " Récupération règles criticité
      " -----------------------------------------------------------

      " Récupération règles criticité
      ls_critic_rules = zcl_transport_request=>mo_hardcode->parameter_value_get( 'CRITIC_RULES' ). "#EC NOTEXT

    CATCH zcx_hardcode.
      " Aucun Hardcode
      ""  --> Arrêt du traitement
      RETURN.

  ENDTRY.

  " -----------------------------------------------------------
  " Récupération Objets contenu dans l'OT
  " -----------------------------------------------------------

  " Récupération contenu de l'OT
  SELECT CASE WHEN main~strkorr NE @space THEN main~strkorr ELSE main~trkorr END AS trkorr,
         e071~pgmid, e071~object, e071~obj_name, e071~objfunc
    FROM e070 AS main INNER JOIN e071 ON e071~trkorr   EQ main~trkorr
   WHERE main~strkorr IN @lr_trkorr   OR main~trkorr   IN @lr_trkorr
     AND ( pgmid NE @if_dms_constants=>orig_type_corr AND object NE @if_cts_organizer_constants=>activity_release )
    INTO TABLE @DATA(lt_071).
  IF sy-subrc NE 0.
    " Aucun Objet
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " Tri
  SORT lt_071 BY trkorr pgmid object obj_name.
  DELETE ADJACENT DUPLICATES FROM lt_071 COMPARING trkorr pgmid object obj_name.

  " -----------------------------------------------------------
  " Contrôle Criticité
  " -----------------------------------------------------------

  " Parcours chaque Règle
  LOOP AT ls_critic_rules ASSIGNING FIELD-SYMBOL(<lfs_s_critic_rules>).

    " Pré-Traitement
    CASE <lfs_s_critic_rules>-key2.

      WHEN 'LIST'.                                          "#EC NOTEXT
        " Contrôle via Liste
        ""  --> Découpe sur le caractère séparateur de liste (',')
        SPLIT concat_lines_of( <lfs_s_critic_rules>-source_code ) AT ',' "#EC NOTEXT
         INTO TABLE lt_split_result.
        "" --> Mise en Range
        LOOP AT lt_split_result ASSIGNING FIELD-SYMBOL(<lfs_s_split_result>).

          IF <lfs_s_split_result> IS INITIAL.
            " Valeur vide
            ""  --> Passe à l'itération suivante
            CONTINUE.

          ENDIF.

          " Condense
          CONDENSE <lfs_s_split_result>.

          " Ajout de l'entrée
          IF contains( val = <lfs_s_split_result> start = '!' ). "#EC NOTEXT
            " 1er carac = '!' => Exclue la sélection
            <lfs_s_split_result> = <lfs_s_split_result>+1.
            APPEND VALUE #(
              sign   = if_trba_selection_c=>gc_sign_excl
              " Si contient '*' => Recherche par Pattern
              option = SWITCH #( xsdbool( contains( val = <lfs_s_split_result> sub = '*' ) ) "#EC NOTEXT
                WHEN abap_true THEN if_trba_selection_c=>gc_option_cp
                ELSE if_trba_selection_c=>gc_option_eq
              )
              " Si 1er carac = '!' => Saute le 1er caractère
              low = <lfs_s_split_result>
            ) TO lr_range_list_excl.

          ELSE.
            " Inclusion
            APPEND VALUE #(
              sign   = if_trba_selection_c=>gc_sign_incl
              " Si contient '*' => Recherche par Pattern
              option = SWITCH #( xsdbool( contains( val = <lfs_s_split_result> sub = '*' ) ) "#EC NOTEXT
                WHEN abap_true THEN if_trba_selection_c=>gc_option_cp
                ELSE if_trba_selection_c=>gc_option_eq
              )
              " Si 1er carac = '!' => Saute le 1er caractère
              low = <lfs_s_split_result>
            ) TO lr_range_list_incl.

          ENDIF.

        ENDLOOP.
        IF  lr_range_list_incl[] IS INITIAL
        AND lr_range_list_excl[] IS INITIAL.
          " Aucune Liste
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

      WHEN 'SELECT'.
        " Contrôle via Sélection en DB
        ""  --> Concaténe le SELECT défini
        lv_select_pre_load = concat_lines_of( <lfs_s_critic_rules>-source_code ).

      WHEN OTHERS.
        " A implémenter

    ENDCASE.

    " Parcours tous les OTs
    LOOP AT lt_trkorr ASSIGNING FIELD-SYMBOL(<lfs_s_trkorr>).

      " Récupération première itération des objets de l'OT
      READ TABLE lt_071 WITH KEY trkorr = <lfs_s_trkorr>
                    TRANSPORTING NO FIELDS BINARY SEARCH.
      IF sy-subrc NE 0.
        " Aucun Objet
        ""  --> Passe à l'OT suivant
        CONTINUE.

      ENDIF.

      " Parcours tous les élèments à vérifier
      LOOP AT lt_071 ASSIGNING FIELD-SYMBOL(<lfs_s_071>)
                          FROM sy-tabix.

        IF <lfs_s_071>-trkorr NE <lfs_s_trkorr>.
          " On ne traite plus le même OT
          ""  --> Arrêt de la boucle
          EXIT.

        ENDIF.

        " Récupération entrée
        READ TABLE et_criticity_result WITH KEY trkorr   = <lfs_s_071>-trkorr
                                                pgmid    = <lfs_s_071>-pgmid
                                                object   = <lfs_s_071>-object
                                                obj_name = <lfs_s_071>-obj_name
                                      ASSIGNING FIELD-SYMBOL(<lfs_s_criticity_result>)
                                         BINARY SEARCH.
        IF sy-subrc NE 0.
          " Aucune correspondance
          ""  --> Ajout de l'entrée
          INSERT VALUE #(
            trkorr   = <lfs_s_071>-trkorr
            pgmid    = <lfs_s_071>-pgmid
            object   = <lfs_s_071>-object
            obj_name = <lfs_s_071>-obj_name
          ) INTO et_criticity_result INDEX sy-tabix ASSIGNING <lfs_s_criticity_result>.

        ELSEIF <lfs_s_criticity_result>-critic EQ abap_true.
          " Objet déjà identifié comme critique
          ""  --> Passe à l'itération suivante
          CONTINUE.

        ENDIF.

        IF <lfs_s_critic_rules>-key1 EQ <lfs_s_071>-object.
          " Contrôle sur un Objet
          ""  --> Discrimation par niveau de Clef renseigné
          IF     NOT <lfs_s_critic_rules>-key4 IS INITIAL.
            " Plus complexe (de clef)

          ELSEIF NOT <lfs_s_critic_rules>-key3 IS INITIAL.
            " Moyennement complexe (de clef)

          ELSEIF NOT <lfs_s_critic_rules>-key2 IS INITIAL.
            " Complexité basse (de clef)

          ELSE.
            " Sans Complexité
            ""  --> Objet critique listé dans Range ?
            IF  NOT <lfs_s_critic_rules>-range[] IS INITIAL
            AND <lfs_s_071>-obj_name IN <lfs_s_critic_rules>-range[].
              " Oui
              <lfs_s_criticity_result>-critic = abap_true.
              MESSAGE ID 'ZTOOLS'	TYPE if_msg_output=>msgtype_error "#EC NOTEXT
                  NUMBER 022      INTO <lfs_s_criticity_result>-explication.

            ENDIF.

          ENDIF.

        ELSEIF NOT <lfs_s_critic_rules>-range[] IS INITIAL
           AND <lfs_s_071>-object IN <lfs_s_critic_rules>-range[].
          " Contrôle basée sur ensemble d'Objet
          ""  --> Discrimation par niveau de Clef renseigné
          IF     NOT <lfs_s_critic_rules>-key4 IS INITIAL.
            " Plus complexe (de clef)

          ELSEIF NOT <lfs_s_critic_rules>-key3 IS INITIAL.
            " Moyennement complexe (de clef)

          ELSEIF NOT <lfs_s_critic_rules>-key2 IS INITIAL.
            " Complexité basse (de clef)
            ""  --> Suivant le type de recherche
            CASE <lfs_s_critic_rules>-key2.

              WHEN 'LIST'.                                  "#EC NOTEXT
                " Contrôle via Liste
                ""  --> Objet critique listé ?
                IF ( NOT lr_range_list_incl IS INITIAL AND <lfs_s_071>-obj_name IN lr_range_list_incl )
                OR ( NOT lr_range_list_excl IS INITIAL AND <lfs_s_071>-obj_name IN lr_range_list_excl ).
                  " Oui
                  <lfs_s_criticity_result>-critic = abap_true.
                  MESSAGE ID 'ZTOOLS'	TYPE if_msg_output=>msgtype_error "#EC NOTEXT
                      NUMBER 021      INTO <lfs_s_criticity_result>-explication.

                ENDIF.

              WHEN 'SELECT'.                                "#EC NOTEXT
                " Contrôle via Sélection en DB
                ""  --> Suivant le type d'élèment (nom de l'attribut)
                CASE <lfs_s_critic_rules>-attribute_name.

                  WHEN 'DDIC_DD03L'.                        "#EC NOTEXT
                    " Elèment du Dictionaire basée sur DD03L
                    ""  --> Défini condition
                    lv_where  = |'{ <lfs_s_071>-obj_name }'|. "#EC NOTEXT

                    ""  --> Initialisation Requête
                    lv_select_exec = lv_select_pre_load.

                    ""  --> Initialisation Référence sur Table de résultat DDIC
                    lot_result = REF #( lt_result_ddic_dd03l ).

                  WHEN OTHERS.
                    " Autre
                    ""  --> A implémenter
                    EXIT.

                ENDCASE.

                " Remplace les variables
                REPLACE '?' WITH lv_where INTO lv_select_exec. "#EC NOTEXT

                TRY.
                    " Exécution du SELECT
                    zcl_dynamic_source_code=>execute_select_dynamic(
                      EXPORTING
                        iv_select  = lv_select_exec
                      CHANGING
                        cot_result = lot_result
                    ).

                  CATCH cx_root INTO DATA(lo_cx_root).
                    " Erreur exécution SELECT
                    IF sy-debug EQ abap_true. "Pour débogage
                      DATA(ls_exception) = lo_cx_root->get_text( ).

                    ENDIF.

                ENDTRY.

                ""  --> Suivant le nom de l'attribut (type d'élèment)
                CASE <lfs_s_critic_rules>-attribute_name.

                  WHEN 'DDIC_DD03L'.                        "#EC NOTEXT
                    " Elèment du Dictionaire basée sur DD03L
                    IF NOT lt_result_ddic_dd03l[] IS INITIAL.
                      " Au moins une entrée correspondant à la Sélection
                      ""  --> Initialise Flag Criticité
                      <lfs_s_criticity_result>-critic = abap_true.
                      MESSAGE ID 'KE'	TYPE if_msg_output=>msgtype_error "#EC NOTEXT
                           NUMBER 139 INTO <lfs_s_criticity_result>-explication
                                      WITH lt_result_ddic_dd03l[ 1 ]-tabname.

                    ENDIF.

                  WHEN OTHERS.
                    " Autre
                    ""  --> A implémenter
                    EXIT.

                ENDCASE.

              WHEN OTHERS.
                " Autre
                ""  --> A implémenter
                EXIT.

            ENDCASE.

          ELSEIF NOT <lfs_s_critic_rules>-key1 IS INITIAL.
            " Complexité faible (de clef)


          ELSE.
            " Sans complexité (de clef)

          ENDIF.

        ENDIF.

        " Réinitialisation
        CLEAR   : lot_result.
        REFRESH : lt_result_ddic_dd03l.

      ENDLOOP.

    ENDLOOP.

    " Réinitialisation
    CLEAR  : lv_select_pre_load.
    REFRESH : lr_range_list_excl, lr_range_list_incl.

  ENDLOOP.

  " -----------------------------------------------------------
  " Post-Traitement
  " -----------------------------------------------------------

  " Retourne Code Criticité
  DELETE et_criticity_result WHERE critic EQ abap_false.
  rv_critic = xsdbool( line_exists( et_criticity_result[ critic = abap_true ] ) ).

ENDMETHOD.


METHOD object_edition_check.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
        lv_answer TYPE numc1.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Sélection des données
  " -----------------------------------------------------------

  TRY.
      " Contrôle Activation du Contrôle
      IF zcl_hardcode=>get_instance( 'ZCL_IM_CTS_REQUEST_CHECK' )->attribute_value_get( ##NO_TEXT
              iv_parameter_name = 'CONFIGURATION'           ##NO_TEXT
              iv_attribute_name = 'ZXSEUU08'                ##NO_TEXT
          )-key1 NE abap_true.
        " Contrôle désactivée
        ""  --> Arrêt du traitement
        RETURN.

      ENDIF.

    CATCH zcx_hardcode.
      " Pas de Hardcode
      ""  --> Arrêt du traitement
      RETURN.

  ENDTRY.

  " Récupération donnée Objet
  READ TABLE zcl_transport_request=>mt_object_edition
  WITH TABLE KEY object = iv_object ASSIGNING FIELD-SYMBOL(<lfs_s_object_edition>).
  IF sy-subrc NE 0.
    " Pas de données pour cet Objet
    ""  --> Création nouvelle entrée
    INSERT VALUE #(
      object = iv_object
    ) INTO TABLE zcl_transport_request=>mt_object_edition
       ASSIGNING <lfs_s_object_edition>.

  ENDIF.

  IF  <lfs_s_object_edition>-first_edit     EQ abap_true
  AND <lfs_s_object_edition>-user_cancelled NE abap_true.
    " Objet déjà contrôlée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  ""  --> Initialise Flag Première Edition
  <lfs_s_object_edition>-first_edit = abap_true.

  ""  --> Contrôle présence autre Version non transportée jusqu'en Prod / Recette
  SELECT CASE WHEN main~strkorr NE @space THEN main~strkorr ELSE main~trkorr END AS trkorr_main
    FROM e071 INNER JOIN e070 AS main ON e071~trkorr EQ main~trkorr
   WHERE e071~obj_name EQ @<lfs_s_object_edition>-object AND e071~trkorr NOT LIKE 'DE1_P%' ##NO_TEXT
     AND main~trstatus NE 'D'                               ##NO_TEXT
  INTO TABLE @DATA(lt_trkorr).
  IF sy-subrc NE 0.
    " Aucun OT
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " Au moins un OT non modifiable trouvé
  ""  --> Tri par Ordre décroissant
  SORT lt_trkorr BY trkorr_main DESCENDING.
  <lfs_s_object_edition>-trkorr = lt_trkorr[ 1 ]-trkorr_main.

  SELECT SINGLE as4text FROM e07t
          WHERE trkorr EQ @<lfs_s_object_edition>-trkorr AND langu EQ 'F'
           INTO @<lfs_s_object_edition>-as4text.

  ""  --> Contrôle Import Production
  IF zcl_transport_request=>transport_request_check_import(
   EXPORTING
     iv_trkorr        = <lfs_s_object_edition>-trkorr
     iv_tarsystem     = 'PE1'                               ##NO_TEXT
 ) EQ abap_true.
    " OT transporté en Production
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " OT non transportée en Production
  ""  --> Popup Confirme
  CALL FUNCTION 'POPUP_TO_CONFIRM'
    EXPORTING
      titlebar              = 'Modification non transportée en Production' ##NO_TEXT
      text_question         = CONV char120( |{ <lfs_s_object_edition>-trkorr } - { <lfs_s_object_edition>-as4text }|
                              && |\\ La modification n'est pas en Prod ! Tu assumes ?| ) ##NO_TEXT
      text_button_1         = 'Oh que oui !' ##NO_TEXT
      icon_button_1         = '@Y2@'
      text_button_2         = 'Oulà non !' ##NO_TEXT
      icon_button_2         = '@1V@'
      default_button        = '2' ##NO_TEXT
      display_cancel_button = abap_false
    IMPORTING
      answer                = lv_answer
    EXCEPTIONS
      text_not_found        = 1
      OTHERS                = 2.
  IF sy-subrc NE 0.
    " Erreur affichage Popup
    ""  --> Confirme
    lv_answer = '1'.                                        ##NO_TEXT

  ENDIF.

  " Suivant la réponse de l'utilisateur
  CASE lv_answer.

    WHEN '1'.                                               ##NO_TEXT
      " J'assume !
      ""  --> Tudo Bem
      rv_cancelled = abap_false.

    WHEN '2'.
      " Oulà non !
      rv_cancelled = abap_true.

    WHEN OTHERS.
      " Euuhh ...
      ""  --> Annule le traitement
      rv_cancelled = abap_true.

  ENDCASE.

  " Retiens la réponse de l'utilisateur
  <lfs_s_object_edition>-user_cancelled = rv_cancelled.

ENDMETHOD.


METHOD transport_is_auth.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle que l'OT soit uniquement des Autorisations
  " -----------------------------------------------------------

  " Récupération des Tâches de l'OT
  SELECT trkorr FROM e070
               WHERE strkorr EQ @iv_trkorr
          INTO TABLE @DATA(lt_e070).
  IF sy-subrc NE 0.
    " Aucune Tâche
    ""  --> Ajout de l'OT en tant que Tâche
    APPEND iv_trkorr TO lt_e070.

  ENDIF.

  " Contrôle présence d'objet d'autorisation
  SELECT trkorr
          FROM e071
  FOR ALL ENTRIES IN @lt_e070
               WHERE trkorr     EQ @lt_e070-trkorr
                 AND ( obj_name EQ 'SPERS_OBJ'              "#EC NOTEXT
                  OR   obj_name EQ 'AGR_TIMEB' )            "#EC NOTEXT
          INTO TABLE @DATA(lt_e071).
  IF sy-subrc NE 0.
    " Pas d'objet d'Autorisation
    RETURN.

  ENDIF.

  " Contrôle que chaque Tâche soit dédié aux autorisations
  LOOP AT lt_e070 ASSIGNING FIELD-SYMBOL(<lfs_s_e070>).

    " Recherche présence de la Tâche
    READ TABLE lt_e071 WITH KEY trkorr = <lfs_s_e070>-trkorr
                   TRANSPORTING NO FIELDS.
    IF sy-subrc NE 0.
      " Tâche non trouvé
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDLOOP.

  " Si on arrive ici c'est que c'est de l'Auth
  rv_only_auth = abap_true.

ENDMETHOD.


METHOD transport_request_check_import.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_cofile TYPE zcl_transport_request=>ts_cofile-t_cofile.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  CLEAR : es_cofile_header.

  " -----------------------------------------------------------
  " Récupération Cofile
  " -----------------------------------------------------------

  " Récupération données CoFile
  lt_cofile = zcl_transport_request=>transport_request_cofile_get(
    EXPORTING
      iv_trkorr        = iv_trkorr
    IMPORTING
      es_cofile_header = es_cofile_header
  ).

  " -----------------------------------------------------------
  " Retourne indicateur Import effectué
  " -----------------------------------------------------------

  rv_imported = xsdbool( line_exists( lt_cofile[
     tarsystem = iv_tarsystem
     function  = cl_cts_change_tracking_api=>co_import_status_imported
   ] ) ).

ENDMETHOD.


METHOD transport_request_cofile_get.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_cofile TYPE zcl_transport_request=>ts_cofile.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  CLEAR : es_cofile_header.

  " -----------------------------------------------------------
  " Récupération Cofile Buffer
  " -----------------------------------------------------------

  READ TABLE zcl_transport_request=>mt_cofile
  WITH TABLE KEY trkorr = iv_trkorr
  ASSIGNING FIELD-SYMBOL(<lfs_s_cofile>).
  IF sy-subrc EQ 0.
    " Retourne les données
    rt_cofile_lines  = <lfs_s_cofile>-t_cofile[].
    es_cofile_header = <lfs_s_cofile>-s_cofile_header.

  ELSE.
    TRY.
        " -----------------------------------------------------------
        " Récupération Cofile DB
        " -----------------------------------------------------------

        " Récupération Cofile
        CALL FUNCTION 'STRF_READ_COFILE'
          EXPORTING
            iv_dirtype     = cl_cts_language=>lc_dir_trans
            iv_trkorr      = iv_trkorr
          IMPORTING
            ev_cofi_header = es_cofile_header
          TABLES
            tt_cofi_lines  = rt_cofile_lines
          EXCEPTIONS
            wrong_call     = 1
            no_info_found  = 2
            error_message  = 3
            OTHERS         = 4.
        IF sy-subrc NE 0.
          " Erreur récupération CoFile
          ""  --> Réinitialise données
          REFRESH : rt_cofile_lines.

        ENDIF.

      CATCH cx_root.
        " Erreur ...

    ENDTRY.

    ""  --> Ajout de l'entrée
    INSERT VALUE #(
      trkorr          = iv_trkorr
      t_cofile        = rt_cofile_lines
      s_cofile_header = es_cofile_header
    ) INTO TABLE zcl_transport_request=>mt_cofile.

  ENDIF.

ENDMETHOD.


METHOD transport_request_is_released.
*&---------------------------------------------------------------------*
*& Méthode         : TRANSPORT_REQUEST_IS_RELEASED                     *
*& Classe          : ZCL_TRANSPORT_REQUEST                             *
*& Description     : Ordre de Transport - Libéré ?                     *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 04/04/2019                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle que l'Objet soit libéré
  " -----------------------------------------------------------

  " Recherche Objet libéré
  SELECT SINGLE trkorr
    FROM e070
   WHERE trkorr   EQ @iv_trkorr
     AND trstatus EQ @if_cts_transport_request=>co_status_open
    INTO @DATA(lv_trkorr).

  " Retourne booléen OT libéré
  rv_released = xsdbool( sy-subrc NE 0 ).

ENDMETHOD.


METHOD transport_request_release.
*&---------------------------------------------------------------------*
*& Méthode         : TRANSPORT_ORDER_RELEASE                           *
*& Classe          : ZCL_TRANSPORT_REQUEST                             *
*& Description     : Ordre de Transport- Libération                    *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 01/02/2017                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
        lt_trkorr TYPE trkorrs.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_request TYPE trwbo_request.

***==================================================================***
**                           TRAITEMENT                               **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération typologie de l'Objet (Tâche ou OT ?)
  " -----------------------------------------------------------

  " Récupér
  SELECT SINGLE trkorr, strkorr
    FROM e070
   WHERE trkorr   EQ @iv_trkorr
     AND trstatus EQ @if_cts_transport_request=>co_status_open
    INTO @DATA(ls_e070).
  IF sy-subrc NE 0.
    " OT déjà libéré
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  IF ls_e070-strkorr IS INITIAL.
    " -----------------------------------------------------------
    " Récupération des Tâches - non libérées - contenue dans l'OT
    " -----------------------------------------------------------

    " Récupération des Tâches non libérées
    SELECT trkorr FROM e070
     WHERE strkorr  EQ @ls_e070-trkorr
       AND trstatus EQ @if_cts_transport_request=>co_status_open
      INTO TABLE @lt_trkorr.

    " Ajout de l'OT à la fin de la table de Travail
    APPEND ls_e070-trkorr TO lt_trkorr.

  ELSE.
    " Tâche
    ""  --> Ajout de la Tâche dans table de travail
    APPEND ls_e070-trkorr TO lt_trkorr.

  ENDIF.

  " -----------------------------------------------------------
  " Libération des Tâches / OTs
  " -----------------------------------------------------------

  LOOP AT lt_trkorr ASSIGNING FIELD-SYMBOL(<lfs_s_trkorr>).

    " Libération de la Tâche / OT
    CALL FUNCTION 'TR_RELEASE_REQUEST'
      EXPORTING
        iv_trkorr                  = <lfs_s_trkorr>
        iv_dialog                  = abap_false
        iv_as_background_job       = abap_false
        iv_success_message         = abap_false
        iv_display_export_log      = abap_false
        iv_simulation              = iv_simulation
      IMPORTING
        es_request                 = ls_request
      EXCEPTIONS
        cts_initialization_failure = 1
        enqueue_failed             = 2
        no_authorization           = 3
        invalid_request            = 4
        request_already_released   = 5
        repeat_too_early           = 6
        error_in_export_methods    = 7
        object_check_error         = 8
        docu_missing               = 9
        db_access_error            = 10
        action_aborted_by_user     = 11
        export_failed              = 12
        error_message              = 13
        OTHERS                     = 14.
    IF sy-subrc NE 0 AND ( iv_simulation EQ abap_false AND sy-subrc NE 4 ).
      " Une erreur est survenue
      rv_subrc = sy-subrc.

      IF es_return IS SUPPLIED.
        ""  --> Retourne message d'erreur
        es_return-id         = sy-msgid.
        es_return-type       = sy-msgty.
        es_return-number     = sy-msgno.
        es_return-message_v1 = sy-msgv1.
        es_return-message_v2 = sy-msgv2.
        es_return-message_v3 = sy-msgv3.
        es_return-message_v4 = sy-msgv4.
        MESSAGE ID es_return-id TYPE es_return-type NUMBER es_return-number
              WITH es_return-message_v1 es_return-message_v2
                   es_return-message_v3 es_return-message_v4
              INTO es_return-message.

        ""  --> Rollback
        CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.

      ELSE.
        IF iv_simulation EQ abap_true.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'
            EXPORTING
              wait = abap_true.

        ENDIF.

      ENDIF.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    CLEAR : ls_request.

  ENDLOOP.

ENDMETHOD.
ENDCLASS.
