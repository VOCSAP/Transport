*&---------------------------------------------------------------------*
*& Report  Z_A_BC_TRANSPORT_DEPENDENCIES
*&
*&---------------------------------------------------------------------*
*&
*&
*&---------------------------------------------------------------------*
REPORT z_a_bc_transport_dependencies.

DATA :
  gv_done   TYPE xsdboolean,
  gv_trkorr TYPE e070-trkorr.

DATA :
      gt_attributes TYPE trwbo_t_e070a.

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

TABLES : e070.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Critère de sélection
" -----------------------------------------------------------

" OT
PARAMETERS : p_tkrorr TYPE e070-trkorr.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Liste OT dépendances
" -----------------------------------------------------------

" Dépendance
SELECT-OPTIONS : s_trkorr FOR e070-trkorr NO INTERVALS MODIF ID loc.

SELECTION-SCREEN END OF BLOCK b2.

PARAMETERS : p_attr TYPE e070a-attribute
                 DEFAULT zcl_transport_request_celio=>mc_attribute_dependencies
                      NO-DISPLAY.

SELECTION-SCREEN END OF BLOCK b1.

***==================================================================***
**                     AT SELECTION-SCREEN OUTPUT                     **
***==================================================================***
AT SELECTION-SCREEN OUTPUT.
  PERFORM at_selection_screen_output.


START-OF-SELECTION.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
        lt_attributes TYPE trwbo_t_e070a.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
     lv_answer TYPE char1.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  IF p_tkrorr IS INITIAL.
    " OT obligatoire
    ""  --> Arrêt du traitement
    MESSAGE s008(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  IF gv_done EQ abap_false.
    " Pas de modification de l'écran de sélection
    ""  --> Veuillez d'abord valider la saisie de l'OT
    MESSAGE s008(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
    RETURN.

  ENDIF.

  IF s_trkorr[] IS INITIAL.
    " Aucune dépendance
    ""  --> PopUp Confirmation
    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = text-tb2
        text_question         = text-q01
        text_button_1         = text-001
        text_button_2         = text-002
        default_button        = '1' ##NOTEXT
        display_cancel_button = abap_true
      IMPORTING
        answer                = lv_answer
      EXCEPTIONS
        text_not_found        = 1
        OTHERS                = 2.
    IF sy-subrc NE 0 OR lv_answer NE '1'.
      " L'utiisateur ne souhaite pas poursuivre
      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

  ENDIF.

  " -----------------------------------------------------------
  " Initialisation Attribut
  " -----------------------------------------------------------

  " Suppression des Dépendances
  DELETE gt_attributes WHERE attribute EQ p_attr.

  " Ajout des Attributs
  LOOP AT s_trkorr ASSIGNING FIELD-SYMBOL(<lfs_s_trkorr>).

    APPEND VALUE #(
     trkorr    = p_tkrorr
     attribute = p_attr
     reference = <lfs_s_trkorr>-low
    ) TO gt_attributes.

  ENDLOOP.

  " Tri et suppression doublon
  SORT gt_attributes BY attribute reference.
  DELETE ADJACENT DUPLICATES FROM gt_attributes COMPARING attribute reference.

  " -----------------------------------------------------------
  " MàJ Attribut
  " -----------------------------------------------------------

  " Modification des dépendances
  CALL FUNCTION 'TR_REPLACE_ATTRIBUTES'
    EXPORTING
      iv_request        = p_tkrorr
      it_attributes     = gt_attributes
    IMPORTING
      et_attributes     = gt_attributes
    EXCEPTIONS
      invalid_request   = 1
      invalid_attribute = 2
      no_authorization  = 3
      enqueue_failed    = 4
      db_access_error   = 5
      OTHERS            = 6.
  IF sy-subrc NE 0.
    " Erreur lors de la MàJ
    ""  --> Rollback
    MESSAGE s010(ztools) DISPLAY LIKE if_msg_output=>msgtype_error.
    CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.

  ELSE.
    " MàJ effectuée
    ""  --> Commit
    MESSAGE s011(ztools) DISPLAY LIKE if_msg_output=>msgtype_success.
    CALL FUNCTION 'BAPI_TRANSACTION_COMMIT'.

  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  AT_SELECTION_SCREEN_OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM at_selection_screen_output.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  "
  " -----------------------------------------------------------

  IF p_tkrorr NE gv_trkorr.
    " Changement numéro OT
    ""  --> Réinitialise témoin
    CLEAR : gv_done.

    ""  --> Changement OT
    gv_trkorr = p_tkrorr.

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  " Récupération des Attributs de l'OT
  CALL FUNCTION 'TR_READ_ATTRIBUTES'
    EXPORTING
      iv_request       = p_tkrorr
    IMPORTING
      et_attributes    = gt_attributes
    EXCEPTIONS
      invalid_request  = 1
      no_authorization = 2
      OTHERS           = 3.
  IF sy-subrc NE 0.
    " Erreur lecture attribut
    ""  --> Réinitialise la liste
    REFRESH : s_trkorr.

  ENDIF.

  LOOP AT SCREEN INTO DATA(ls_screen).

    CASE ls_screen-group1.

      WHEN 'LOC'. ##NOTEXT
        " Liste OT
        IF gv_done EQ abap_false.
          ""  --> Charge la liste
          LOOP AT gt_attributes ASSIGNING FIELD-SYMBOL(<lfs_s_attributes>)
            WHERE attribute EQ p_attr.

            APPEND VALUE #(
              low    = <lfs_s_attributes>-reference
              sign   = if_trba_selection_c=>gc_sign_incl
              option = if_trba_selection_c=>gc_option_eq
            ) TO s_trkorr.

          ENDLOOP.
          IF sy-subrc NE 0.
            " Aucun Attribut de Dépendance
            ""  --> Réinitialise la liste
            REFRESH : s_trkorr.

          ENDIF.

          " Témoin traitement effectué
          gv_done = abap_true.

        ENDIF.

      WHEN OTHERS.
        " Autre
        ""  --> Passe à l'itération suivante
        CONTINUE.

    ENDCASE.

    " Modification écran
    MODIFY screen FROM ls_screen.

  ENDLOOP.

ENDFORM.
