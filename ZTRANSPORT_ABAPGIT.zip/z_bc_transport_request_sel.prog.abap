*&---------------------------------------------------------------------*
*&  Include           Z_BC_TRANSPORT_REQUEST_SEL
*&---------------------------------------------------------------------*


TABLES : e070.

***==================================================================***
**                         SELECTION-SCREEN                           **
***==================================================================***

*" Action utilisateur
*PARAMETERS : p_ucomm TYPE sy-ucomm NO-DISPLAY.
*
" Ecran
PARAMETERS : p_screen TYPE sy-dynnr NO-DISPLAY.

SELECTION-SCREEN BEGIN OF SCREEN 2000 AS SUBSCREEN.
" -----------------------------------------------------------
" Création
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE text-tb1.
" -----------------------------------------------------------
" Paramètres
" -----------------------------------------------------------

" Liste OT
SELECT-OPTIONS : s_trkorr FOR e070-trkorr NO INTERVALS.

" Système Cible
PARAMETERS : p_sysid TYPE ztbdestrfc-zedtargsys.

" Type de Transport
PARAMETERS : p_type TYPE ztbrequest-zedtrpcode.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE text-tb3.

" Date de Transport souhaité
PARAMETERS : p_datum TYPE sy-datum DEFAULT sy-datum OBLIGATORY MODIF ID bat.

" Heure de Transport souhaité
PARAMETERS : p_uzeit TYPE sy-uzeit DEFAULT sy-uzeit OBLIGATORY MODIF ID bat.

SELECTION-SCREEN SKIP 1.

SELECTION-SCREEN BEGIN OF BLOCK b4 WITH FRAME TITLE text-tb4.

SELECTION-SCREEN:
  BEGIN OF LINE,
  COMMENT 1(12) text-bat FOR FIELD p_batch.
PARAMETERS p_batch TYPE ztbrequest_batch-zedbatch MODIF ID prd MATCHCODE OBJECT zh_request_batch_open.
SELECTION-SCREEN :
    COMMENT 25(11) text-tcb,
    PUSHBUTTON 37(4) text-cba USER-COMMAND cbatch MODIF ID prd, POSITION 46.
SELECTION-SCREEN :
END OF LINE.

SELECTION-SCREEN END OF BLOCK b4.

SELECTION-SCREEN BEGIN OF BLOCK b5 WITH FRAME TITLE text-tb5.

" Au moins un OT critique
PARAMETERS : p_critic AS CHECKBOX MODIF ID prd USER-COMMAND cri.

SELECTION-SCREEN END OF BLOCK b5.

SELECTION-SCREEN END OF BLOCK b3.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE text-tb2.
" -----------------------------------------------------------
" Options de Transport supplémentaires
" -----------------------------------------------------------

" Contrôler cohérence
PARAMETERS : p_check AS CHECKBOX DEFAULT 'X' USER-COMMAND chk MODIF ID man. ##NO_TEXT

" Uniquement ce Sytème
PARAMETERS : p_only AS CHECKBOX MODIF ID prd USER-COMMAND chk.

" Express
PARAMETERS : p_expr AS CHECKBOX MODIF ID prd USER-COMMAND chk.

" Déclencher Job Transport
PARAMETERS : p_ljob AS CHECKBOX MODIF ID rec USER-COMMAND chk.

SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b6 WITH FRAME TITLE text-tb6.
" -----------------------------------------------------------
" Certification
" -----------------------------------------------------------

" Certifie
PARAMETERS : p_acc AS CHECKBOX USER-COMMAND acc.

SELECTION-SCREEN END OF BLOCK b6.

SELECTION-SCREEN END OF SCREEN 2000.

SELECTION-SCREEN BEGIN OF SCREEN 3000 AS SUBSCREEN.
" -----------------------------------------------------------
" Modification
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK tb7 WITH FRAME TITLE text-tb7.

" Requête
PARAMETERS : p_req TYPE ztbrequest-zedreqnb.

" Lecture seule
PARAMETERS : p_ronly TYPE xsdboolean NO-DISPLAY.

SELECTION-SCREEN END OF BLOCK tb7.

SELECTION-SCREEN END OF SCREEN 3000.

SELECTION-SCREEN BEGIN OF SCREEN 4000 AS SUBSCREEN.
" -----------------------------------------------------------
" Exécution
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF BLOCK tb8 WITH FRAME TITLE text-tb8.

" Date
PARAMETERS : p_edate TYPE sy-datum DEFAULT sy-datum.

" Heure
PARAMETERS : p_ehour TYPE sy-uzeit DEFAULT sy-uzeit.

SELECTION-SCREEN END OF BLOCK tb8.

SELECTION-SCREEN END OF SCREEN 4000.


" -----------------------------------------------------------
" Gestion Onglets
" -----------------------------------------------------------

SELECTION-SCREEN BEGIN OF TABBED BLOCK tab FOR 30 LINES.

" Création
SELECTION-SCREEN TAB (30) text-sc1 USER-COMMAND ucomm1
  DEFAULT SCREEN 2000.

" Modification
SELECTION-SCREEN TAB (30) text-sc2 USER-COMMAND ucomm2
  DEFAULT SCREEN 3000.

" Exécution
SELECTION-SCREEN TAB (30) text-sc3 USER-COMMAND ucomm3
  DEFAULT SCREEN 4000.

SELECTION-SCREEN END OF BLOCK tab.
