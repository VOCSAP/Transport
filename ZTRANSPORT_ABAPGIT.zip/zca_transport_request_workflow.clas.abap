class ZCA_TRANSPORT_REQUEST_WORKFLOW definition
  public
  inheriting from ZCB_TRANSPORT_REQUEST_WORKFLOW
  final
  create private .

public section.

  class-data AGENT type ref to ZCA_TRANSPORT_REQUEST_WORKFLOW read-only .

  class-methods CLASS_CONSTRUCTOR .
protected section.
private section.
ENDCLASS.



CLASS ZCA_TRANSPORT_REQUEST_WORKFLOW IMPLEMENTATION.


  method CLASS_CONSTRUCTOR.
***BUILD 090501
************************************************************************
* Purpose        : Initialize the 'class'.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : Singleton is created.
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 1999-09-20   : (OS) Initial Version
* - 2000-03-06   : (BGR) 2.0 modified REGISTER_CLASS_AGENT
************************************************************************
* GENERATED: Do not modify
************************************************************************

  create object AGENT.

  call method AGENT->REGISTER_CLASS_AGENT
    exporting
      I_CLASS_NAME          = 'ZCL_TRANSPORT_REQUEST_WORKFLOW'
      I_CLASS_AGENT_NAME    = 'ZCA_TRANSPORT_REQUEST_WORKFLOW'
      I_CLASS_GUID          = '0050568A04511EDAB1D1FD2A8AC8447B'
      I_CLASS_AGENT_GUID    = '0050568A04511EDAB1D1FD2A8AC8C47B'
      I_AGENT               = AGENT
      I_STORAGE_LOCATION    = ''
      I_CLASS_AGENT_VERSION = '2.0'.

           "CLASS_CONSTRUCTOR
  endmethod.
ENDCLASS.
