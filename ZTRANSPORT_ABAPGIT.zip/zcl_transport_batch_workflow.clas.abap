class ZCL_TRANSPORT_BATCH_WORKFLOW definition
  public
  final
  create protected

  global friends ZCB_TRANSPORT_BATCH_WORKFLOW .

public section.

  interfaces IF_OS_STATE .
  interfaces BI_OBJECT .
  interfaces BI_PERSISTENT .
  interfaces IF_PT_REQ_ITEM .
  interfaces IF_PT_REQ_ITEM_WF .
  interfaces IF_WORKFLOW .

  events WF_VALIDATION_EVENT_START
    exporting
      value(IS_BATCH) type ZTBREQUEST_BATCH
      value(IO_INSTANCE) type ref to ZCL_TRANSPORT_BATCH_WORKFLOW .
  events WF_VALIDATION_EVENT_DONE
    exporting
      value(IS_BATCH) type ZTBREQUEST_BATCH .
  events WF_VALIDATION_EVENT_STOP
    exporting
      value(IS_BATCH) type ZTBREQUEST_BATCH optional .
  events WF_VALIDATION_EVENT_RESEND
    exporting
      value(IS_BATCH) type ZTBREQUEST_BATCH optional .

  methods SET_ZEDCREATED_BY
    importing
      !I_ZEDCREATED_BY type UNAME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDCREATED_AT
    importing
      !I_ZEDCREATED_AT type ERDAT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDCREATED_BY
    returning
      value(RESULT) type UNAME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDCREATED_AT
    returning
      value(RESULT) type ERDAT
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDVALIDATED
    importing
      !I_ZEDVALIDATED type ICL_STATUS_RELEASED
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRTTIME
    importing
      !I_ZEDTRTTIME type ZEDTRTTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRTDATE
    importing
      !I_ZEDTRTDATE type ZEDTRTDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRPTIME
    importing
      !I_ZEDTRPTIME type ZEDTRPTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDTRPDATE
    importing
      !I_ZEDTRPDATE type ZEDTRPDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSUPVALUSER
    importing
      !I_ZEDSUPVALUSER type ZEDSUPVALUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSUPVALTIME
    importing
      !I_ZEDSUPVALTIME type ZEDSUPVALTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDSUPVALDATE
    importing
      !I_ZEDSUPVALDATE type ZEDSUPVALDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDJIRA
    importing
      !I_ZEDJIRA type ZEDJIRA_ID
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDELIGIBLE
    importing
      !I_ZEDELIGIBLE type ZEDELIGIBLE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDCRITIC
    importing
      !I_ZEDCRITIC type ZEDREQCRITIC
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_ZEDBATCH_DESCR
    importing
      !I_ZEDBATCH_DESCR type ZEDREQBATCH_DESCR
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDVALIDATED
    returning
      value(RESULT) type ICL_STATUS_RELEASED
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRTTIME
    returning
      value(RESULT) type ZEDTRTTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRTDATE
    returning
      value(RESULT) type ZEDTRTDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRPTIME
    returning
      value(RESULT) type ZEDTRPTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDTRPDATE
    returning
      value(RESULT) type ZEDTRPDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPVALUSER
    returning
      value(RESULT) type ZEDSUPVALUSER
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPVALTIME
    returning
      value(RESULT) type ZEDSUPVALTIME
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDSUPVALDATE
    returning
      value(RESULT) type ZEDSUPVALDATE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDJIRA
    returning
      value(RESULT) type ZEDJIRA_ID
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDELIGIBLE
    returning
      value(RESULT) type ZEDELIGIBLE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDCRITIC
    returning
      value(RESULT) type ZEDREQCRITIC
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDBATCH_DESCR
    returning
      value(RESULT) type ZEDREQBATCH_DESCR
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_ZEDBATCH
    returning
      value(RESULT) type ZEDREQBATCH
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods CONSTRUCTOR .
  class-methods WORKFLOW_VALIDATION_STOP
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  class-methods WORKFLOW_VALIDATION_START
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  class-methods WORKFLOW_VALIDATION_DONE
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  class-methods WORKFLOW_VALIDATION_RESEND
    importing
      !IV_BATCH type ZEDREQBATCH
    returning
      value(RV_RAISED) type XSDBOOLEAN .
  methods DATA_RETURN
    returning
      value(RS_BATCH_REQUEST) type ZTBREQUEST_BATCH .
  methods MAIL_NOTIFICATION .
  methods INITIATOR_MAIL_GET
    returning
      value(RV_EMAIL) type AD_SMTPADR .
  methods VALIDATOR_MAIL_GET
    returning
      value(RT_EMAIL) type BCSY_SMTPA .
  methods SUPER_VALIDATOR_MAIL_GET
    returning
      value(RT_EMAIL) type BCSY_SMTPA .
protected section.

  data ZEDBATCH type ZEDREQBATCH .
  data ZEDCRITIC type ZEDREQCRITIC .
  data ZEDELIGIBLE type ZEDELIGIBLE .
  data ZEDTRPDATE type ZEDTRPDATE .
  data ZEDTRPTIME type ZEDTRPTIME .
  data ZEDBATCH_DESCR type ZEDREQBATCH_DESCR .
  data ZEDJIRA type ZEDJIRA_ID .
  data ZEDVALIDATED type ICL_STATUS_RELEASED .
  data ZEDSUPVALUSER type ZEDSUPVALUSER .
  data ZEDSUPVALDATE type ZEDSUPVALDATE .
  data ZEDSUPVALTIME type ZEDSUPVALTIME .
  data ZEDTRTDATE type ZEDTRTDATE .
  data ZEDTRTTIME type ZEDTRTTIME .
  data ZEDCREATED_BY type UNAME .
  data ZEDCREATED_AT type ERDAT .
private section.

  types:
    BEGIN OF ts_instance,
      instid     TYPE sibfinstid,
      o_instance TYPE REF TO zcl_transport_batch_workflow,
    END OF   ts_instance .
  types:
    tt_instance TYPE SORTED TABLE OF ts_instance
                  WITH UNIQUE KEY primary_key COMPONENTS instid .
  types:
    BEGIN OF ts_work_area,
      o_hardcode              TYPE REF TO zcl_hardcode,
      initiator_user          TYPE sy-uname,
      initiator_email         TYPE ad_smtpadr,
      t_validator_email       TYPE piqt_mailaddr,
      t_super_validator_email TYPE piqt_mailaddr,
    END OF   ts_work_area .

  CONSTANTS:
    BEGIN OF mc_workflow_event,
      objtype                 TYPE char50 VALUE 'ZCL_TRANSPORT_BATCH_WORKFLOW', ##NOTEXT
      event_validation_start  TYPE char50 VALUE 'WF_VALIDATION_EVENT_START', ##NOTEXT
      event_validation_stop   TYPE char50 VALUE 'WF_VALIDATION_EVENT_STOP', ##NOTEXT
      event_validation_done   TYPE char50 VALUE 'WF_VALIDATION_EVENT_DONE', ##NOTEXT
      event_validation_resend TYPE char50 VALUE 'WF_VALIDATION_EVENT_RESEND', ##NOTEXT
    END OF  mc_workflow_event .
  class-data MT_INSTANCE type ZCL_TRANSPORT_BATCH_WORKFLOW=>TT_INSTANCE .
  data MS_WORK_AREA type ZCL_TRANSPORT_BATCH_WORKFLOW=>TS_WORK_AREA .

  methods SET_MS_WORK_AREA
    importing
      !I_MS_WORK_AREA type ZCL_TRANSPORT_BATCH_WORKFLOW=>TS_WORK_AREA
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_MS_WORK_AREA
    returning
      value(RESULT) type ZCL_TRANSPORT_BATCH_WORKFLOW=>TS_WORK_AREA
    raising
      CX_OS_OBJECT_NOT_FOUND .
ENDCLASS.



CLASS ZCL_TRANSPORT_BATCH_WORKFLOW IMPLEMENTATION.


METHOD bi_object~default_attribute_value.
ENDMETHOD.


METHOD bi_object~execute_default_method.
ENDMETHOD.


METHOD bi_object~release.
ENDMETHOD.


METHOD bi_persistent~find_by_lpor.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_transport_batch TYPE REF TO zcl_transport_batch_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération instance Singleton
  " -----------------------------------------------------------

  " Récupération instance ST
  READ TABLE zcl_transport_batch_workflow=>mt_instance
  WITH TABLE KEY instid = lpor-instid
       ASSIGNING FIELD-SYMBOL(<lfs_s_instance>).
  IF sy-subrc NE 0.
    " Aucune correspondance
    TRY.
        ""  --> Récupération instance basée sur DB
        lo_transport_batch = zca_transport_batch_workflow=>agent->get_persistent( CONV #( lpor-instid ) ).

      CATCH cx_root.
        " Erreur
        ""  --> Création instance
        CREATE OBJECT lo_transport_batch.

    ENDTRY.

    ""  --> Ajout de l'entrée & création de l'instance
    INSERT VALUE #(
      instid     = lpor-instid
      o_instance = lo_transport_batch
    ) INTO TABLE zcl_transport_batch_workflow=>mt_instance
       ASSIGNING <lfs_s_instance>.

  ENDIF.

  " Retourne instance
  result ?= <lfs_s_instance>-o_instance.

ENDMETHOD.


METHOD bi_persistent~lpor.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne information WorkItem
  " -----------------------------------------------------------

  result-instid         = me->get_zedbatch( ).
  result-objtype-catid  = cl_swf_evt_event=>mc_objcateg_cl.
  result-objtype-typeid = 'ZCL_TRANSPORT_BATCH_WORKFLOW'.   "#EC NOTEXT

ENDMETHOD.


METHOD constructor.
*&---------------------------------------------------------------------*
*& Méthode         : CONSTRUCTOR                                       *
*& Classe          : ZCL_TRANSPORT_BATCH_WORKFLOW                      *
*& Description     : Constructeur                                      *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Créé par     : Olivier Véhier                                       *
*                                                                      *
*& Créé le      : 16/07/2020                                           *
*                                                                      *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Liste des modifications                                             *
*& Auteur      Date       Signature  Objet de la modification          *
*&---------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*                                                                      *

***------------------------------------------------------------------***
**                             RANGES                                 **
***------------------------------------------------------------------***
  DATA :
    lr_uname_validator       TYPE RANGE OF sy-uname,
    lr_uname_super_validator TYPE RANGE OF sy-uname.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation Attributs
  " -----------------------------------------------------------

  TRY.
      " Hardcode
      me->ms_work_area-o_hardcode = zcl_hardcode=>get_instance( 'ZCL_TRANSPORT_REQUEST_WORKFLOW' ). "#EC NOTEXT

      TRY.
          " Mail Validateur
          LOOP AT me->ms_work_area-o_hardcode->attribute_value_get(
             iv_parameter_name = 'CONFIGURATION'            "#EC NOTEXT
             iv_attribute_name = 'VALIDATOR_EMAIL'          "#EC NOTEXT
            )-range INTO DATA(ls_range).

            APPEND ls_range-low TO me->ms_work_area-t_validator_email.

          ENDLOOP.

        CATCH zcx_hardcode.
          " Paramétrage non existant

      ENDTRY.

      TRY.
          " Mail Super-Validateur
          LOOP AT me->ms_work_area-o_hardcode->attribute_value_get(
               iv_parameter_name = 'CONFIGURATION'          "#EC NOTEXT
               iv_attribute_name = 'SUPER_VALIDATOR_MAIL'   "#EC NOTEXT
            )-range INTO ls_range.

            APPEND ls_range-low TO me->ms_work_area-t_super_validator_email.

          ENDLOOP.

        CATCH zcx_hardcode.
          " Paramétrage non existant

      ENDTRY.

      TRY.
          " User Super-Validateur
          lr_uname_super_validator = me->ms_work_area-o_hardcode->attribute_value_get(
               iv_parameter_name = 'CONFIGURATION'          "#EC NOTEXT
               iv_attribute_name = 'SUPER_VALIDATOR_USER'   "#EC NOTEXT
            )-range.

        CATCH zcx_hardcode.
          " Paramétrage non existant
          CLEAR : lr_uname_super_validator.

      ENDTRY.

      TRY.
          " User Validateur
          lr_uname_validator = me->ms_work_area-o_hardcode->attribute_value_get(
               iv_parameter_name = 'CONFIGURATION'          "#EC NOTEXT
               iv_attribute_name = 'VALIDATOR_USER'         "#EC NOTEXT
            )-range.

        CATCH zcx_hardcode.
          " Paramétrage non existant

      ENDTRY.

    CATCH zcx_hardcode.
      " Hardcode non trouvée
      CLEAR : lr_uname_validator.

  ENDTRY.

  " -----------------------------------------------------------
  " Validateurs
  " -----------------------------------------------------------

  IF NOT lr_uname_validator[] IS INITIAL.
    " Récupération des Emails associés à ces Comptes
    SELECT adr6~smtp_addr
      FROM usr21 INNER JOIN adr6
                         ON adr6~addrnumber EQ usr21~addrnumber
                        AND adr6~persnumber EQ usr21~persnumber
     WHERE usr21~bname   IN @lr_uname_validator
            APPENDING TABLE @me->ms_work_area-t_validator_email.

  ENDIF.

  " -----------------------------------------------------------
  " Super-Validateurs
  " -----------------------------------------------------------

  IF NOT lr_uname_super_validator[] IS INITIAL.
    " Récupération des Emails associés à ces Comptes
    SELECT adr6~smtp_addr
      FROM usr21 INNER JOIN adr6
                         ON adr6~addrnumber EQ usr21~addrnumber
                        AND adr6~persnumber EQ usr21~persnumber
     WHERE usr21~bname   IN @lr_uname_super_validator
            APPENDING TABLE @me->ms_work_area-t_super_validator_email.

  ENDIF.

  " -----------------------------------------------------------
  " Mail Initiateur
  " -----------------------------------------------------------

  " Initialisation données initiateur (Nom & eMail)
  me->ms_work_area-initiator_user = sy-uname.
  SELECT SINGLE adr6~smtp_addr
    FROM usr21 INNER JOIN adr6
                       ON adr6~addrnumber EQ usr21~addrnumber
                      AND adr6~persnumber EQ usr21~persnumber
   WHERE usr21~bname EQ @sy-uname
    INTO @me->ms_work_area-initiator_email.
  IF sy-subrc NE 0.
    " Aucune correspondance
    "" --> Construction adresse Celio
    me->ms_work_area-initiator_email = |{ sy-uname CASE = LOWER }@celio.com|. "#EC NOTEXT

  ENDIF.

ENDMETHOD.


METHOD data_return.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_value_me>      TYPE any,
    <lfs_value_request> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Récupération des Attributs
  SELECT cmpname  FROM vseocompdf
   WHERE clsname    EQ 'ZCL_TRANSPORT_BATCH_WORKFLOW' ##NOTEXT
     AND attpersist EQ @abap_true
    INTO TABLE @DATA(lt_attributes).

  " -----------------------------------------------------------
  " Initialisation des données
  " -----------------------------------------------------------

  " Traite tous les attributs publiques
  LOOP AT lt_attributes ASSIGNING FIELD-SYMBOL(<lfs_s_attributes>).

    " Récupération valeur attribut
    ASSIGN me->(<lfs_s_attributes>-cmpname) TO <lfs_value_me>.
    IF sy-subrc EQ 0.
      " Initialisation pointeur sur la données
      ASSIGN COMPONENT <lfs_s_attributes>-cmpname
          OF STRUCTURE rs_batch_request
                    TO <lfs_value_request>.

    ENDIF.
    IF sy-subrc NE 0.
      " Erreur initialisation pointeur
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Initialisation de la valeur
    <lfs_value_request> = <lfs_value_me>.

  ENDLOOP.

ENDMETHOD.


  method GET_MS_WORK_AREA.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute MS_WORK_AREA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = MS_WORK_AREA.

           " GET_MS_WORK_AREA
  endmethod.


  method GET_ZEDBATCH.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDBATCH
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDBATCH.

           " GET_ZEDBATCH
  endmethod.


  method GET_ZEDBATCH_DESCR.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDBATCH_DESCR
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDBATCH_DESCR.

           " GET_ZEDBATCH_DESCR
  endmethod.


  method GET_ZEDCREATED_AT.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDCREATED_AT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDCREATED_AT.

           " GET_ZEDCREATED_AT
  endmethod.


  method GET_ZEDCREATED_BY.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDCREATED_BY
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDCREATED_BY.

           " GET_ZEDCREATED_BY
  endmethod.


  method GET_ZEDCRITIC.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDCRITIC
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDCRITIC.

           " GET_ZEDCRITIC
  endmethod.


  method GET_ZEDELIGIBLE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDELIGIBLE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDELIGIBLE.

           " GET_ZEDELIGIBLE
  endmethod.


  method GET_ZEDJIRA.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDJIRA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDJIRA.

           " GET_ZEDJIRA
  endmethod.


  method GET_ZEDSUPVALDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPVALDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPVALDATE.

           " GET_ZEDSUPVALDATE
  endmethod.


  method GET_ZEDSUPVALTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPVALTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPVALTIME.

           " GET_ZEDSUPVALTIME
  endmethod.


  method GET_ZEDSUPVALUSER.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDSUPVALUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDSUPVALUSER.

           " GET_ZEDSUPVALUSER
  endmethod.


  method GET_ZEDTRPDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRPDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRPDATE.

           " GET_ZEDTRPDATE
  endmethod.


  method GET_ZEDTRPTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRPTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRPTIME.

           " GET_ZEDTRPTIME
  endmethod.


  method GET_ZEDTRTDATE.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRTDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRTDATE.

           " GET_ZEDTRTDATE
  endmethod.


  method GET_ZEDTRTTIME.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDTRTTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDTRTTIME.

           " GET_ZEDTRTTIME
  endmethod.


  method GET_ZEDVALIDATED.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute ZEDVALIDATED
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = ZEDVALIDATED.

           " GET_ZEDVALIDATED
  endmethod.


  method IF_OS_STATE~GET.
***BUILD 090501
     " returning result type ref to object
************************************************************************
* Purpose        : Get state.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* GENERATED: Do not modify
************************************************************************

  data: STATE_OBJECT type ref to CL_OS_STATE.

  create object STATE_OBJECT.
  call method STATE_OBJECT->SET_STATE_FROM_OBJECT( ME ).
  result = STATE_OBJECT.

  endmethod.


  method IF_OS_STATE~HANDLE_EXCEPTION.
***BUILD 090501
     " importing I_EXCEPTION type ref to IF_OS_EXCEPTION_INFO optional
     " importing I_EX_OS type ref to CX_OS_OBJECT_NOT_FOUND optional
************************************************************************
* Purpose        : Handles exceptions during attribute access.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : If an exception is raised during attribut access,
*                  this method is called and the exception is passed
*                  as a paramater. The default is to raise the exception
*                  again, so that the caller can handle the exception.
*                  But it is also possible to handle the exception
*                  here in the callee.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
* - 2000-08-02   : (SB)  OO Exceptions
************************************************************************
* Modify if you like
************************************************************************

  if i_ex_os is not initial.
    raise exception i_ex_os.
  endif.

  endmethod.


  method IF_OS_STATE~INIT.
***BUILD 090501
"#EC NEEDED
************************************************************************
* Purpose        : Initialisation of the transient state partition.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : Transient state is initial.
*
* OO Exceptions  : -
*
* Implementation : Caution!: Avoid Throwing ACCESS Events.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* Modify if you like
************************************************************************

  endmethod.


  method IF_OS_STATE~INVALIDATE.
***BUILD 090501
"#EC NEEDED
************************************************************************
* Purpose        : Do something before all persistent attributes are
*                  cleared.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : Whatever you like to do.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* Modify if you like
************************************************************************

  endmethod.


  method IF_OS_STATE~SET.
***BUILD 090501
     " importing I_STATE type ref to object
************************************************************************
* Purpose        : Set state.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* GENERATED: Do not modify
************************************************************************

  data: STATE_OBJECT type ref to CL_OS_STATE.

  STATE_OBJECT ?= I_STATE.
  call method STATE_OBJECT->SET_OBJECT_FROM_STATE( ME ).

  endmethod.


METHOD if_pt_req_item~compare_db_to_object.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_transport_batch TYPE REF TO zcl_transport_batch_workflow.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_field TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
    <lfs_source> TYPE any,
    <lfs_target> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Pré-Traitement
  " -----------------------------------------------------------

  " Témoin indentique
  ret_identical = abap_true.

  " Move-Cast
  lo_transport_batch ?= im_compare_item.

  " Récupération des Attributs
  SELECT cmpname  FROM vseocompdf
   WHERE clsname    EQ 'ZCL_TRANSPORT_BATCH_WORKFLOW' ##NOTEXT
     AND attpersist EQ @abap_true
    INTO TABLE @DATA(lt_attributes).

  " -----------------------------------------------------------
  " Compare les données
  " -----------------------------------------------------------

  LOOP AT lt_attributes ASSIGNING FIELD-SYMBOL(<lfs_s_attributes>).

    " Récupération valeur objet courant
    ASSIGN me->(<lfs_s_attributes>-cmpname) TO <lfs_source>.
    IF sy-subrc EQ 0.
      " Récupération valeur objet comparé
      lv_field = |lo_transport_batch->{ <lfs_s_attributes>-cmpname }|. ##NOTEXT
      ASSIGN (lv_field) TO <lfs_target>.

    ENDIF.
    IF sy-subrc NE 0.
      " Pas de correspondance
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    IF <lfs_source> NE <lfs_target>.
      " Valeur divergente
      ""  --> Initialisation témoin
      ret_identical = abap_false.

      ""  --> Arrêt du traitement
      RETURN.

    ENDIF.

    " Réinitialisation
    UNASSIGN : <lfs_target>, <lfs_source>.

  ENDLOOP.

ENDMETHOD.


METHOD if_pt_req_item~get_all_item_attribs.

***------------------------------------------------------------------***
**                            STRUCTURE                               **
***------------------------------------------------------------------***
  DATA :
        ls_workflow_data TYPE ztbrequest_batch.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
        lo_structdescr TYPE REF TO cl_abap_structdescr.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_method TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
                 <lfs_attribute> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation tables des Attributs
  " -----------------------------------------------------------

  " Récupération description de la structure
  lo_structdescr ?= cl_abap_structdescr=>describe_by_data( ls_workflow_data ).

  LOOP AT lo_structdescr->components ASSIGNING FIELD-SYMBOL(<lfs_s_components>).

    " Nom de la méthode
    lv_method = |GET_{ <lfs_s_components>-name CASE = UPPER }|. "#EC NOTEXT

    " Initialisation pointeur sur l'Attribut
    ASSIGN (<lfs_s_components>-name) TO <lfs_attribute>.
    IF sy-subrc NE 0.
      " Aucune corrspondance
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    TRY.
        " Appel de la méthode dynamiquement
        CALL METHOD me->(lv_method)
          RECEIVING
            result = <lfs_attribute>.

      CATCH cx_sy_dyn_call_illegal_method.
        " Méthode inexistante

    ENDTRY.

    " Ajout dans la table des Attributs / Valeurs
    APPEND VALUE #(
      name  = <lfs_s_components>-name
      value = <lfs_attribute>
    ) TO ex_attribs_tab.

    " Réinitialisation
    CLEAR    : lv_method.
    UNASSIGN : <lfs_attribute>.

  ENDLOOP.

  " Iniialisation Attribut WF
  CALL METHOD me->if_pt_req_item_wf~set_all_item_wf_attribs.

ENDMETHOD.


METHOD if_pt_req_item~get_item_id.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne ID
  " -----------------------------------------------------------

  result = me->get_zedbatch( ).

ENDMETHOD.


METHOD if_pt_req_item~set_all_item_attribs.

***------------------------------------------------------------------***
**                             TABLES                                 **
***------------------------------------------------------------------***
  DATA :
      lt_parameter_table TYPE abap_parmbind_tab.

***------------------------------------------------------------------***
**                            VARIABLES                               **
***------------------------------------------------------------------***
  DATA :
    lv_method TYPE string.

***------------------------------------------------------------------***
**                          FIELD-SYMBOLS                             **
***------------------------------------------------------------------***
  FIELD-SYMBOLS :
        <lfs_value> TYPE any.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation des Attributs
  " -----------------------------------------------------------

  LOOP AT im_attribs_tab ASSIGNING FIELD-SYMBOL(<lfs_s_attribts_tab>).

    " Initialisation pointeur sur la valeur
    ASSIGN (<lfs_s_attribts_tab>-name) TO <lfs_value>.
    IF sy-subrc NE 0.
      " Pointeur non initialisé
      ""  --> Passe à l'itération suivante
      CONTINUE.

    ENDIF.

    " Nom de la méthode
    lv_method = |SET_{ <lfs_s_attribts_tab>-name CASE = UPPER }|. "#EC NOTEXT

    " Initialisation paramètre d'appel de la méthode
    lt_parameter_table = VALUE #(
      (
        name  = |I_{ <lfs_s_attribts_tab>-name CASE = UPPER }| "#EC NOTEXT
        value = REF #( <lfs_value> )
      )
    ).

    TRY.
        " Appel de la méthde dynamniquement
        CALL METHOD me->(lv_method)
          PARAMETER-TABLE lt_parameter_table.

      CATCH cx_sy_dyn_call_illegal_method.
        " Méthode inexistante
        ""  --> Passe à l'itération suivante
        CONTINUE.

    ENDTRY.

    " Réinitialisation
    CLEAR   : lv_method.
    REFRESH : lt_parameter_table.

  ENDLOOP.

  TRY.
      " -----------------------------------------------------------
      " Initialisation des Attributs
      " -----------------------------------------------------------

      DATA(lv_id) = me->if_pt_req_item~get_item_id( ).

    CATCH cx_os_object_not_found.

  ENDTRY.

  " -----------------------------------------------------------
  " Initialisation des Attributs Workflow
  " -----------------------------------------------------------

  me->if_pt_req_item_wf~set_all_item_wf_attribs( ).

ENDMETHOD.


METHOD if_pt_req_item~set_item_id.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Initialisation ID
  " -----------------------------------------------------------

  " Initialisation ID
  me->zedbatch = im_item_id.

ENDMETHOD.


METHOD initiator_mail_get.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne Mail Initiateur
  " -----------------------------------------------------------

  rv_email = me->ms_work_area-initiator_email.

ENDMETHOD.


METHOD mail_notification.
ENDMETHOD.


  method SET_MS_WORK_AREA.
***BUILD 090501
     " importing I_MS_WORK_AREA
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute MS_WORK_AREA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_MS_WORK_AREA <> MS_WORK_AREA ).

    MS_WORK_AREA = I_MS_WORK_AREA.

  endif. "( I_MS_WORK_AREA <> MS_WORK_AREA )

           " GET_MS_WORK_AREA
  endmethod.


  method SET_ZEDBATCH_DESCR.
***BUILD 090501
     " importing I_ZEDBATCH_DESCR
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDBATCH_DESCR
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDBATCH_DESCR <> ZEDBATCH_DESCR ).

    ZEDBATCH_DESCR = I_ZEDBATCH_DESCR.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDBATCH_DESCR <> ZEDBATCH_DESCR )

           " GET_ZEDBATCH_DESCR
  endmethod.


  method SET_ZEDCREATED_AT.
***BUILD 090501
     " importing I_ZEDCREATED_AT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDCREATED_AT
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDCREATED_AT <> ZEDCREATED_AT ).

    ZEDCREATED_AT = I_ZEDCREATED_AT.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDCREATED_AT <> ZEDCREATED_AT )

           " GET_ZEDCREATED_AT
  endmethod.


  method SET_ZEDCREATED_BY.
***BUILD 090501
     " importing I_ZEDCREATED_BY
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDCREATED_BY
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDCREATED_BY <> ZEDCREATED_BY ).

    ZEDCREATED_BY = I_ZEDCREATED_BY.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDCREATED_BY <> ZEDCREATED_BY )

           " GET_ZEDCREATED_BY
  endmethod.


  method SET_ZEDCRITIC.
***BUILD 090501
     " importing I_ZEDCRITIC
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDCRITIC
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDCRITIC <> ZEDCRITIC ).

    ZEDCRITIC = I_ZEDCRITIC.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDCRITIC <> ZEDCRITIC )

           " GET_ZEDCRITIC
  endmethod.


  method SET_ZEDELIGIBLE.
***BUILD 090501
     " importing I_ZEDELIGIBLE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDELIGIBLE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDELIGIBLE <> ZEDELIGIBLE ).

    ZEDELIGIBLE = I_ZEDELIGIBLE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDELIGIBLE <> ZEDELIGIBLE )

           " GET_ZEDELIGIBLE
  endmethod.


  method SET_ZEDJIRA.
***BUILD 090501
     " importing I_ZEDJIRA
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDJIRA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDJIRA <> ZEDJIRA ).

    ZEDJIRA = I_ZEDJIRA.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDJIRA <> ZEDJIRA )

           " GET_ZEDJIRA
  endmethod.


  method SET_ZEDSUPVALDATE.
***BUILD 090501
     " importing I_ZEDSUPVALDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPVALDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPVALDATE <> ZEDSUPVALDATE ).

    ZEDSUPVALDATE = I_ZEDSUPVALDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPVALDATE <> ZEDSUPVALDATE )

           " GET_ZEDSUPVALDATE
  endmethod.


  method SET_ZEDSUPVALTIME.
***BUILD 090501
     " importing I_ZEDSUPVALTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPVALTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPVALTIME <> ZEDSUPVALTIME ).

    ZEDSUPVALTIME = I_ZEDSUPVALTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPVALTIME <> ZEDSUPVALTIME )

           " GET_ZEDSUPVALTIME
  endmethod.


  method SET_ZEDSUPVALUSER.
***BUILD 090501
     " importing I_ZEDSUPVALUSER
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDSUPVALUSER
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDSUPVALUSER <> ZEDSUPVALUSER ).

    ZEDSUPVALUSER = I_ZEDSUPVALUSER.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDSUPVALUSER <> ZEDSUPVALUSER )

           " GET_ZEDSUPVALUSER
  endmethod.


  method SET_ZEDTRPDATE.
***BUILD 090501
     " importing I_ZEDTRPDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRPDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRPDATE <> ZEDTRPDATE ).

    ZEDTRPDATE = I_ZEDTRPDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRPDATE <> ZEDTRPDATE )

           " GET_ZEDTRPDATE
  endmethod.


  method SET_ZEDTRPTIME.
***BUILD 090501
     " importing I_ZEDTRPTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRPTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRPTIME <> ZEDTRPTIME ).

    ZEDTRPTIME = I_ZEDTRPTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRPTIME <> ZEDTRPTIME )

           " GET_ZEDTRPTIME
  endmethod.


  method SET_ZEDTRTDATE.
***BUILD 090501
     " importing I_ZEDTRTDATE
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRTDATE
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRTDATE <> ZEDTRTDATE ).

    ZEDTRTDATE = I_ZEDTRTDATE.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRTDATE <> ZEDTRTDATE )

           " GET_ZEDTRTDATE
  endmethod.


  method SET_ZEDTRTTIME.
***BUILD 090501
     " importing I_ZEDTRTTIME
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDTRTTIME
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDTRTTIME <> ZEDTRTTIME ).

    ZEDTRTTIME = I_ZEDTRTTIME.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDTRTTIME <> ZEDTRTTIME )

           " GET_ZEDTRTTIME
  endmethod.


  method SET_ZEDVALIDATED.
***BUILD 090501
     " importing I_ZEDVALIDATED
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute ZEDVALIDATED
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_ZEDVALIDATED <> ZEDVALIDATED ).

    ZEDVALIDATED = I_ZEDVALIDATED.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_ZEDVALIDATED <> ZEDVALIDATED )

           " GET_ZEDVALIDATED
  endmethod.


METHOD super_validator_mail_get.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne Mail Super-Validatateur
  " -----------------------------------------------------------

  rt_email[] = me->ms_work_area-t_super_validator_email[].

ENDMETHOD.


METHOD validator_mail_get.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Retourne Mail Validatateur
  " -----------------------------------------------------------

  rt_email[] = me->ms_work_area-t_validator_email[].

ENDMETHOD.


METHOD workflow_validation_done.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_container       TYPE REF TO if_swf_ifs_parameter_container,
    lo_transport_batch TYPE REF TO zcl_transport_batch_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Récupération instance Transport
      " -----------------------------------------------------------

      " Récupération instance Transport
      lo_transport_batch ?= zcl_transport_batch_workflow=>bi_persistent~find_by_lpor( VALUE #(
        instid = iv_batch
      ) ).

    CATCH cx_root.

  ENDTRY.
  IF NOT lo_transport_batch IS BOUND.
    " Instance non trouvée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Trigger Event Validation effectuée
      " -----------------------------------------------------------

      TRY.
          " -----------------------------------------------------------
          " Préparation Container WF
          " -----------------------------------------------------------


          " Création instance Container du WF
          lo_container = cl_swf_evt_event=>get_event_container(
              im_event    = zcl_transport_batch_workflow=>mc_workflow_event-event_validation_done
              im_objcateg = cl_swf_evt_event=>mc_objcateg_cl
              im_objtype  = zcl_transport_batch_workflow=>mc_workflow_event-objtype
          ).

          IF lo_container IS BOUND.
            " Ajout dans le Container
            lo_container->set(
                name  = 'IS_BATCH'
                value = lo_transport_batch->data_return( )
            ).

          ENDIF.

        CATCH cx_root.

      ENDTRY.

      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_event           = zcl_transport_batch_workflow=>mc_workflow_event-event_validation_done
        im_objkey          = CONV char8( iv_batch )
        im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype         = zcl_transport_batch_workflow=>mc_workflow_event-objtype
        im_event_container = lo_container
      ).

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.


METHOD workflow_validation_resend.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_transport_batch TYPE REF TO zcl_transport_batch_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération instance Transport
  " -----------------------------------------------------------

  " Récupération instance Transport
  lo_transport_batch ?= zcl_transport_batch_workflow=>bi_persistent~find_by_lpor( VALUE #(
    instid = iv_batch
  ) ).
  IF NOT lo_transport_batch IS BOUND.
    " Instance non trouvée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  TRY.
      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_objcateg = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype  = zcl_transport_batch_workflow=>mc_workflow_event-objtype
        im_event    = zcl_transport_batch_workflow=>mc_workflow_event-event_validation_resend
        im_objkey   = CONV char8( iv_batch )
      ).

      " Evénement levée
      rv_raised = abap_true.

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.


METHOD workflow_validation_start.

***------------------------------------------------------------------***
**                            INSTANCES                               **
***------------------------------------------------------------------***
  DATA :
    lo_container       TYPE REF TO if_swf_ifs_parameter_container,
    lo_transport_batch TYPE REF TO zcl_transport_batch_workflow.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  " -----------------------------------------------------------
  " Récupération instance Transport
  " -----------------------------------------------------------

  " Récupération instance Transport
  lo_transport_batch ?= zcl_transport_batch_workflow=>bi_persistent~find_by_lpor( VALUE #(
    instid = iv_batch
  ) ).
  IF NOT lo_transport_batch IS BOUND.
    " Instance non trouvée
    ""  --> Arrêt du traitement
    RETURN.

  ENDIF.

  " -----------------------------------------------------------
  " Contrôle
  " -----------------------------------------------------------

  TRY.
      TRY.
          " -----------------------------------------------------------
          " Préparation Container WF
          " -----------------------------------------------------------

          " Création instance Container du WF
          lo_container = cl_swf_evt_event=>get_event_container(
              im_objcateg  = cl_swf_evt_event=>mc_objcateg_cl
              im_objtype  = zcl_transport_batch_workflow=>mc_workflow_event-objtype
              im_event    = zcl_transport_batch_workflow=>mc_workflow_event-event_validation_start
          ).

          IF lo_container IS BOUND.
            " Ajout dans le Container
            ""  --> Données Demande
            lo_container->set(
                name  = 'IS_BATCH' ##NOTEXT
                value = lo_transport_batch->data_return( )
            ).

            lo_container->set(
                name  = 'IO_INSTANCE' ##NOTEXT
                value = lo_transport_batch
            ).

*            ""  --> Mail Initiateur
*            lo_container->set(
*                name  = 'IV_INITIATOR_EMAIL' ##NOTEXT
*                value = lo_transport_batch->ms_work_area-initiator_email
*            ).
*
*            ""  --> Mail Validateur
*            lo_container->set(
*                name  = 'IT_VALIDATOR_EMAIL' ##NOTEXT
*                value = lo_transport_batch->ms_work_area-t_validator_email
*            ).
*
*            ""  --> Mail Super Validateur
*            lo_container->set(
*                name  = 'IT_SUPER_VALIDATOR_EMAIL' ##NOTEXT
*                value = lo_transport_batch->ms_work_area-t_super_validator_email
*            ).

          ENDIF.

        CATCH cx_root.

      ENDTRY.

      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_objcateg        = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype         = zcl_transport_batch_workflow=>mc_workflow_event-objtype
        im_event           = zcl_transport_batch_workflow=>mc_workflow_event-event_validation_start
        im_objkey          = CONV char8( iv_batch )
        im_event_container = lo_container
      ).

      " Evénement levée
      rv_raised = abap_true.

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.


METHOD workflow_validation_stop.

***==================================================================***
**                             TRAITEMENT                             **
***==================================================================***

  TRY.
      " -----------------------------------------------------------
      " Lancement Workflow
      " -----------------------------------------------------------

      " Déclenche l'évènement de démarrage du WorkFlow
      cl_swf_evt_event=>raise(
        im_objcateg = cl_swf_evt_event=>mc_objcateg_cl
        im_objtype  = zcl_transport_batch_workflow=>mc_workflow_event-objtype
        im_event    = zcl_transport_batch_workflow=>mc_workflow_event-event_validation_stop
        im_objkey   = CONV char8( iv_batch )
      ).

      " Evénement levée
      rv_raised = abap_true.

      " Commit
      COMMIT WORK.

    CATCH : cx_swf_evt_invalid_objtype, cx_swf_evt_invalid_event.
      " Erreur génération WF
      ""  --> Tant pis

  ENDTRY.

ENDMETHOD.
ENDCLASS.
